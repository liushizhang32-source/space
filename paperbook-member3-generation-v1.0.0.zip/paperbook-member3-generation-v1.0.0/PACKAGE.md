# 成员 3 代码包 · Story / TTS / Video

| 项 | 内容 |
|---|---|
| 包名 | `paperbook-member3-generation-v1.0.0` |
| 版本 | v1.0.0 |
| 打包日期 | 2026-11-07 |
| 对应契约 | `docs/API_v1.0.md`（ZSZB-API-1.0 冻结版）C3 / C4 / A6 |
| 归属 | 成员 3（Story / TTS / Video） |
| 测试 | 60 passed（`python -m pytest`） |

## 这个包能干什么

1. 读成员 2 的 `json/{page_id}_ocr.json`、`json/{page_id}_vlm.json`；
2. 生成 `json/{page_id}_story.json`（C3），逐段调 TTS（内容哈希缓存）；
3. 用 ffmpeg 合成 `videos/{page_id}_video.mp4` + `json/{page_id}_video.json`（C4）；
4. 对外提供 `POST /api/v1/tts`（A6），给成员 4 的问答用；
5. 给出与 `/jobs` 的 `pages[]` 同构的结果（`status / degraded / story_url / video_url / error`）。

## 包内容

```
paperbook-member3-generation-v1.0.0/
├── README.md                 模块说明与命令
├── PACKAGE.md                本文件
├── requirements.txt          运行依赖（无密钥）
├── pytest.ini                测试配置
├── .env.example              配置模板（所有值都是空/占位）
├── .gitignore
├── agents/
│   ├── __init__.py
│   └── generation/           story / tts / video / pipeline / cli
├── tests/                    60 项用例（schema、降级、缓存、错误码、端到端）
├── docs/
│   ├── GENERATION.md         实现细节：契约映射、状态机、决策、联调对应
│   ├── images/story-frame.png  demo 产物截图
│   └── schemas/              story/video 的 JSON Schema
├── examples/
│   ├── README.md
│   ├── install_example.py    把示例输入装进 DATA_DIR
│   └── book01_p03/           示例输入：ocr.json、vlm.json、原图 PNG
└── scripts/
    ├── verify.ps1            Windows 一键验证
    └── verify.sh             macOS / Linux 一键验证
```

**不含**：真实 API Key、`.env`、模型权重、ffmpeg 二进制、`_vendor`（沙箱专用）、任何运行产物。

## 三步验证

环境要求：Python 3.10+、`ffmpeg`/`ffprobe` 在 PATH（或 `.env` 里指定 `FFMPEG_PATH`）。

```bash
# 0) 装依赖
pip install -r requirements.txt

# 1) 测试（不需要 ffmpeg 的用例会自动跳过；有 ffmpeg 则全跑）
python -m pytest

# 2) 跑一页示例
python examples/install_example.py
python -m agents.generation run --page-id book01_p03 --age-level 3-6
```

期望：命令输出 `"status": "done"`，并且

```
data/json/book01_p03_story.json      C3
data/json/book01_p03_video.json      C4
data/videos/book01_p03_video.mp4     720x1280 / 25fps / 含字幕
data/audios/tts_*.mp3                静音 mock 音频
```

Windows 可以直接：

```powershell
powershell -ExecutionPolicy Bypass -File scripts\verify.ps1
```

## 先看视频能不能生成

```bash
python -m agents.generation demo --overwrite
```

不需要任何输入数据，会用内置 mock 页跑完整链路。产物在 `_demo_data/`（或 `DATA_DIR`）。
默认 `TTS_ENGINE=silent`，所以**视频是静音的**，这是预期的 mock 行为，不要当成配音效果。

## 配置

复制 `.env.example` 为 `.env`（或直接设环境变量）。全部有默认值，不配也能跑：

| 变量 | 默认 | 作用 |
|---|---|---|
| `DATA_DIR` | `./data` | 产物根目录 |
| `ASSET_BASE_URL` | `http://127.0.0.1:8000` | 拼绝对 URL 用 |
| `FFMPEG_PATH` / `FFPROBE_PATH` | `ffmpeg` / `ffprobe` | 不在 PATH 时指定 |
| `TTS_ENGINE` | `auto` | `auto`/`silent`（静音 mock）/`http`（真实服务） |
| `TTS_HTTP_URL` | 空 | 真实 TTS 服务地址；配了 auto 就走 http |
| `LLM_BASE_URL` / `LLM_API_KEY` / `LLM_MODEL` | 空 | 配了走真实 LLM，否则 `mock-template` |
| `VIDEO_RESOLUTION` | `720x1280` | Q4 未拍板，默认取建议值 |
| `SAFETY_ENABLED` | `0` | Q8：开关默认关，字段与分支已实现 |

**包里没有任何密钥**；`.env` 已被 `.gitignore` 忽略。

## 与其他人对接

- **成员 1（中枢）**：进程内调 `pipeline.run_page(page_id, age_level, settings)`，拿到的 dict
  就是 `pages[]` 的结构；或 `subprocess` 跑 `python -m agents.generation run` 读 stdout JSON。
- **成员 4（前端/问答）**：只调 `POST /api/v1/tts`，不要自己接 TTS SDK；音色统一 `TTS_VOICE_ID`。
- **成员 5（评测）**：直接读 `json/*_story.json`、`json/*_video.json`，字段见 `docs/schemas/`。

## 已实现 / 未实现

已实现：C3、C4、A6、单页流水线、降级矩阵（no_ocr/no_scene/no_audio/no_video/blocked）、
内容哈希缓存、Video/Story 阶段重试、原子写、JSON Schema 导出、60 项测试。

未实现（不归成员 3 或待拍板）：job 状态机与并发控制（成员 1）、`POST /jobs/{id}/cancel`（Q10 未定）、
ASR/QA（成员 4）、真实 TTS 引擎选型（Q2）、Q4 分辨率最终值。

## 分支与 PR

代码包**没有推送到 GitHub**：`github.com/liushizhang32-source/space` 在 2026-11-05 与 2026-11-07 两次访问均返回 404
（私有或地址不对），本机也没有 git 客户端和仓库凭据。

合并建议：

```bash
git checkout -b feat/generation origin/dev
# 把包内 agents/ tests/ docs/ examples/ scripts/ 及根文件覆盖进仓库对应位置
git add agents tests docs examples scripts requirements.txt .env.example README.md
git commit -m "feat(generation): story/tts/video per API v1.0 (C3/C4/A6)"
git push -u origin feat/generation
# PR: feat/generation -> dev
```

## 已知限制

1. 默认 TTS 是静音 mock（`TTS_ENGINE=silent`），视频音轨无声音，属预期。
2. 字幕为硬字幕（Pillow 渲染后 overlay），不提供外挂字幕文件。
3. 视频是“静帧 + 配音 + 字幕”，不做运镜/转场；`image_prompt` 按契约 v1 不消费。
4. 需要 ffmpeg 才能出视频；没有 ffmpeg 时页面 `partial + [no_video]`，仍返回 `story_url`。
