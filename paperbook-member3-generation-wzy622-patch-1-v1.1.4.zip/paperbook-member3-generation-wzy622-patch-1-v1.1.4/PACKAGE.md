# 成员 3 代码包 · Story / TTS / Video

| 项 | 内容 |
|---|---|
| 包名 | `paperbook-member3-generation-wzy622-patch-1-v1.1.4` |
| 版本 | v1.1.4（第五轮静态审查后备修复版） |
| 分支 | `wzy622-patch-1` |
| 打包日期 | 2026-11-08 |
| 对应契约 | `docs/API_v1.0.md`（ZSZB-API-1.0 冻结版）C3 / C4 / A6 |
| 归属 | 成员 3（Story / TTS / Video） |
| 测试 | **128 passed**（`python -m pytest`） |
| 历史版本 | v1.1.0 ～ v1.1.3 包与报告原样保留 |

## 1. 本版修复（第五轮 F01–F03）

| # | 审查意见 | 修法 | 验证 |
|---|---|---|---|
| F01 | 备份清理失败触发破坏性回滚 | 提交与清理分离；清理失败只告警不回滚 | `test_backup_cleanup_failure_does_not_rollback` |
| F02 | 回滚失败后 finally 删恢复备份 | 分步回滚、失败保留 `.bak`、抛 `VideoPublishError` 带路径 | `test_rollback_failure_keeps_recovery_backup` |
| F03 | 发布锁在回滚前释放 | 备份/提交/回滚同一页级锁内完成 | `test_rollback_lock_blocks_other_publisher` |
| P2-01 | MIME 子串误判 | 裸 MIME 精确白名单，`text/html; charset` 拒绝 | 2 例 |
| P2-05 | 断言过宽 | 模型负例改用 `ValidationError` | — |

逐条回应：`docs/REVIEW_RESPONSE.md`；报告：`docs/TEST_REPORT.md`；
历史报告：`docs/TEST_REPORT-v1.1.3.md` ～ `-v1.1.0.md`。

## 2. 包内容

```
paperbook-member3-generation-wzy622-patch-1-v1.1.4/
├── README.md / PACKAGE.md / requirements.txt / pytest.ini
├── .env.example / .gitignore
├── agents/generation/        story / tts / video / pipeline / safety / cli
├── tests/                    128 项用例
├── docs/                     实现说明、IO 示例、五轮报告、逐条回应、变更记录、Schema
├── examples/                 示例输入 + 安装脚本
├── artifacts/                实际音视频产物 + ffprobe 证据 + Schema 校验结果
└── scripts/                  verify.ps1 / verify.sh
```

**不含**：真实 API Key、`.env`、模型权重、ffmpeg 二进制、`_vendor`、缓存目录。

## 3. 环境要求

- Python 3.10+
- `ffmpeg` 与 `ffprobe`（缺失时明确 2004，不发布未验证产物）
- 依赖见 `requirements.txt`

## 4. 验证

```bash
pip install -r requirements.txt
python -m pytest                 # 128 passed

python examples/install_example.py
python -m agents.generation story --page-id book01_p03
python -m agents.generation tts   --text "从前有只小兔子，住在森林边上。"
python -m agents.generation video --page-id book01_p03
python -m agents.generation run   --page-id book01_p03
```

Windows 一键：`powershell -ExecutionPolicy Bypass -File scripts\verify.ps1`

## 5. 三个模块可独立运行

| 模块 | 命令 | 输入 | 输出 |
|---|---|---|---|
| Story | `story --page-id book01_p03` | `json/*_ocr.json`、`json/*_vlm.json` | `json/*_story.json` + 音频 |
| TTS | `tts --text "..."` / `serve --port 8001` | 文本 / HTTP JSON | `audios/tts_{hash}.mp3` + 响应 |
| Video | `video --page-id book01_p03` | `json/*_story.json` + `uploads/*_orig.*` | `videos/*.mp4` + `json/*_video.json` |

## 6. 发布语义（本版重点）

- 同进程同页写者由 `_page_lock(page_id)` 串行；跨进程未串行化，部署应保证单写进程。
- 提交点是“新 MP4 + 新 JSON 都已替换”；提交后清理失败只告警。
- 回滚失败时旧版本保留为 `.bak.<suffix>`，抛 `VideoPublishError` 给出路径；按日志重命名即可恢复。
- 双 rename 不是跨文件原子事务，读者可能短暂看到混合版本，应结合 mtime/内容判断。

## 7. 产物证据（artifacts/）

```
TTS    mp3 / 24000 Hz / mono / 4.09s            （artifacts/tts/probe.txt）
Video  h264 720x1280 + aac 44100Hz / 7.67s      （artifacts/video/probe.txt）
Story  StoryDoc 通过：status=ok、scene 非空、highlight 默认 [] 且属于本页
```

> 故事为 `mock-template`、音频为静音（`TTS_ENGINE=silent`），仅验证链路与文件有效性。

## 8. 配置（关键项）

| 变量 | 默认 | 作用 |
|---|---|---|
| `TTS_MAX_AUDIO_BYTES` | 10485760 | HTTP 音频响应大小上限 |
| `TTS_TIMEOUT_SEC` | 20 | 下载/合成超时（超时 2002） |
| `SAFETY_ENABLED` / `SAFETY_BLOCKLIST` | 0 / 空 | 统一安全开关与词表 |
| `FFMPEG_PATH` / `FFPROBE_PATH` | ffmpeg / ffprobe | 媒体生成与校验 |

CLI 启动时加载工作目录 `.env`（仅补齐未设置变量）。包里没有密钥。

## 9. 与其他人对接

- **成员 1（中枢）**：`pipeline.run_page()` 或 `run` 子命令；结果与 `pages[]` 同构（无 `stages[]`）。
- **成员 4（问答）**：只调 `POST /api/v1/tts`；不安全文本 3004。
- **成员 5（评测）**：读 `json/*_story.json`、`json/*_video.json`。

## 10. 分支与 PR

仓库 `github.com/liushizhang32-source/space` 仍 404，本机无 git，因此无真实 commit/PR；
`wzy622-patch-1` 为交付标识。合并建议（不要重复推到 `feat/generation`）：

```bash
git checkout -b wzy622-patch-1 origin/dev
git add -A
git commit -m "fix(generation): round-5 video publish transaction (commit/rollback/cleanup)"
git push -u origin wzy622-patch-1
# PR: wzy622-patch-1 -> dev
```

## 11. 已知限制

1. 发布锁仅进程内；多进程同页写需外部锁。
2. 双文件发布非跨文件原子事务（读者一致性策略已写入文档）。
3. 未接真实 TTS/LLM；产物为静音 mock + 模板故事。
4. 缓存键不区分 silent/http 来源（R112-05）。
5. 媒体元数据核对与 `stages[]` 聚合未做（R112-06/07）。
6. 无 git commit/PR（仓库不可达）。
