# 对第五轮审查（v1.1.3）意见的逐条回应 · v1.1.4

审查报告：`reports/MEMBER3_V1.1.3_REVIEW.md`（结论 B）。本轮只改发布组件与两处 P2 边界。

## F01｜提交完成后备份清理失败会触发破坏性回滚（P1）

**状态：已修复。**

- `video.py::_publish_pair` 拆成两个阶段：
  1. **提交阶段**（锁内）：旧 MP4/JSON 备份 → 提交新 MP4 → 提交新 JSON；
  2. **提交后清理**（锁外）：`_best_effort_unlink()` 逐个删备份，失败只 `logger.warning`，
     不再进入 `except`，不会回滚已提交的新版本。
- 备份删除顺序不再影响产物一致性；失败留下的 `.bak` 可人工清理。

**证据**：`test_backup_cleanup_failure_does_not_rollback`
（JSON 备份删除抛 `PermissionError` → 新 MP4/JSON 字节完整、日志有 WARNING）。

## F02｜回滚失败后 finally 仍删除恢复备份（P1）

**状态：已修复。**

- 回滚步骤逐项 `try`：删新 MP4、恢复旧 MP4、删新 JSON、恢复旧 JSON；
  失败项记入 `rollback_errors`，**不中断其余恢复步骤**。
- 回滚失败：保留现存备份，抛 `VideoPublishError`，detail 带备份路径与失败原因；
- 回滚成功：只清理本轮 `staged` / `json_tmp`；
- 删除了原来“无条件 unlink 四类文件”的 `finally`。

**证据**：`test_rollback_failure_keeps_recovery_backup`
（JSON 提交失败 + 旧 MP4 恢复失败 → `.mp4.bak.*` 保留且内容为旧版本；
错误信息包含备份路径）。

## F03｜发布锁在回滚前释放（P1）

**状态：已修复。**

- 备份、提交、回滚全部在同一个 `with _page_lock(page_id)` 内完成；
  只有提交成功或回滚结束才释放锁。
- 提交后的备份清理不需要锁（不再触碰正式文件）。
- 文档明确：锁仅覆盖**同进程同页写者**；跨进程未串行化；双 rename 不是跨文件原子事务，
  读者可能短暂看到混合版本。

**证据**：`test_rollback_lock_blocks_other_publisher`
（A 失败时启动 B；B 被锁阻塞；A 回滚完成后 B 发布；断言最终文件是 B 的字节，未被 A 覆盖）。

## P2-01｜MIME 判定不精确

**状态：已修复。**

- 取裸 MIME（`split(";")[0]`）后精确判断：
  `application/json` 或 `*+json` 才走 JSON；`audio/*`、`application/octet-stream` 走二进制；
  其他（含 `text/html`）直接拒绝；空类型仅在 body 以 `{` 开头时按 JSON 处理。
- 证据：`test_mime_with_parameters_rejected_for_html`、
  `test_mime_json_with_charset_accepted`。

## P2-05｜回归断言过宽

**状态：已修复。** v1.1.3 的模型负例已从 `pytest.raises(Exception)` 收紧为 `ValidationError`。

## 未关闭 / 后续跟踪

| 编号 | 状态 | 说明 |
|---|---|---|
| P2-02 缓存来源 | 未关闭 | silent/http 共键；切换真实引擎前建议换 `DATA_DIR` |
| P2-03 URL/环境入口 | 部分 | 已挂 `/audios`、CLI 加载 `.env`；默认 `ASSET_BASE_URL=8000` 与 8001 的关系需部署时显式配置 |
| P2-04 阶段预算/元数据 | 未关闭 | 子进程超时 ≠ 阶段预算；视频容器/音轨/尺寸核对仍有限 |
| P2-06 共享 JSON 写入 | 未改 | `storage.write_json` 仍固定 `.tmp`；本轮 Video 已绕开，Story 发布未并发化 |

## 关于测试

```
python -m pytest    # 128 passed
```

新增 `tests/test_regressions_v114.py` 5 例，其余 123 例保留；无 ffmpeg 的机器上编码相关用例会 skip。

## 明确不做

- 不接真实 TTS/LLM（不产生费用）。
- 不做多页、job 状态机、取消接口。
- 不修改公共 Schema / API 文档 / 成员二文件。
