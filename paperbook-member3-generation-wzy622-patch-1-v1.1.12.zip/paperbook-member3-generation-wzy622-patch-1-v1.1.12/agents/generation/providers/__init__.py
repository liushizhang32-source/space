"""视频 Provider 包（M3）。"""

from .base import (
    CancellationReceipt,
    ProviderCapabilities,
    ProviderResult,
    ProviderStatus,
    ProviderTask,
    VideoPlan,
)
from .wan import ProviderError, WanConfig, WanProvider

__all__ = [
    "CancellationReceipt",
    "ProviderCapabilities",
    "ProviderError",
    "ProviderResult",
    "ProviderStatus",
    "ProviderTask",
    "VideoPlan",
    "WanConfig",
    "WanProvider",
]
