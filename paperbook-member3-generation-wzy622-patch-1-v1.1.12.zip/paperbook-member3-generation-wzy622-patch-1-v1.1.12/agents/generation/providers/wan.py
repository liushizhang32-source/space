"""Wan 3.0 / 2.7 视频 Provider（阿里云百炼 DashScope 异步 API）。

官方接口要点（2026-11 文档）：
  POST https://{WorkspaceId}.{region}.maas.aliyuncs.com/api/v1/services/aigc/video-generation/video-synthesis
  Header: Authorization: Bearer <API_KEY>, X-DashScope-Async: enable
  Body: {"model": "wan3.0-video", "input": {"prompt": ..., "media": [...]}, "parameters": {...}}
  GET  https://{WorkspaceId}.{region}.maas.aliyuncs.com/api/v1/tasks/{task_id}

一段一任务；本类只返回 typed 结果，不维护 Job 状态机。
"""

from __future__ import annotations

import hashlib
import ipaddress
import json
import os
import re
import time
import urllib.error
import urllib.request
import uuid
from dataclasses import dataclass
from fnmatch import fnmatch
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from ..errors import AppError, ErrorCode
from ..execution import ExecutionContext, request_hash, utc_now
from .base import (
    CancellationReceipt,
    ProviderCapabilities,
    ProviderResult,
    ProviderStatus,
    ProviderTask,
    VideoPlan,
)

DEFAULT_REGION = "cn-beijing"
DEFAULT_MODEL = "wan3.0-video"
DEFAULT_DOWNLOAD_HOSTS: tuple[str, ...] = (
    "*.oss-accelerate.aliyuncs.com",
    "*.oss-cn-*.aliyuncs.com",
)


def validate_download_url(url: str, hosts: tuple[str, ...] = DEFAULT_DOWNLOAD_HOSTS) -> str:
    """F07：仅允许 HTTPS + 供应商域名；拒绝私网/回环/凭据/非标准协议。"""
    parsed = urlparse(url or "")
    if parsed.scheme.lower() != "https":
        raise DownloadUrlError("下载 URL 必须是 HTTPS")
    if parsed.username or parsed.password:
        raise DownloadUrlError("下载 URL 不允许内嵌凭据")
    host = (parsed.hostname or "").lower()
    if not host:
        raise DownloadUrlError("下载 URL 缺少主机名")
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        address = None
    if address is not None and (
        address.is_private
        or address.is_loopback
        or address.is_link_local
        or address.is_reserved
        or address.is_multicast
    ):
        raise DownloadUrlError("下载 URL 指向私网/回环地址", kind="security")
    if not any(fnmatch(host, pattern) for pattern in hosts):
        raise DownloadUrlError(f"下载域名不在白名单：{host}", kind="security")
    return host


class _SafeRedirect(urllib.request.HTTPRedirectHandler):
    def __init__(self, hosts: tuple[str, ...]):
        self._hosts = hosts

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        validate_download_url(newurl, self._hosts)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def redact_detail(text: str, limit: int = 300) -> str:
    """F15：诊断信息脱敏，去掉签名参数/Key，并截断。"""
    cleaned = re.sub(r"(?i)(signature|ossaccesskeyid|expires)=[^&\s]+", r"\1=***", text or "")
    cleaned = re.sub(r"sk-[A-Za-z0-9_-]+", "sk-***", cleaned)
    return cleaned[:limit]


class ProviderError(AppError):
    def __init__(
        self,
        msg: str,
        code: ErrorCode = ErrorCode.MODEL_FAILED,
        detail: str | None = None,
        *,
        kind: str = "provider_error",
    ):
        super().__init__(code, msg, detail=redact_detail(detail) if detail else None)
        self.kind = kind


class DownloadUrlError(ProviderError):
    def __init__(self, msg: str, *, kind: str = "terminal", detail: str | None = None):
        super().__init__(msg, code=ErrorCode.INVALID_PARAM, detail=detail, kind=kind)


@dataclass(frozen=True)
class WanConfig:
    api_key: str
    workspace_id: str
    region: str = DEFAULT_REGION
    model: str = DEFAULT_MODEL
    resolution: str = "720P"
    poll_interval_sec: float = 5.0
    timeout_sec: float = 900.0
    max_clip_bytes: int = 200 * 1024 * 1024
    download_hosts: tuple[str, ...] = DEFAULT_DOWNLOAD_HOSTS

    @classmethod
    def from_env(cls, env: dict[str, str] | None = None) -> "WanConfig":
        e = os.environ if env is None else env
        api_key = (e.get("WAN_API_KEY") or "").strip()
        workspace = (e.get("WAN_WORKSPACE_ID") or "").strip()
        if not api_key or not workspace:
            raise ProviderError(
                "未配置 Wan API：需要 WAN_API_KEY 与 WAN_WORKSPACE_ID",
                code=ErrorCode.UNAVAILABLE,
            )
        raw_hosts = (e.get("WAN_DOWNLOAD_HOSTS") or "").strip()
        hosts = tuple(h.strip() for h in raw_hosts.split(",") if h.strip()) or DEFAULT_DOWNLOAD_HOSTS
        return cls(
            api_key=api_key,
            workspace_id=workspace,
            region=(e.get("WAN_REGION") or DEFAULT_REGION).strip(),
            model=(e.get("WAN_MODEL") or DEFAULT_MODEL).strip(),
            resolution=(e.get("WAN_RESOLUTION") or "720P").strip(),
            poll_interval_sec=float(e.get("WAN_POLL_INTERVAL_SEC") or 5.0),
            timeout_sec=float(e.get("WAN_TIMEOUT_SEC") or 900.0),
            max_clip_bytes=int(e.get("WAN_MAX_CLIP_BYTES") or 200 * 1024 * 1024),
            download_hosts=hosts,
        )

    @property
    def base_url(self) -> str:
        return f"https://{self.workspace_id}.{self.region}.maas.aliyuncs.com"

    @property
    def submit_url(self) -> str:
        return f"{self.base_url}/api/v1/services/aigc/video-generation/video-synthesis"

    def poll_url(self, task_id: str) -> str:
        return f"{self.base_url}/api/v1/tasks/{task_id}"

    def cancel_url(self, task_id: str) -> str:
        return f"{self.base_url}/api/v1/tasks/{task_id}/cancel"


class WanProvider:
    name = "wan"
    capabilities = ProviderCapabilities(cancel="unknown", idempotent_submit="unknown")

    def __init__(self, config: WanConfig, *, opener=urllib.request.urlopen):
        self.config = config
        self._opener = opener

    # ---- 提交 ----
    def submit(
        self,
        plan: VideoPlan,
        image_url: str,
        *,
        safety_check=None,
        execution: ExecutionContext | None = None,
        idempotency_key: str | None = None,
    ) -> ProviderTask:
        if safety_check is not None:
            safety_check(plan.prompt)
        # Wan3.0 约束：first_frame/last_frame 与 reference_image 互斥，不能混用。
        # 无角色参考图 -> 首帧模式（保持书页原貌）；有参考图 -> 全模态参考模式。
        prompt = plan.prompt
        if plan.reference_image_urls:
            media = [{"type": "reference_image", "url": image_url}]
            media.extend({"type": "reference_image", "url": url} for url in plan.reference_image_urls)
            prompt = "图1为绘本页面，后续图片为角色参考。请保持参考角色外观一致。" + prompt
        else:
            media = [{"type": "first_frame", "url": image_url}]

        duration = max(2, min(30, int(round(plan.target_duration_sec))))
        body = {
            "model": self.config.model,
            "input": {"prompt": prompt, "media": media},
            "parameters": {
                "duration": duration,
                "resolution": self.config.resolution,
                "ratio": "adaptive",
                "prompt_extend": True,
                # 我们用自己的 TTS，禁止供应商再生成一条音轨
                "audio": False,
            },
        }
        digest = request_hash(body)
        key = idempotency_key
        if key is None and execution is not None:
            key = execution.segment_key(plan.segment_id)
        raw = self._request_json(
            self.config.submit_url,
            method="POST",
            payload=body,
            extra_headers={"X-DashScope-Async": "enable"},
        )
        output = raw.get("output") or {}
        task_id = output.get("task_id") or raw.get("task_id")
        if not task_id:
            raise ProviderError(
                "Wan 创建任务未返回 task_id",
                kind="unknown",
                detail=json.dumps(raw, ensure_ascii=False),
            )
        return ProviderTask(
            task_id=str(task_id),
            provider=self.name,
            model=self.config.model,
            raw=raw,
            request_hash=digest,
            idempotency_key=key or "",
            fence=execution.fence if execution else "",
        )

    # ---- 轮询 ----
    def poll(self, task_id: str) -> ProviderResult:
        raw = self._request_json(self.config.poll_url(task_id), method="GET")
        output = raw.get("output") or {}
        state = str(output.get("task_status") or raw.get("task_status") or "").upper()
        observed = utc_now()
        if state in {"PENDING", "QUEUED"}:
            return ProviderResult(ProviderStatus.QUEUED, raw=raw, observed_at=observed)
        if state in {"RUNNING", "PROCESSING"}:
            return ProviderResult(ProviderStatus.RUNNING, raw=raw, observed_at=observed)
        if state in {"SUCCEEDED", "SUCCESS"}:
            video_url = (
                output.get("video_url")
                or (output.get("results") or [{}])[0].get("url")
                or raw.get("video_url")
            )
            if not video_url:
                return ProviderResult(
                    ProviderStatus.FAILED,
                    error_code="missing_video_url",
                    error_message="Wan 任务成功但没有 video_url",
                    raw=raw,
                    observed_at=observed,
                )
            return ProviderResult(ProviderStatus.SUCCEEDED, video_url=str(video_url), raw=raw, observed_at=observed)
        if state in {"CANCELED", "CANCELLED"}:
            return ProviderResult(ProviderStatus.CANCELLED, raw=raw, observed_at=observed)
        if state in {"FAILED", "ERROR"}:
            return ProviderResult(
                ProviderStatus.FAILED,
                error_code=str(output.get("code") or "task_failed"),
                error_message=str(output.get("message") or state),
                raw=raw,
                observed_at=observed,
            )
        # F15：未知新状态不能伪造成终态 failed；交给 M1 对账
        return ProviderResult(
            ProviderStatus.UNKNOWN,
            error_code=str(output.get("code") or "unknown_state"),
            error_message=str(output.get("message") or state or "unknown"),
            raw=raw,
            observed_at=observed,
        )

    def wait(self, task_id: str) -> ProviderResult:
        deadline = time.monotonic() + self.config.timeout_sec
        while time.monotonic() < deadline:
            result = self.poll(task_id)
            if result.status in {
                ProviderStatus.SUCCEEDED,
                ProviderStatus.FAILED,
                ProviderStatus.CANCELLED,
                ProviderStatus.UNKNOWN,
            }:
                return result
            time.sleep(self.config.poll_interval_sec)
        raise ProviderError("Wan 任务轮询超时", code=ErrorCode.TIMEOUT, kind="timeout")

    # ---- 取消 ----
    def cancel(self, task_id: str) -> CancellationReceipt:
        requested = utc_now()
        try:
            raw = self._request_json(self.config.cancel_url(task_id), method="POST", payload={})
        except ProviderError as exc:
            if exc.kind == "unsupported":
                return CancellationReceipt(
                    ProviderStatus.UNKNOWN,
                    requested_at=requested,
                    raw_status="unsupported",
                    supported=False,
                    detail=exc.msg,
                )
            return CancellationReceipt(
                ProviderStatus.UNKNOWN,
                requested_at=requested,
                raw_status="unknown",
                supported=True,
                detail=exc.msg,
            )

        output = raw.get("output") or {}
        state = str(output.get("task_status") or "").upper()
        if state in {"CANCELED", "CANCELLED"}:
            return CancellationReceipt(
                ProviderStatus.CANCELLED,
                requested_at=requested,
                confirmed_at=utc_now(),
                raw_status=state,
            )
        # 请求被接受但任务未终止：不能宣称已终止
        return CancellationReceipt(
            ProviderStatus.UNKNOWN,
            requested_at=requested,
            raw_status=state or "accepted",
            supported=True,
            detail="cancel accepted but backend terminal state not confirmed",
        )

    # ---- 下载 ----
    def download(self, video_url: str, dest: Path) -> tuple[Path, str]:
        validate_download_url(video_url, self.config.download_hosts)
        dest.parent.mkdir(parents=True, exist_ok=True)
        part = dest.with_name(f"{dest.name}.{uuid.uuid4().hex[:8]}.part")
        digest = hashlib.sha256()
        total = 0
        request = urllib.request.Request(video_url, method="GET")
        opener = self._opener
        if opener is urllib.request.urlopen:
            opener = urllib.request.build_opener(_SafeRedirect(self.config.download_hosts)).open
        try:
            with opener(request, timeout=self.config.timeout_sec) as response:
                headers = getattr(response, "headers", None)
                content_type = (headers.get("Content-Type", "") if headers else "").lower()
                if content_type and not (
                    content_type.startswith("video/") or "application/octet-stream" in content_type
                ):
                    raise ProviderError("Wan 下载响应不是视频类型", kind="terminal")
                with part.open("wb") as handle:
                    while True:
                        chunk = response.read(1 << 20)
                        if not chunk:
                            break
                        total += len(chunk)
                        if total > self.config.max_clip_bytes:
                            raise ProviderError("Wan 视频超过大小上限", code=ErrorCode.INVALID_PARAM)
                        digest.update(chunk)
                        handle.write(chunk)
        except ProviderError:
            part.unlink(missing_ok=True)
            raise
        except urllib.error.HTTPError as exc:
            part.unlink(missing_ok=True)
            raise ProviderError(f"下载 Wan 视频失败：HTTP {exc.code}", code=ErrorCode.MODEL_FAILED) from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            part.unlink(missing_ok=True)
            raise ProviderError("下载 Wan 视频超时或网络失败", code=ErrorCode.TIMEOUT, detail=str(exc)) from exc

        try:
            if part.stat().st_size == 0:
                raise ProviderError("Wan 视频为空", code=ErrorCode.MODEL_FAILED)
            with part.open("rb") as handle:
                head = handle.read(12)
            if b"ftyp" not in head[4:12]:
                raise ProviderError("Wan 下载内容不是有效 MP4", code=ErrorCode.INVALID_PARAM, kind="terminal")
            os.replace(part, dest)
        except ProviderError:
            part.unlink(missing_ok=True)
            raise
        return dest, digest.hexdigest()

    # ---- HTTP ----
    def _request_json(
        self,
        url: str,
        *,
        method: str,
        payload: dict | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> dict:
        headers = {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json",
        }
        if extra_headers:
            headers.update(extra_headers)
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8") if payload is not None else None
        request = urllib.request.Request(url, data=data, headers=headers, method=method)
        try:
            with self._opener(request, timeout=self.config.timeout_sec) as response:
                raw = response.read()
                return json.loads(raw.decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = redact_detail(exc.read(600).decode("utf-8", "replace"))
            if exc.code == 429:
                raise ProviderError("Wan 触发限流", code=ErrorCode.RATE_LIMITED, detail=detail, kind="rate_limited") from exc
            if exc.code in (401, 403):
                raise ProviderError("Wan 鉴权失败", code=ErrorCode.UNAVAILABLE, detail=detail, kind="auth") from exc
            if exc.code == 400 and "UnsupportedOperation" in detail:
                raise ProviderError("Wan 不支持取消该任务", code=ErrorCode.INVALID_PARAM, detail=detail, kind="unsupported") from exc
            if exc.code == 404:
                raise ProviderError("Wan 任务不存在", code=ErrorCode.NOT_FOUND, detail=detail, kind="unknown") from exc
            if exc.code >= 500:
                raise ProviderError(f"Wan 返回 HTTP {exc.code}", code=ErrorCode.MODEL_FAILED, detail=detail, kind="transient") from exc
            raise ProviderError(f"Wan 返回 HTTP {exc.code}", code=ErrorCode.MODEL_FAILED, detail=detail, kind="terminal") from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise ProviderError("Wan 网络不可达或超时", code=ErrorCode.TIMEOUT, detail=str(exc), kind="timeout") from exc
        except json.JSONDecodeError as exc:
            raise ProviderError("Wan 返回了非 JSON 响应", code=ErrorCode.MODEL_FAILED, kind="terminal") from exc
