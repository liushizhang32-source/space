"""视频供应商中立接口（M3 提供，M1 驱动任务与持久化）。"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class ProviderStatus(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class ProviderCapabilities:
    """供应商能力声明：不能把“客户端退出”当成后端终止。"""

    cancel: str = "unknown"  # supported / unsupported / unknown
    idempotent_submit: str = "unknown"


@dataclass(frozen=True)
class CancellationReceipt:
    status: ProviderStatus
    requested_at: str
    confirmed_at: str | None = None
    raw_status: str = ""
    supported: bool = True
    detail: str = ""

    @property
    def confirmed(self) -> bool:
        return self.status is ProviderStatus.CANCELLED and bool(self.confirmed_at)


@dataclass(frozen=True)
class VideoPlan:
    """一个 Story Segment 对应的动态视频计划（v1.1 内部结构）。"""

    segment_id: str
    prompt: str
    target_duration_sec: float
    reference_image_urls: list[str] = field(default_factory=list)
    character_keys: list[str] = field(default_factory=list)
    aspect_ratio: str = "9:16"


@dataclass(frozen=True)
class ProviderTask:
    task_id: str
    provider: str
    model: str
    raw: dict = field(default_factory=dict)
    request_hash: str = ""
    idempotency_key: str = ""
    fence: str = ""
    generation: int = 0
    attempt: int = 1


@dataclass(frozen=True)
class ProviderResult:
    status: ProviderStatus
    video_url: str | None = None
    error_code: str | None = None
    error_message: str | None = None
    raw: dict = field(default_factory=dict)
    observed_at: str = ""
    retryable: bool = False
