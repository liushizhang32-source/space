"""Fake 视频 Provider：实现与 Wan 相同的提交/查询/取消/资产交接接口。"""

from __future__ import annotations

import hashlib
import shutil
from dataclasses import dataclass, field
from pathlib import Path

from ..errors import AppError, ErrorCode
from ..execution import ExecutionContext, utc_now
from .base import (
    CancellationReceipt,
    ProviderCapabilities,
    ProviderResult,
    ProviderStatus,
    ProviderTask,
    VideoPlan,
)


@dataclass
class _FakeTask:
    task_id: str
    plan: VideoPlan
    status: ProviderStatus
    source: Path
    error_code: str | None = None
    error_message: str | None = None


@dataclass
class FakeVideoProvider:
    """确定性 Fake：不联网、不收费；可注入前 N 次失败。"""

    sources: list[Path]
    fail_submits: int = 0
    name: str = "fake"
    model: str = "fake-video-v1"
    capabilities: ProviderCapabilities = field(
        default_factory=lambda: ProviderCapabilities(cancel="supported", idempotent_submit="supported")
    )
    _tasks: dict[str, _FakeTask] = field(default_factory=dict)
    _counter: int = 0

    def submit(
        self,
        plan: VideoPlan,
        image_url: str,
        *,
        safety_check=None,
        execution: ExecutionContext | None = None,
        idempotency_key: str | None = None,
    ) -> ProviderTask:
        if safety_check is not None:
            safety_check(plan.prompt)
        self._counter += 1
        failed = self._counter <= self.fail_submits
        task_id = f"fake-{self._counter:04d}"
        source = self.sources[(self._counter - 1) % len(self.sources)]
        task = _FakeTask(
            task_id=task_id,
            plan=plan,
            status=ProviderStatus.FAILED if failed else ProviderStatus.QUEUED,
            source=source,
            error_code="transient_failure" if failed else None,
            error_message="fake transient failure" if failed else None,
        )
        self._tasks[task_id] = task
        return ProviderTask(
            task_id=task_id,
            provider=self.name,
            model=self.model,
            request_hash=hashlib.sha256(f"{plan.segment_id}|{image_url}".encode()).hexdigest(),
            idempotency_key=idempotency_key or "",
            fence=execution.fence if execution else "",
            generation=execution.generation if execution else 0,
            attempt=execution.attempt if execution else self._counter,
        )

    def poll(self, task_id: str) -> ProviderResult:
        task = self._tasks.get(task_id)
        if task is None:
            return ProviderResult(ProviderStatus.UNKNOWN, error_code="not_found")
        if task.status is ProviderStatus.QUEUED:
            task.status = ProviderStatus.RUNNING
        elif task.status is ProviderStatus.RUNNING:
            task.status = ProviderStatus.SUCCEEDED
        return ProviderResult(
            task.status,
            video_url=f"fake://{task_id}" if task.status is ProviderStatus.SUCCEEDED else None,
            error_code=task.error_code,
            error_message=task.error_message,
        )

    def wait(self, task_id: str) -> ProviderResult:
        return self.poll(task_id)

    def cancel(self, task_id: str) -> CancellationReceipt:
        task = self._tasks.get(task_id)
        requested = utc_now()
        if task is None:
            return CancellationReceipt(ProviderStatus.UNKNOWN, requested_at=requested, supported=False)
        if task.status in {ProviderStatus.SUCCEEDED, ProviderStatus.FAILED}:
            return CancellationReceipt(ProviderStatus.UNKNOWN, requested_at=requested, supported=False)
        task.status = ProviderStatus.CANCELLED
        return CancellationReceipt(
            ProviderStatus.CANCELLED,
            requested_at=requested,
            confirmed_at=utc_now(),
            raw_status="CANCELED",
        )

    def download(self, video_url: str, dest: Path) -> tuple[Path, str]:
        task_id = video_url.removeprefix("fake://")
        task = self._tasks.get(task_id)
        if task is None:
            raise AppError(ErrorCode.NOT_FOUND, "fake task 不存在")
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(task.source, dest)
        digest = hashlib.sha256(dest.read_bytes()).hexdigest()
        return dest, digest
