"""可信来源与审核状态（F01/F02/F11 的共用基础）。

- GenerationMode：mock / local_test / hybrid_test / real_video
- SourceKind：fixture / static / local_model / ai_video
- SafetyReview / MediaReview：显式审核状态，未审不得发布
- Provenance：Provider 对 task/clip hash 的 HMAC 签名，防止调用方自报真实
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum


class GenerationMode(str, Enum):
    MOCK = "mock"
    LOCAL_TEST = "local_test"
    HYBRID_TEST = "hybrid_test"
    REAL_VIDEO = "real_video"


class SourceKind(str, Enum):
    FIXTURE = "fixture"
    STATIC = "static"
    LOCAL_MODEL = "local_model"
    AI_VIDEO = "ai_video"


class SafetyDecision(str, Enum):
    UNREVIEWED = "unreviewed"
    REJECTED = "rejected"
    PASSED = "passed"


@dataclass(frozen=True)
class SafetyReview:
    decision: SafetyDecision
    reviewer: str
    reviewed_at: str
    flags: tuple[str, ...] = ()
    content_sha256: str = ""

    @property
    def ok(self) -> bool:
        return self.decision is SafetyDecision.PASSED and not self.flags and bool(self.content_sha256)


@dataclass(frozen=True)
class MediaReview:
    passed: bool
    reviewer: str
    reviewed_at: str
    subject_sha256: str = ""

    @property
    def ok(self) -> bool:
        return self.passed and bool(self.subject_sha256)


def story_digest(story: dict) -> str:
    """审核对象摘要：绑定故事内容，排除 elapsed_ms 等易变字段。"""
    stable = {key: value for key, value in story.items() if key != "elapsed_ms"}
    return hashlib.sha256(
        json.dumps(stable, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def clips_digest(clip_hashes: dict[str, str]) -> str:
    """媒体审核对象摘要：绑定本页所有 clip 的 hash。"""
    return hashlib.sha256(_canonical(dict(sorted(clip_hashes.items())))).hexdigest()


def _canonical(payload: dict) -> bytes:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sign_provenance(
    *,
    provider: str,
    model: str,
    task_ids: dict[str, str],
    clip_hashes: dict[str, str],
    secret: str,
    issued_at: str | None = None,
) -> "Provenance":
    issued = issued_at or datetime.now(timezone.utc).isoformat(timespec="seconds")
    payload = {
        "provider": provider,
        "model": model,
        "task_ids": dict(sorted(task_ids.items())),
        "clip_hashes": dict(sorted(clip_hashes.items())),
        "issued_at": issued,
    }
    signature = hmac.new(secret.encode("utf-8"), _canonical(payload), hashlib.sha256).hexdigest()
    return Provenance(
        provider=provider,
        model=model,
        task_ids=dict(task_ids),
        clip_hashes=dict(clip_hashes),
        issued_at=issued,
        signature=signature,
    )


@dataclass(frozen=True)
class Provenance:
    provider: str
    model: str
    task_ids: dict[str, str]
    clip_hashes: dict[str, str]
    issued_at: str
    signature: str

    def verify(self, secret: str) -> bool:
        if not secret:
            return False
        expected = sign_provenance(
            provider=self.provider,
            model=self.model,
            task_ids=self.task_ids,
            clip_hashes=self.clip_hashes,
            secret=secret,
            issued_at=self.issued_at,
        )
        return hmac.compare_digest(expected.signature, self.signature)


def provenance_secret(env: dict[str, str] | None = None) -> str:
    values = os.environ if env is None else env
    return (values.get("VIDEO_PROVENANCE_SECRET") or "").strip()
