"""F08：真实 POC 授权/预算门禁。

负责人签发 token，至少绑定：用途、地域、次数、总时长、费用上限、截止时间。
没有 token/超限/过期一律拒绝；API Key 本身不构成授权。
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import time
import urllib.request
from dataclasses import asdict, dataclass


class PocGateError(Exception):
    pass


@dataclass(frozen=True)
class PocApproval:
    approved_by: str
    purpose: str
    region: str
    max_calls: int
    max_seconds: float
    max_cost_usd: float
    expires_at: int
    input_sha256: str = ""

    def payload(self) -> dict:
        return asdict(self)


def _canonical(payload: dict) -> bytes:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def issue_approval(approval: PocApproval, secret: str) -> str:
    body = _canonical(approval.payload())
    signature = hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
    token = base64.urlsafe_b64encode(body).decode("ascii").rstrip("=")
    return f"{token}.{signature}"


def parse_approval(token: str, secret: str) -> PocApproval:
    try:
        encoded, signature = token.split(".", 1)
        padded = encoded + "=" * (-len(encoded) % 4)
        body = base64.urlsafe_b64decode(padded.encode("ascii"))
        expected = hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, signature):
            raise PocGateError("POC 授权签名无效")
        data = json.loads(body.decode("utf-8"))
        return PocApproval(**data)
    except PocGateError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise PocGateError(f"POC 授权 token 无法解析：{exc}") from exc


def assert_allowed(
    approval: PocApproval,
    *,
    region: str,
    calls: int,
    seconds: float,
    estimated_cost_usd: float | None = None,
    actual_input_sha256: str | None = None,
    now: int | None = None,
) -> None:
    current = int(time.time()) if now is None else now
    if approval.expires_at <= current:
        raise PocGateError("POC 授权已过期")
    if approval.region != region:
        raise PocGateError(f"POC 授权地域不匹配：{approval.region} != {region}")
    if calls < 1 or calls > approval.max_calls:
        raise PocGateError(f"POC 调用次数超出授权：{calls} > {approval.max_calls}")
    if seconds <= 0 or seconds > approval.max_seconds:
        raise PocGateError(f"POC 时长超出授权：{seconds} > {approval.max_seconds}")
    if estimated_cost_usd is not None and estimated_cost_usd > approval.max_cost_usd:
        raise PocGateError(f"POC 费用超出授权：{estimated_cost_usd} > {approval.max_cost_usd}")
    if actual_input_sha256 is not None:
        if not approval.input_sha256:
            raise PocGateError("POC 授权未绑定输入素材 SHA256，拒绝真实 submit")
        if not hmac.compare_digest(approval.input_sha256.lower(), actual_input_sha256.lower()):
            raise PocGateError("实际输入素材 SHA256 与授权不一致")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def fetch_input_sha256(url: str, *, max_bytes: int = 20 * 1024 * 1024, opener=urllib.request.urlopen) -> str:
    """下载输入素材并计算 SHA256；仅 HTTPS、大小受限；不落盘。"""
    if not (url or "").lower().startswith("https://"):
        raise PocGateError("输入素材必须是 HTTPS URL")
    request = urllib.request.Request(url, method="GET")
    digest = hashlib.sha256()
    total = 0
    try:
        with opener(request, timeout=60) as response:
            while True:
                chunk = response.read(1 << 20)
                if not chunk:
                    break
                total += len(chunk)
                if total > max_bytes:
                    raise PocGateError("输入素材超过大小上限")
                digest.update(chunk)
    except PocGateError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise PocGateError(f"读取输入素材失败：{exc}") from exc
    if total == 0:
        raise PocGateError("输入素材为空")
    return digest.hexdigest()


def require_approval_from_env(
    *,
    region: str,
    calls: int,
    seconds: float,
    estimated_cost_usd: float | None = None,
    actual_input_sha256: str | None = None,
    env: dict[str, str] | None = None,
    now: int | None = None,
) -> PocApproval:
    values = os.environ if env is None else env
    token = (values.get("POC_APPROVAL_TOKEN") or "").strip()
    secret = (values.get("POC_APPROVAL_SECRET") or "").strip()
    if not token or not secret:
        raise PocGateError("缺少 POC_APPROVAL_TOKEN / POC_APPROVAL_SECRET，拒绝真实 submit")
    approval = parse_approval(token, secret)
    assert_allowed(
        approval,
        region=region,
        calls=calls,
        seconds=seconds,
        estimated_cost_usd=estimated_cost_usd,
        actual_input_sha256=actual_input_sha256,
        now=now,
    )
    return approval
