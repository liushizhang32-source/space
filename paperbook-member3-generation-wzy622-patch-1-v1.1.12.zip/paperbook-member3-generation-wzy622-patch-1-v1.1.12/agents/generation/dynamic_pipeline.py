"""F03：动态执行适配器（两阶段，离线可测）。

阶段 1 prepare：Story/TTS + Planner，产出可审核的 VideoPlan；
阶段 2 generate：逐段 Provider submit/poll/download；
阶段 3 compose：人工媒体审核通过后，用动态合成发布。
默认 CLI 仍走 mock_static，不把动态路径混进旧入口。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from types import SimpleNamespace

from .config import Settings
from .errors import AppError, ErrorCode
from .execution import ExecutionContext
from .providers.base import ProviderResult, ProviderStatus, VideoPlan
from .story.builder import build_page_story
from .story.planner import CharacterRegistry, plan_segments
from .schemas import StoryDoc
from .trust import GenerationMode, MediaReview, SafetyReview, story_digest
from .video_dynamic import compose_dynamic_video
from .video import VideoResult


@dataclass
class PreparedDynamicPage:
    page_id: str
    story: dict
    plans: list[VideoPlan]
    safety_digest: str
    story_path: Path


@dataclass
class GeneratedDynamicPage:
    page_id: str
    story: dict
    plans: list[VideoPlan]
    clips: dict[str, Path] = field(default_factory=dict)
    task_refs: dict[str, str] = field(default_factory=dict)


def prepare_dynamic_page(
    page_id: str,
    age_level: str,
    settings: Settings,
    *,
    ocr: dict | None = None,
    vlm: dict | None = None,
    tts_client=None,
    registry: CharacterRegistry | None = None,
    preserve_page: bool = True,
) -> PreparedDynamicPage:
    story_result = build_page_story(
        page_id,
        age_level,
        settings,
        tts_client=tts_client,
        ocr=ocr,
        vlm=vlm,
    )
    story = story_result.doc
    story_doc = StoryDoc.model_validate(story)
    segments = [
        SimpleNamespace(
            segment_id=item["segment_id"],
            narration=item["narration"],
            scene=item["scene"],
            duration_sec=item["duration_sec"],
        )
        for item in story["segments"]
    ]
    plans = plan_segments(
        segments,
        list((vlm or {}).get("objects") or []),
        registry=registry,
        age_level=age_level,
        preserve_page=preserve_page,
        continuity=True,
        settings=settings,
    )
    return PreparedDynamicPage(
        page_id=page_id,
        story=story,
        plans=plans,
        safety_digest=story_digest(story_doc.model_dump(mode="json")),
        story_path=settings.json_dir / f"{page_id}_story.json",
    )


def generate_dynamic_clips(
    prepared: PreparedDynamicPage,
    provider,
    image_url: str,
    settings: Settings,
    *,
    safety_review: SafetyReview,
    execution: ExecutionContext | None = None,
) -> GeneratedDynamicPage:
    """生成前必须先有与 Story 内容绑定的安全审核。"""
    if not safety_review.ok or safety_review.content_sha256 != prepared.safety_digest:
        raise AppError(ErrorCode.SAFETY_BLOCKED, "动态生成缺少匹配的安全审核")

    clip_dir = settings.data_dir / "clips"
    clip_dir.mkdir(parents=True, exist_ok=True)
    generated = GeneratedDynamicPage(prepared.page_id, prepared.story, prepared.plans)
    for plan in prepared.plans:
        task = provider.submit(plan, image_url, execution=execution)
        result: ProviderResult = provider.wait(task.task_id)
        if result.status is not ProviderStatus.SUCCEEDED or not result.video_url:
            raise AppError(ErrorCode.VIDEO_FAILED, f"segment {plan.segment_id} 生成失败")
        dest = clip_dir / f"{plan.segment_id}_c01.mp4"
        provider.download(result.video_url, dest)
        generated.clips[plan.segment_id] = dest
        generated.task_refs[plan.segment_id] = task.task_id
    return generated


def compose_generated(
    generated: GeneratedDynamicPage,
    settings: Settings,
    *,
    safety_review: SafetyReview,
    media_review: MediaReview,
    generation_mode: GenerationMode | str = GenerationMode.LOCAL_TEST,
) -> VideoResult:
    return compose_dynamic_video(
        generated.page_id,
        generated.story,
        generated.clips,
        settings,
        generation_mode=generation_mode,
        safety_review=safety_review,
        media_review=media_review,
        provider="wan",
        model="wan3.0-video-prime",
        task_refs=generated.task_refs,
    )


def run_dynamic_page(
    page_id: str,
    age_level: str,
    settings: Settings,
    image_url: str,
    provider,
    *,
    safety_review: SafetyReview,
    media_review_factory,
    execution: ExecutionContext | None = None,
    ocr: dict | None = None,
    vlm: dict | None = None,
    registry: CharacterRegistry | None = None,
    generation_mode: GenerationMode | str = GenerationMode.LOCAL_TEST,
) -> VideoResult:
    """视频生成接口适配：prepare → generate → 人工审核 → compose。

    media_review_factory(clips) 必须在看到实际 clip 后返回 MediaReview；
    不接受调用方提前伪造媒体审核。
    """
    prepared = prepare_dynamic_page(
        page_id,
        age_level,
        settings,
        ocr=ocr,
        vlm=vlm,
        registry=registry,
        preserve_page=True,
    )
    generated = generate_dynamic_clips(
        prepared,
        provider,
        image_url,
        settings,
        safety_review=safety_review,
        execution=execution,
    )
    review = media_review_factory(generated.clips)
    if not isinstance(review, MediaReview):
        raise AppError(ErrorCode.SAFETY_BLOCKED, "媒体审核工厂未返回 MediaReview")
    return compose_generated(
        generated,
        settings,
        safety_review=safety_review,
        media_review=review,
        generation_mode=generation_mode,
    )
