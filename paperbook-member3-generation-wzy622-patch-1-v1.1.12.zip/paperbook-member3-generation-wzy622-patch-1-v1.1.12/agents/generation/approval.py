"""M1 签发、M3 只验证的 POC 授权 Token（技术准备版）。

设计约束：
- Secret 只在 M1/负责人侧；M3 源码、日志、环境不保存 secret；
- M3 不本地校验 HMAC，只把 token 交给 M1 验证接口；
- M3 可解析未签名 claims 用于展示/日志，但不得据此放行；
- 防篡改、过期、重复使用（jti）、素材 hash 不匹配由 M1 验证端负责。
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
import urllib.request
from dataclasses import asdict, dataclass
from typing import Protocol


class ApprovalError(Exception):
    pass


@dataclass(frozen=True)
class ApprovalClaims:
    jti: str
    issued_at: int
    expires_at: int
    purpose: str
    asset_sha256: str
    budget_id: str
    approved_by: str
    max_calls: int
    max_seconds: float
    max_cost_cny: float
    version: str = "1.0"
    region: str = "cn-beijing"

    def validate_shape(self) -> None:
        if not self.jti or not self.purpose or not self.budget_id or not self.approved_by:
            raise ApprovalError("token 缺少 jti/purpose/budget_id/approved_by")
        if not self.version or not self.region:
            raise ApprovalError("token 缺少 version/region")
        if len(self.asset_sha256) != 64:
            raise ApprovalError("asset_sha256 必须是 64 位十六进制")
        if self.expires_at <= self.issued_at:
            raise ApprovalError("expires_at 必须晚于 issued_at")
        if self.max_calls < 1 or self.max_seconds <= 0 or self.max_cost_cny <= 0:
            raise ApprovalError("token 额度字段非法")


@dataclass(frozen=True)
class VerifiedApproval:
    claims: ApprovalClaims
    verified_at: int
    verifier: str


def _canonical(claims: dict) -> bytes:
    return json.dumps(claims, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def issue_token(claims: ApprovalClaims, secret: str) -> str:
    """仅 M1/负责人使用；M3 不调用。"""
    claims.validate_shape()
    body = _canonical(asdict(claims))
    signature = hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
    encoded = base64.urlsafe_b64encode(body).decode("ascii").rstrip("=")
    return f"{encoded}.{signature}"


def parse_token_untrusted(token: str) -> ApprovalClaims:
    """M3 只读查看；结果不可用于放行。"""
    try:
        encoded, _ = token.split(".", 1)
        padded = encoded + "=" * (-len(encoded) % 4)
        data = json.loads(base64.urlsafe_b64decode(padded.encode("ascii")))
        return ApprovalClaims(**data)
    except Exception as exc:  # noqa: BLE001
        raise ApprovalError(f"token 无法解析：{exc}") from exc


class ApprovalVerifier(Protocol):
    """M1 侧验证接口；M3 只依赖协议。"""

    def verify(self, token: str, *, asset_sha256: str, purpose: str, now: int | None = None) -> VerifiedApproval:
        ...


class M1ApprovalClient:
    """M1 的验证 HTTP 客户端；M3 不持有 secret。"""

    def __init__(self, base_url: str, *, opener=urllib.request.urlopen):
        self.base_url = base_url.rstrip("/")
        self._opener = opener

    def verify(self, token: str, *, asset_sha256: str, purpose: str, region: str | None = None, now: int | None = None) -> VerifiedApproval:
        payload = json.dumps(
            {"token": token, "asset_sha256": asset_sha256, "purpose": purpose, "region": region, "at": now},
            ensure_ascii=False,
        ).encode("utf-8")
        request = urllib.request.Request(
            f"{self.base_url}/internal/approvals/verify",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with self._opener(request, timeout=30) as response:
                data = json.loads(response.read().decode("utf-8"))
        except Exception as exc:  # noqa: BLE001
            raise ApprovalError(f"M1 授权验证失败：{exc}") from exc
        if not data.get("ok"):
            raise ApprovalError(str(data.get("message") or "M1 拒绝授权"))
        claims = ApprovalClaims(**data["claims"])
        claims.validate_shape()
        return VerifiedApproval(claims=claims, verified_at=int(data.get("verified_at") or time.time()), verifier="m1")


class FakeApprovalVerifier:
    """仅测试/Fake 使用：模拟 M1 的签名、过期、jti 重放、素材 hash 校验。"""

    def __init__(self, secret: str):
        self._secret = secret
        self._used_jti: set[str] = set()

    def verify(self, token: str, *, asset_sha256: str, purpose: str, region: str | None = None, now: int | None = None) -> VerifiedApproval:
        current = int(time.time()) if now is None else now
        try:
            encoded, signature = token.split(".", 1)
            padded = encoded + "=" * (-len(encoded) % 4)
            body = base64.urlsafe_b64decode(padded.encode("ascii"))
            expected = hmac.new(self._secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
            if not hmac.compare_digest(expected, signature):
                raise ApprovalError("token 签名无效（可能被篡改）")
            claims = ApprovalClaims(**json.loads(body.decode("utf-8")))
        except ApprovalError:
            raise
        except Exception as exc:  # noqa: BLE001
            raise ApprovalError(f"token 解析失败：{exc}") from exc

        claims.validate_shape()
        if claims.expires_at <= current:
            raise ApprovalError("token 已过期")
        if claims.issued_at > current + 60:
            raise ApprovalError("token issued_at 在未来")
        if claims.purpose != purpose:
            raise ApprovalError("token purpose 不匹配")
        if region is not None and claims.region != region:
            raise ApprovalError("token region 不匹配")
        if claims.asset_sha256.lower() != asset_sha256.lower():
            raise ApprovalError("素材 SHA256 与 token 不匹配")
        if claims.jti in self._used_jti:
            raise ApprovalError("token 已被使用（jti 重放）")
        self._used_jti.add(claims.jti)
        return VerifiedApproval(claims=claims, verified_at=current, verifier="fake-m1")
