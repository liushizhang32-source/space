"""三件套原子发布：mp4 + video.json + assets.json（F06 的离线实现）。

这不是 M1 的最终发布门禁；M3 只保证自己的候选资产要么三件齐全，要么全部回滚。
"""

from __future__ import annotations

import os
import threading
import uuid
from pathlib import Path

from .errors import VideoPublishError

_locks: dict[str, threading.Lock] = {}
_locks_guard = threading.Lock()


def _lock_for(page_id: str) -> threading.Lock:
    with _locks_guard:
        return _locks.setdefault(page_id, threading.Lock())


def publish_bundle(page_id: str, targets: dict[Path, Path]) -> None:
    """按 target -> staged 映射原子发布；任一步失败全部回滚。"""
    if not targets:
        raise VideoPublishError("没有可发布的动态视频文件")
    for target, staged in targets.items():
        if not staged.is_file() or staged.stat().st_size == 0:
            raise VideoPublishError(f"暂存文件缺失或为空：{staged}")

    lock = _lock_for(page_id)
    with lock:
        backups: dict[Path, Path] = {}
        committed: list[Path] = []
        try:
            for target, staged in targets.items():
                target.parent.mkdir(parents=True, exist_ok=True)
                if target.exists():
                    backup = target.with_name(f"{target.name}.bak.{uuid.uuid4().hex[:8]}")
                    os.replace(target, backup)
                    backups[target] = backup
                os.replace(staged, target)
                committed.append(target)
        except OSError as exc:
            for target in reversed(committed):
                try:
                    target.unlink(missing_ok=True)
                except OSError:
                    pass
            for target, backup in backups.items():
                try:
                    if backup.exists():
                        os.replace(backup, target)
                except OSError:
                    pass
            raise VideoPublishError("动态视频发布失败，已回滚", detail=str(exc)) from exc

        for backup in backups.values():
            try:
                backup.unlink(missing_ok=True)
            except OSError:
                pass
