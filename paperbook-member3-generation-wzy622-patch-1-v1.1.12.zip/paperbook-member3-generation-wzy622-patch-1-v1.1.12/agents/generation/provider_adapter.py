"""Provider Adapter：授权验证 → 预算预留 → 提交/轮询/取消 → 资产交接。

M3 不持有 Token Secret、不做本地 HMAC 验证；验证由 M1 接口完成。
"""

from __future__ import annotations

import hashlib
import tempfile
from dataclasses import dataclass
from pathlib import Path

from .approval import ApprovalVerifier, VerifiedApproval
from .budget import BudgetClient, Reservation
from .errors import AppError, ErrorCode
from .execution import ExecutionContext
from .providers.base import ProviderResult, ProviderStatus, VideoPlan
from .retry import should_retry


class AdapterError(Exception):
    def __init__(self, message: str, *, retryable: bool = False):
        super().__init__(message)
        self.retryable = retryable


@dataclass(frozen=True)
class AssetHandoff:
    page_id: str
    segment_id: str
    provider: str
    model: str
    generation: int
    attempt: int
    task_id: str
    asset_path: str
    asset_sha256: str
    status: str
    budget_reservation_id: str


@dataclass
class VideoProviderAdapter:
    provider: object
    verifier: ApprovalVerifier
    budget: BudgetClient
    budget_id: str = "PAPERBOOK-POC-001"
    purpose: str = "M3 POC"
    cost_per_attempt_cny: float = 0.05
    poll_limit: int = 10
    output_dir: Path = Path(tempfile.gettempdir()) / "m3_adapter"

    def execute(
        self,
        *,
        token: str,
        plan: VideoPlan,
        image_url: str,
        asset_sha256: str,
        page_id: str,
        generation: int = 1,
        attempt: int = 1,
    ) -> AssetHandoff:
        verified = self.verifier.verify(token, asset_sha256=asset_sha256, purpose=self.purpose)
        return self._execute_verified(
            verified=verified,
            plan=plan,
            image_url=image_url,
            page_id=page_id,
            generation=generation,
            attempt=attempt,
        )

    def _execute_verified(
        self,
        *,
        verified: VerifiedApproval,
        plan: VideoPlan,
        image_url: str,
        page_id: str,
        generation: int,
        attempt: int,
    ) -> AssetHandoff:
        reservation: Reservation = self.budget.reserve(
            budget_id=self.budget_id,
            approval_jti=verified.claims.jti,
            amount_cny=self.cost_per_attempt_cny,
            purpose=self.purpose,
        )
        context = ExecutionContext(job_id=page_id, generation=generation, attempt=attempt, fence=verified.claims.jti)
        try:
            task = self.provider.submit(plan, image_url, execution=context)
            result: ProviderResult | None = None
            for _ in range(self.poll_limit):
                result = self.provider.wait(task.task_id)
                if result.status in {
                    ProviderStatus.SUCCEEDED,
                    ProviderStatus.FAILED,
                    ProviderStatus.CANCELLED,
                    ProviderStatus.UNKNOWN,
                }:
                    break
            if result is None or result.status is not ProviderStatus.SUCCEEDED or not result.video_url:
                # 失败也按预留金额计入累计费用，防止重试绕过预算
                self.budget.commit(reservation, actual_cny=self.cost_per_attempt_cny)
                retryable = should_retry("transient", attempt=attempt, max_attempts=attempt + 1)
                raise AdapterError(
                    f"视频生成失败：{result.error_code if result else 'no_result'}",
                    retryable=retryable,
                )
            self.output_dir.mkdir(parents=True, exist_ok=True)
            dest = self.output_dir / f"{page_id}_{plan.segment_id}_c01.mp4"
            path, digest = self.provider.download(result.video_url, dest)
            self.budget.commit(reservation, actual_cny=self.cost_per_attempt_cny)
            return AssetHandoff(
                page_id=page_id,
                segment_id=plan.segment_id,
                provider=task.provider,
                model=task.model,
                generation=task.generation,
                attempt=task.attempt,
                task_id=task.task_id,
                asset_path=str(path),
                asset_sha256=digest,
                status="ok",
                budget_reservation_id=reservation.reservation_id,
            )
        except AdapterError:
            raise
        except Exception as exc:  # noqa: BLE001
            self.budget.commit(reservation, actual_cny=self.cost_per_attempt_cny)
            raise AdapterError(f"Adapter 执行异常：{exc}") from exc

    def execute_with_retry(
        self,
        *,
        token: str,
        plan: VideoPlan,
        image_url: str,
        asset_sha256: str,
        page_id: str,
        generation: int = 1,
        max_attempts: int = 2,
    ) -> AssetHandoff:
        verified = self.verifier.verify(token, asset_sha256=asset_sha256, purpose=self.purpose)
        last: AdapterError | None = None
        for attempt in range(1, max_attempts + 1):
            try:
                return self._execute_verified(
                    verified=verified,
                    plan=plan,
                    image_url=image_url,
                    page_id=page_id,
                    generation=generation,
                    attempt=attempt,
                )
            except AdapterError as exc:
                last = exc
                if not exc.retryable or attempt >= max_attempts:
                    break
        raise last or AdapterError("Adapter 失败")
