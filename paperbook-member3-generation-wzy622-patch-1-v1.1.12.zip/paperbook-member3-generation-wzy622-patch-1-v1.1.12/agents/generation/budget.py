"""M1 统一预算客户端接口 + 测试用 Fake 预算服务（技术准备）。

真实环境：M3 只调用 M1 的预算接口；M1 持有项目总预算（人民币 10 元）。
本文件的 FakeBudgetService 只用于离线测试/重放，不是生产台账。
"""

from __future__ import annotations

import json
import os
import threading
import time
import urllib.request
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Protocol


class BudgetError(Exception):
    pass


@dataclass(frozen=True)
class Reservation:
    reservation_id: str
    budget_id: str
    approval_jti: str
    amount_cny: float


class BudgetClient(Protocol):
    def reserve(self, *, budget_id: str, approval_jti: str, amount_cny: float, purpose: str) -> Reservation:
        ...

    def commit(self, reservation: Reservation, *, actual_cny: float) -> None:
        ...


class M1BudgetClient:
    """M1 预算 HTTP 客户端；M3 不持有总预算，只预留/结算。"""

    def __init__(self, base_url: str, *, opener=urllib.request.urlopen):
        self.base_url = base_url.rstrip("/")
        self._opener = opener

    def _post(self, path: str, payload: dict) -> dict:
        request = urllib.request.Request(
            f"{self.base_url}{path}",
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with self._opener(request, timeout=30) as response:
                data = json.loads(response.read().decode("utf-8"))
        except Exception as exc:  # noqa: BLE001
            raise BudgetError(f"M1 预算接口失败：{exc}") from exc
        if not data.get("ok", True):
            raise BudgetError(str(data.get("message") or "M1 预算拒绝"))
        return data

    def reserve(self, *, budget_id: str, approval_jti: str, amount_cny: float, purpose: str) -> Reservation:
        data = self._post(
            "/internal/budget/reserve",
            {
                "budget_id": budget_id,
                "approval_jti": approval_jti,
                "amount_cny": amount_cny,
                "purpose": purpose,
            },
        )
        return Reservation(
            reservation_id=data["reservation_id"],
            budget_id=budget_id,
            approval_jti=approval_jti,
            amount_cny=float(data.get("amount_cny", amount_cny)),
        )

    def commit(self, reservation: Reservation, *, actual_cny: float) -> None:
        self._post(
            "/internal/budget/commit",
            {"reservation_id": reservation.reservation_id, "actual_cny": actual_cny},
        )


class FakeBudgetService:
    """模拟 M1 的全项目预算：总预算 10 元，跨进程重启保持，线程并发安全。"""

    def __init__(self, path: Path | None = None, *, total_cny: float = 150.0):
        self.path = path
        self.total_cents = int(round(total_cny * 100))
        self._lock = threading.Lock()
        self._data = {
            "schema_version": "1.0",
            "total_cents": self.total_cents,
            "spent_cents": 0,
            "reserved_cents": 0,
            "reservations": {},
            "history": [],
        }
        if path and path.is_file():
            loaded = json.loads(path.read_text(encoding="utf-8"))
            self._data.update(loaded)

    @property
    def spent_cny(self) -> float:
        return round(self._data["spent_cents"] / 100, 2)

    @property
    def reserved_cny(self) -> float:
        return round(self._data["reserved_cents"] / 100, 2)

    def reserve(self, *, budget_id: str, approval_jti: str, amount_cny: float, purpose: str) -> Reservation:
        amount_cents = int(round(amount_cny * 100))
        if amount_cents <= 0:
            raise BudgetError("预留金额必须大于 0")
        with self._lock:
            used = self._data["spent_cents"] + self._data["reserved_cents"]
            if used + amount_cents > self.total_cents:
                raise BudgetError(
                    f"项目预算不足：已用 {used/100:.2f} 元，预留 {amount_cents/100:.2f} 元，总额 {self.total_cents/100:.2f} 元"
                )
            reservation = Reservation(
                reservation_id="res_" + uuid.uuid4().hex[:12],
                budget_id=budget_id,
                approval_jti=approval_jti,
                amount_cny=amount_cents / 100,
            )
            self._data["reserved_cents"] += amount_cents
            self._data["reservations"][reservation.reservation_id] = {
                "budget_id": budget_id,
                "approval_jti": approval_jti,
                "reserved_cents": amount_cents,
                "purpose": purpose,
                "created_at": int(time.time()),
                "status": "reserved",
            }
            self._save()
            return reservation

    def commit(self, reservation: Reservation, *, actual_cny: float) -> None:
        actual_cents = int(round(actual_cny * 100))
        with self._lock:
            record = self._data["reservations"].get(reservation.reservation_id)
            if record is None or record["status"] != "reserved":
                raise BudgetError("预留不存在或已结算")
            reserved = record["reserved_cents"]
            if actual_cents > reserved:
                raise BudgetError("实际费用超过预留金额")
            self._data["reserved_cents"] -= reserved
            self._data["spent_cents"] += actual_cents
            record["status"] = "committed"
            record["actual_cents"] = actual_cents
            self._data["history"].append(
                {
                    "reservation_id": reservation.reservation_id,
                    "budget_id": reservation.budget_id,
                    "approval_jti": reservation.approval_jti,
                    "reserved_cents": reserved,
                    "actual_cents": actual_cents,
                    "at": int(time.time()),
                }
            )
            self._save()

    def _save(self) -> None:
        if not self.path:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_name(self.path.name + ".part")
        tmp.write_text(json.dumps(self._data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, self.path)
