"""F08/F05：POC 跨运行累计调用/时长/费用台账。

规则（与文档一致）：
- 每次真正发出 submit 请求 = 1 次 call，计入 calls/seconds/cost；
- poll/download 不计数；
- 本地校验失败（未发 HTTP）不计数；
- 重试产生新的 submit，也计数（保守，防重复扣费）。
台账只做 POC 预算，不是 Job 状态机；持久化由本文件原子写完成。
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path

from .poc_gate import PocApproval, PocGateError


@dataclass(frozen=True)
class GlobalLimits:
    max_calls: int | None = None
    max_seconds: float | None = None
    max_cost_usd: float | None = None

    @classmethod
    def from_env(cls, env: dict[str, str] | None = None) -> "GlobalLimits":
        values = os.environ if env is None else env

        def number(name: str, cast):
            raw = (values.get(name) or "").strip()
            return cast(raw) if raw else None

        return cls(
            max_calls=number("POC_GLOBAL_MAX_CALLS", int),
            max_seconds=number("POC_GLOBAL_MAX_SECONDS", float),
            max_cost_usd=number("POC_GLOBAL_MAX_COST_USD", float),
        )


class PocLedger:
    def __init__(self, path: Path):
        self.path = path
        self._data = {"schema_version": "1.0", "approvals": {}, "totals": {"calls": 0, "seconds": 0.0, "cost_usd": 0.0}}
        if path.is_file():
            loaded = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                self._data.update(loaded)

    @property
    def totals(self) -> dict:
        return dict(self._data.get("totals") or {})

    def used_for(self, approval_id: str) -> dict:
        return dict((self._data.get("approvals") or {}).get(approval_id) or {})

    def reserve(
        self,
        approval: PocApproval,
        *,
        approval_id: str,
        calls: int,
        seconds: float,
        cost_usd: float,
        global_limits: GlobalLimits | None = None,
        now: int | None = None,
    ) -> None:
        current = int(time.time()) if now is None else now
        if approval.expires_at <= current:
            raise PocGateError("POC 授权已过期")
        if calls < 1 or calls > approval.max_calls:
            raise PocGateError(f"POC 调用次数超出授权：{calls} > {approval.max_calls}")
        if seconds <= 0 or seconds > approval.max_seconds:
            raise PocGateError(f"POC 时长超出授权：{seconds} > {approval.max_seconds}")
        if cost_usd > approval.max_cost_usd:
            raise PocGateError(f"POC 费用超出授权：{cost_usd} > {approval.max_cost_usd}")

        approvals = self._data.setdefault("approvals", {})
        used = approvals.setdefault(approval_id, {"calls": 0, "seconds": 0.0, "cost_usd": 0.0})
        if used["calls"] + calls > approval.max_calls:
            raise PocGateError("该授权累计调用次数已用尽")
        if used["seconds"] + seconds > approval.max_seconds:
            raise PocGateError("该授权累计时长已用尽")
        if used["cost_usd"] + cost_usd > approval.max_cost_usd:
            raise PocGateError("该授权累计费用已用尽")

        totals = self._data.setdefault("totals", {"calls": 0, "seconds": 0.0, "cost_usd": 0.0})
        limits = global_limits or GlobalLimits()
        if limits.max_calls is not None and totals["calls"] + calls > limits.max_calls:
            raise PocGateError("POC 全局调用次数超限")
        if limits.max_seconds is not None and totals["seconds"] + seconds > limits.max_seconds:
            raise PocGateError("POC 全局时长超限")
        if limits.max_cost_usd is not None and totals["cost_usd"] + cost_usd > limits.max_cost_usd:
            raise PocGateError("POC 全局费用超限")

        used["calls"] += calls
        used["seconds"] = round(used["seconds"] + seconds, 3)
        used["cost_usd"] = round(used["cost_usd"] + cost_usd, 6)
        totals["calls"] += calls
        totals["seconds"] = round(totals["seconds"] + seconds, 3)
        totals["cost_usd"] = round(totals["cost_usd"] + cost_usd, 6)
        self._data.setdefault("history", []).append(
            {
                "approval_id": approval_id,
                "calls": calls,
                "seconds": seconds,
                "cost_usd": cost_usd,
                "at": current,
            }
        )
        self._save()

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_name(self.path.name + ".part")
        tmp.write_text(json.dumps(self._data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, self.path)


def approval_id(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()[:16]
