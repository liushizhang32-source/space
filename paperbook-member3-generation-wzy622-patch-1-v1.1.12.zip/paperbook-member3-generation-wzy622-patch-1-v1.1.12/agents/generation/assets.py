"""视频资产清单（v1.1 内部交付物，不替换 v1.0 C4）。

输出 `{page_id}_assets.json`：Segment、clip、音频、时间轴、角色、风格、供应商证据，
供 M1 编排/发布、M2 对齐、M4 播放使用。
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def make_asset_id(kind: str, page_id: str, segment_id: str, digest: str) -> str:
    """稳定、可追溯的资产 ID：kind_page_segment_sha12。"""
    return f"{kind}_{page_id}_{segment_id}_{digest[:12]}"


@dataclass
class ClipAsset:
    segment_id: str
    clip_id: str
    asset_id: str
    path: str
    sha256: str
    duration_sec: float
    width: int
    height: int
    fps: float
    provider: str
    model: str
    task_ref: str = ""
    source_kind: str = "ai_video"
    size_bytes: int = 0
    status: str = "ok"
    revision: str = ""


@dataclass
class AudioAsset:
    segment_id: str
    asset_id: str
    path: str
    sha256: str
    duration_sec: float
    engine: str = "tts"
    provider: str = ""
    model: str = ""
    voice: str = ""
    sample_rate: int = 0
    format: str = ""
    source_type: str = "tts"
    revision: str = ""
    size_bytes: int = 0
    status: str = "ok"


@dataclass
class SegmentAsset:
    segment_id: str
    order: int
    start_sec: float
    end_sec: float
    narration: str
    scene: str
    clip: ClipAsset | None = None
    audio: AudioAsset | None = None
    character_keys: list[str] = field(default_factory=list)


@dataclass
class PageAssetManifest:
    schema_version: str
    page_id: str
    book_id: str
    generation_mode: str
    style_profile: dict[str, Any]
    characters: list[dict[str, Any]]
    segments: list[SegmentAsset]
    video_path: str
    video_asset_id: str
    video_sha256: str
    video_duration_sec: float
    resolution: str
    fps: int
    created_at: str
    provider: str
    model: str
    job_id: str = ""
    generation: int = 0
    attempt: int = 0
    revision: str = ""
    status: str = "ok"
    total_size_bytes: int = 0
    subtitles_burned: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def write_manifest(path: Path, manifest: PageAssetManifest) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(manifest.to_dict(), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
