"""统一重试/计数规则（F05/F08）。

- 只有 timeout / rate_limited / transient / network 可自动重试；
- auth / terminal / unsupported / unknown 不自动重试；
- 每次真正 submit（含重试）都计入 POC calls；poll/download 不计；
- 本地参数/授权校验失败（未发 HTTP）不计。
"""

from __future__ import annotations

RETRYABLE_KINDS = frozenset({"timeout", "rate_limited", "transient", "network"})


def should_retry(kind: str, *, attempt: int, max_attempts: int) -> bool:
    if max_attempts <= 0:
        return False
    if attempt >= max_attempts:
        return False
    return kind in RETRYABLE_KINDS


def is_billable_submit(kind: str | None = None, *, http_sent: bool) -> bool:
    """submit 是否计入 calls：只要 HTTP 已发出就计；本地校验失败不计。"""
    return bool(http_sent)
