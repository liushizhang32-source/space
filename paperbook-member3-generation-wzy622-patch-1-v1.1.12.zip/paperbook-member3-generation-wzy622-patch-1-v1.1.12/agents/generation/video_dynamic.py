"""动态视频合成：每个 Segment 用真实 AI clip + TTS + 字幕 -> FFmpeg -> MP4。

与 v1.0 静帧路径分开：本模块不消费书页静图，clip 缺失/过短直接失败，禁止静图补位。
"""

from __future__ import annotations

import json
import os
import shutil
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from .assets import (
    AudioAsset,
    ClipAsset,
    PageAssetManifest,
    SegmentAsset,
    make_asset_id,
    sha256_file,
    write_manifest,
)
from .config import Settings
from .errors import AppError, ContractError, ErrorCode, VideoError
from .ids import book_id_of, page_no_of
from .media import AudioProbe, MediaStatus, VideoProbe, validate_audio, validate_video
from .proc import run, tail
from .publishing import publish_bundle
from .safety import ensure_story_safe
from .schemas import StoryDoc, VideoDoc
from .storage import PageFiles, asset_url
from .trust import (
    GenerationMode,
    MediaReview,
    Provenance,
    SafetyDecision,
    SafetyReview,
    SourceKind,
    clips_digest,
    provenance_secret,
    story_digest,
)
from .video import VideoResult, _audio_path, _base_vf, _concat, _subtitle_png


def _render_dynamic_clip(
    settings: Settings,
    ffmpeg: str,
    clip: Path,
    audio: Path | None,
    duration: float,
    out: Path,
    narration: str,
    tmp_dir: Path,
) -> bool:
    """把一个动态 clip 裁到 duration，叠加旁白与字幕。"""
    inputs = ["-i", str(clip)]
    if audio is not None:
        inputs += ["-i", str(audio)]
    else:
        inputs += ["-f", "lavfi", "-i", "anullsrc=channel_layout=mono:sample_rate=44100"]

    subtitle = _subtitle_png(narration, settings, tmp_dir, out.stem)
    cmd = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y", *inputs]
    if subtitle is not None:
        cmd += ["-loop", "1", "-i", str(subtitle)]
        filter_complex = (
            f"[0:v]{_base_vf(settings)}[bg];"
            f"[bg][2:v]overlay=(W-w)/2:H-h-40:format=auto[v]"
        )
        cmd += ["-filter_complex", filter_complex, "-map", "[v]", "-map", "1:a"]
    else:
        cmd += ["-vf", _base_vf(settings), "-map", "0:v:0", "-map", "1:a"]

    cmd += ["-t", f"{duration:.3f}", "-af", "apad"]
    cmd += [
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-crf",
        "23",
        "-pix_fmt",
        "yuv420p",
        "-c:a",
        "aac",
        "-b:a",
        "96k",
        "-ar",
        "44100",
        "-ac",
        "1",
        "-movflags",
        "+faststart",
        str(out),
    ]
    proc = run(cmd, timeout=settings.video_timeout_sec)
    if proc.returncode != 0 or not out.is_file() or out.stat().st_size == 0:
        if subtitle is not None:
            return _render_dynamic_clip(settings, ffmpeg, clip, audio, duration, out, "", tmp_dir)
        raise VideoError(f"动态片段合成失败（{out.stem}）", detail=tail(proc))
    return subtitle is not None


def _validate_dynamic_request(
    *,
    page_id: str,
    story_doc: StoryDoc,
    settings: Settings,
    expected_page_id: str | None,
    mode: GenerationMode,
    safety_review: SafetyReview | None,
    media_review: MediaReview | None,
    provenance: Provenance | None,
    secret: str,
) -> None:
    """F01/F02/F11 的统一入口门禁：页身份、安全审核、来源与模式。"""
    if story_doc.page_id != page_id:
        raise AppError(
            ErrorCode.INVALID_PARAM,
            f"story.page_id({story_doc.page_id}) 与请求页({page_id}) 不一致",
        )
    if expected_page_id is not None and expected_page_id != page_id:
        raise AppError(
            ErrorCode.INVALID_PARAM,
            f"请求页({page_id}) 与期望页({expected_page_id}) 不一致",
        )
    if story_doc.safety_pass is not True or story_doc.safety_flags:
        raise AppError(ErrorCode.SAFETY_BLOCKED, "故事未通过安全审核，禁止生成动态视频")
    digest = story_digest(story_doc.model_dump(mode="json"))
    if safety_review is None or not safety_review.ok or safety_review.content_sha256 != digest:
        raise AppError(ErrorCode.SAFETY_BLOCKED, "故事缺少通过的安全审核记录（或审核后内容被篡改）")
    ensure_story_safe(story_doc.model_dump(), settings, stage="video_dynamic")

    if mode is not GenerationMode.MOCK:
        if media_review is None or not media_review.ok:
            raise AppError(ErrorCode.SAFETY_BLOCKED, "生成媒体缺少通过的人工审核记录，禁止发布")
    if mode is GenerationMode.REAL_VIDEO:
        if provenance is None or not provenance.verify(secret):
            raise AppError(ErrorCode.SAFETY_BLOCKED, "真实视频缺少可信来源令牌，禁止标记 real_video")


def compose_dynamic_video(
    page_id: str,
    story: dict,
    clip_paths: dict[str, Path],
    settings: Settings,
    *,
    expected_page_id: str | None = None,
    generation_mode: GenerationMode | str = GenerationMode.MOCK,
    safety_review: SafetyReview | None = None,
    media_review: MediaReview | None = None,
    provenance: Provenance | None = None,
    provenance_secret_value: str | None = None,
    style_profile: dict | None = None,
    characters: list[dict] | None = None,
    provider: str = "wan",
    model: str = "",
    task_refs: dict[str, str] | None = None,
) -> VideoResult:
    """逐段合成动态视频并写 `{page_id}_assets.json`。

    clip_paths 必须覆盖所有 segment；缺一段即失败，不退回静帧。
    入口先做页身份、安全审核、模式/来源校验（F01/F02/F11）。
    """
    ffmpeg = settings.ffmpeg
    if not ffmpeg:
        raise VideoError("ffmpeg 不可用", detail="请设置 FFMPEG_PATH")
    if not clip_paths:
        raise VideoError("没有可用的 AI 动态 clip")

    story_doc = StoryDoc.model_validate(story)
    try:
        mode = GenerationMode(generation_mode)
    except ValueError as exc:
        raise AppError(ErrorCode.INVALID_PARAM, "generation_mode 非法") from exc
    secret = provenance_secret_value or provenance_secret()
    _validate_dynamic_request(
        page_id=page_id,
        story_doc=story_doc,
        settings=settings,
        expected_page_id=expected_page_id,
        mode=mode,
        safety_review=safety_review,
        media_review=media_review,
        provenance=provenance,
        secret=secret,
    )
    if mode is GenerationMode.REAL_VIDEO:
        assert provenance is not None
        provider = provenance.provider
        model = provenance.model
        task_refs = dict(provenance.task_ids)

    source_kind = {
        GenerationMode.MOCK: SourceKind.FIXTURE,
        GenerationMode.LOCAL_TEST: SourceKind.LOCAL_MODEL,
        GenerationMode.HYBRID_TEST: SourceKind.LOCAL_MODEL,
        GenerationMode.REAL_VIDEO: SourceKind.AI_VIDEO,
    }[mode]
    segments = [seg.model_dump() for seg in story_doc.segments]
    files = PageFiles(settings, page_id)
    tmp_dir = (settings.tmp_dir / f"{page_id}_dynamic_{os.getpid()}_{threading.get_ident()}_{uuid.uuid4().hex[:8]}").resolve()
    tmp_dir.mkdir(parents=True, exist_ok=True)

    clip_assets: dict[str, ClipAsset] = {}
    audio_assets: dict[str, AudioAsset] = {}
    rendered: list[Path] = []
    rendered_durations: list[float] = []
    subtitles_burned = False
    seen_digests: set[str] = set()
    started = time.perf_counter()

    try:
        for segment in segments:
            seg_id = segment["segment_id"]
            clip = clip_paths.get(seg_id)
            if clip is None or not clip.is_file():
                raise VideoError(f"segment {seg_id} 缺少 AI clip，拒绝用静图补位")
            if not clip.is_relative_to(settings.data_dir):
                raise AppError(ErrorCode.INVALID_PARAM, f"segment {seg_id} 的 clip 不在 DATA_DIR 内")
            duration = float(segment.get("duration_sec") or 0)
            if duration <= 0:
                raise VideoError(f"segment {seg_id} 时长为 0")

            check = validate_video(clip, settings, deep=True)
            if check.status is MediaStatus.UNAVAILABLE:
                raise AppError(ErrorCode.UNAVAILABLE, "clip 无法验证（ffprobe 不可用）", detail=check.reason)
            if check.status is MediaStatus.INVALID:
                raise VideoError(f"clip 校验失败：{check.reason}")
            probe = check.probe
            assert isinstance(probe, VideoProbe)
            clip_duration = probe.duration_ms / 1000.0
            if clip_duration + 0.2 < duration:
                raise VideoError(
                    f"clip 短于旁白（{clip_duration:.2f}s < {duration:.2f}s），需重新生成，不能循环/静帧补时"
                )

            audio = _audio_path(segment, settings)
            audio_asset = None
            if audio is not None:
                audio_check = validate_audio(audio, settings, deep=True)
                if isinstance(audio_check.probe, AudioProbe):
                    audio_asset = AudioAsset(
                        segment_id=seg_id,
                        asset_id=make_asset_id("aud", page_id, seg_id, sha256_file(audio)),
                        path=audio.relative_to(settings.data_dir).as_posix(),
                        sha256=sha256_file(audio),
                        duration_sec=round(audio_check.probe.duration_ms / 1000.0, 3),
                        engine="tts",
                        provider="tts",
                        model="",
                        voice="",
                        sample_rate=audio_check.probe.sample_rate,
                        format=audio.suffix.lstrip("."),
                        source_type="tts",
                        revision=sha256_file(audio)[:12],
                        size_bytes=audio.stat().st_size,
                    )
                    audio_assets[seg_id] = audio_asset

            out = tmp_dir / f"clip_{segment['order']:02d}.mp4"
            burned = _render_dynamic_clip(
                settings, ffmpeg, clip, audio, duration, out, str(segment.get("narration") or ""), tmp_dir
            )
            subtitles_burned = subtitles_burned or burned
            rendered.append(out)
            rendered_check = validate_video(out, settings, deep=True)
            if not rendered_check.ok or rendered_check.probe is None:
                raise VideoError(f"segment {seg_id} 渲染片段无法验证：{rendered_check.reason}")
            rendered_durations.append(round(rendered_check.probe.duration_ms / 1000.0, 3))

            digest = sha256_file(clip)
            if digest in seen_digests:
                raise VideoError(f"segment {seg_id} 与其他段复用了同一 clip，拒绝发布")
            seen_digests.add(digest)
            if mode is GenerationMode.REAL_VIDEO:
                assert provenance is not None
                expected = provenance.clip_hashes.get(seg_id)
                if expected != digest:
                    raise AppError(ErrorCode.SAFETY_BLOCKED, f"segment {seg_id} 的 clip 与来源令牌不一致")
            clip_assets[seg_id] = ClipAsset(
                segment_id=seg_id,
                clip_id=f"{seg_id}_c01",
                asset_id=make_asset_id("clip", page_id, seg_id, digest),
                path=clip.relative_to(settings.data_dir).as_posix(),
                sha256=digest,
                duration_sec=round(clip_duration, 3),
                width=probe.width,
                height=probe.height,
                fps=round(probe.fps, 3),
                provider=provider,
                model=model,
                task_ref=(task_refs or {}).get(seg_id, ""),
                source_kind=source_kind.value,
                size_bytes=clip.stat().st_size,
                status="ok",
                revision=digest[:12],
            )

        merged = tmp_dir / "merged.mp4"
        if mode is not GenerationMode.MOCK:
            hashes = {seg_id: asset.sha256 for seg_id, asset in clip_assets.items()}
            if media_review is None or media_review.subject_sha256 != clips_digest(hashes):
                raise AppError(ErrorCode.SAFETY_BLOCKED, "媒体审核未覆盖本次 clip 集合（或 clip 被替换）")
        _concat(ffmpeg, rendered, merged, settings.video_timeout_sec, tmp_dir)
        check = validate_video(merged, settings, deep=True)
        if check.status is MediaStatus.UNAVAILABLE:
            raise AppError(ErrorCode.UNAVAILABLE, "视频无法验证（ffprobe 不可用）", detail=check.reason)
        if check.status is MediaStatus.INVALID:
            raise VideoError(f"视频文件校验失败：{check.reason}")
        video_probe = check.probe
        assert isinstance(video_probe, VideoProbe)

        # F12：用每段实际渲染 probe 构造时间轴，不按总时长比例重写边界。
        durations = rendered_durations
        total = round(sum(durations), 3)
        actual = round(video_probe.duration_ms / 1000.0, 3)
        if abs(actual - total) > 0.2:
            raise VideoError(f"合成时长({actual:.2f}s)与分段实际时长({total:.2f}s)不一致")

        timeline: list[SegmentAsset] = []
        cursor = 0.0
        for segment, duration in zip(segments, durations):
            seg_id = segment["segment_id"]
            timeline.append(
                SegmentAsset(
                    segment_id=seg_id,
                    order=int(segment["order"]),
                    start_sec=round(cursor, 3),
                    end_sec=round(cursor + duration, 3),
                    narration=str(segment.get("narration") or ""),
                    scene=str(segment.get("scene") or ""),
                    clip=clip_assets.get(seg_id),
                    audio=audio_assets.get(seg_id),
                    character_keys=list(segment.get("character_keys") or []),
                )
            )
            cursor += duration

        doc = {
            "schema_version": "1.0",
            "book_id": book_id_of(page_id),
            "page_id": page_id,
            "page_no": page_no_of(page_id),
            "status": "ok",
            "video_url": asset_url(settings, files.video),
            "duration_sec": total,
            "resolution": f"{settings.video_width}x{settings.video_height}",
            "fps": settings.video_fps,
            "segments": [
                {
                    "segment_id": item.segment_id,
                    "start_sec": item.start_sec,
                    "end_sec": item.end_sec,
                }
                for item in timeline
            ],
            "elapsed_ms": int((time.perf_counter() - started) * 1000),
        }
        try:
            validated = VideoDoc.model_validate(doc)
        except Exception as exc:  # noqa: BLE001
            raise ContractError("video.json 不满足 C4 契约", detail=str(exc)[:800]) from exc

        # F06：三件套先全部暂存，再一次性发布；manifest 不再晚于视频。
        video_digest = sha256_file(merged)
        video_json_tmp = tmp_dir / "video.json"
        video_json_tmp.write_text(
            json.dumps(validated.model_dump(), ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        manifest = PageAssetManifest(
            schema_version="1.1",
            page_id=page_id,
            book_id=book_id_of(page_id),
            generation_mode=mode.value,
            style_profile=style_profile or {"source": "page_first_frame"},
            characters=characters or [],
            segments=timeline,
            video_path=files.video.relative_to(settings.data_dir).as_posix(),
            video_asset_id=make_asset_id("video", page_id, "full", video_digest),
            video_sha256=video_digest,
            video_duration_sec=total,
            resolution=f"{settings.video_width}x{settings.video_height}",
            fps=settings.video_fps,
            created_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
            provider=provider,
            model=model,
            revision=video_digest[:12],
            status="ok",
            total_size_bytes=sum(
                [merged.stat().st_size]
                + [asset.size_bytes for asset in clip_assets.values()]
                + [asset.size_bytes for asset in audio_assets.values()]
            ),
            subtitles_burned=subtitles_burned,
        )
        manifest_tmp = tmp_dir / "assets.json"
        write_manifest(manifest_tmp, manifest)
        publish_bundle(
            page_id,
            {
                files.video: merged,
                files.video_json: video_json_tmp,
                settings.json_dir / f"{page_id}_assets.json": manifest_tmp,
            },
        )

        return VideoResult(
            page_id=page_id,
            doc=validated.model_dump(),
            path=files.video,
            subtitles_burned=subtitles_burned,
            elapsed_ms=int((time.perf_counter() - started) * 1000),
        )
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)
