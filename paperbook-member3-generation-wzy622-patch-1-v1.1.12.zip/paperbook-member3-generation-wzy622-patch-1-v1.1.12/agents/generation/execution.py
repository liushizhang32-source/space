"""执行身份、幂等键与 typed Provider 事件（F05）。

M3 不持有 Job 状态机；只接收 M1 的 ExecutionContext，返回绑定身份的 typed 事件。
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum


class EventKind(str, Enum):
    SUBMITTED = "submitted"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class ExecutionContext:
    job_id: str
    generation: int
    attempt: int
    fence: str

    def __post_init__(self) -> None:
        if not self.job_id:
            raise ValueError("job_id 不能为空")
        if self.generation < 0 or self.attempt < 0:
            raise ValueError("generation/attempt 不能为负")
        if not self.fence:
            raise ValueError("fence 不能为空")

    def idempotency_key(self, page_id: str, segment_id: str) -> str:
        return f"{self.job_id}:{self.generation}:{self.attempt}:{self.fence}:{page_id}:{segment_id}"

    def segment_key(self, segment_id: str) -> str:
        return f"{self.job_id}:{self.generation}:{self.attempt}:{self.fence}:{segment_id}"


def request_hash(payload: dict) -> str:
    """供应商请求参数摘要；同一 prompt/图片/参数应得到同一 hash。"""
    return hashlib.sha256(
        json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass(frozen=True)
class ProviderEvent:
    kind: EventKind
    task_id: str
    fence: str
    observed_at: str
    raw_status: str = ""
    retryable: bool = False
    detail: str = ""

    @classmethod
    def from_status(
        cls,
        *,
        status: str,
        task_id: str,
        fence: str,
        raw_status: str = "",
        retryable: bool = False,
        detail: str = "",
    ) -> "ProviderEvent":
        mapping = {
            "queued": EventKind.SUBMITTED,
            "running": EventKind.SUBMITTED,
            "succeeded": EventKind.SUCCEEDED,
            "failed": EventKind.FAILED,
            "cancelled": EventKind.CANCELLED,
            "unknown": EventKind.UNKNOWN,
        }
        return cls(
            kind=mapping.get(status, EventKind.UNKNOWN),
            task_id=task_id,
            fence=fence,
            observed_at=utc_now(),
            raw_status=raw_status or status,
            retryable=retryable,
            detail=detail,
        )
