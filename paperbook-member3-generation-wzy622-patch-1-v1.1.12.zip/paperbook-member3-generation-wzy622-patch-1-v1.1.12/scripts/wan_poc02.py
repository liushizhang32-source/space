"""POC-02：用成员二 C1/C2 生成两段 Wan 动态 clip（保书页模式）。

用法：
  python scripts/wan_poc02.py --image-url "https://..." --duration 5
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from agents.generation.approval import ApprovalError, M1ApprovalClient  # noqa: E402
from agents.generation.budget import BudgetError, M1BudgetClient  # noqa: E402
from agents.generation.config import load_dotenv  # noqa: E402
from agents.generation.poc_gate import PocGateError, fetch_input_sha256  # noqa: E402
from agents.generation.providers import WanConfig, WanProvider  # noqa: E402
from agents.generation.story.planner import plan_segments  # noqa: E402

PAGE = "sally_p19"
DATA = ROOT / "data_m2_20261110" / "json"


def build_segments(duration: float) -> list[SimpleNamespace]:
    ocr = json.loads((DATA / f"{PAGE}_ocr.json").read_text(encoding="utf-8"))
    vlm = json.loads((DATA / f"{PAGE}_vlm.json").read_text(encoding="utf-8"))
    texts = [b["text"].strip() for b in ocr["text_blocks"] if b["text"].strip() and b["text"].strip() != "19"]
    if len(texts) < 2:
        raise SystemExit("OCR 文本不足两段")
    scene = vlm.get("description") or ""
    return [
        SimpleNamespace(
            segment_id=f"{PAGE}_s01",
            narration=" ".join(texts[:2]),
            scene=scene,
            duration_sec=duration,
        ),
        SimpleNamespace(
            segment_id=f"{PAGE}_s02",
            narration=" ".join(texts[2:4]),
            scene=scene,
            duration_sec=duration,
        ),
    ]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--image-url", required=True)
    parser.add_argument("--duration", type=float, default=5.0)
    parser.add_argument("--out", default="poc_output/poc02")
    args = parser.parse_args()

    load_dotenv()
    config = WanConfig.from_env()
    vlm = json.loads((DATA / f"{PAGE}_vlm.json").read_text(encoding="utf-8"))
    segments = build_segments(args.duration)
    plans = plan_segments(segments, vlm.get("objects", []), age_level="3-6", preserve_page=True)

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    try:
        m1_base = (os.environ.get("M1_BASE_URL") or "").strip()
        token = (os.environ.get("POC_APPROVAL_TOKEN") or "").strip()
        if not m1_base or not token:
            raise PocGateError("缺少 M1_BASE_URL / POC_APPROVAL_TOKEN，拒绝真实 submit")
        actual_sha = fetch_input_sha256(args.image_url)
        verified = M1ApprovalClient(m1_base).verify(token, asset_sha256=actual_sha, purpose="M3 POC")
        rate_cny = float(os.environ.get("WAN_PRICE_PER_SEC_CNY") or "0.92")
        cost_cny = args.duration * len(plans) * rate_cny
        budget = M1BudgetClient(m1_base)
        reservation = budget.reserve(
            budget_id=verified.claims.budget_id,
            approval_jti=verified.claims.jti,
            amount_cny=cost_cny,
            purpose="M3 POC",
        )
        print(f"approved_by={verified.claims.approved_by} input_sha256={actual_sha[:12]}…")
    except (ApprovalError, BudgetError, PocGateError) as exc:
        print("POC 授权/预算拒绝：", exc)
        return 3

    provider = WanProvider(config)
    summary = []

    for plan in plans:
        print(f"--- {plan.segment_id} duration={plan.target_duration_sec}s")
        print("prompt:", plan.prompt[:120], "...")
        task = provider.submit(plan, args.image_url)
        print("task_id=", task.task_id)
        result = provider.wait(task.task_id)
        print("status=", result.status.value)
        if result.status.value != "succeeded" or not result.video_url:
            budget.commit(reservation, actual_cny=cost_cny)
            print("error=", result.error_code, result.error_message)
            return 1
        dest = out / f"{plan.segment_id}.mp4"
        path, digest = provider.download(result.video_url, dest)
        summary.append({"segment_id": plan.segment_id, "task_id": task.task_id, "path": str(path), "sha256": digest, "bytes": path.stat().st_size})
        print("saved", path, path.stat().st_size, digest)

    budget.commit(reservation, actual_cny=cost_cny)
    (out / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("done", out.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
