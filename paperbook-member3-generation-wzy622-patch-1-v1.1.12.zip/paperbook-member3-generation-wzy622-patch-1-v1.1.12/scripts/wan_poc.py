"""Wan 3.0 单段 POC：真实提交 → 轮询 → 下载 → 记录哈希。

用法（在包根目录）：
  .\\_aivenv\\Scripts\\python.exe scripts\\wan_poc.py --help   # 不需要，直接用系统 Python
  python scripts\\wan_poc.py --image-url "https://..." --duration 5 --prompt "..."

密钥只从环境/.env 读取，不打印。
"""

from __future__ import annotations

import argparse
import hashlib
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from agents.generation.approval import ApprovalError, M1ApprovalClient  # noqa: E402
from agents.generation.budget import BudgetError, M1BudgetClient  # noqa: E402
from agents.generation.config import load_dotenv  # noqa: E402
from agents.generation.poc_gate import PocGateError, fetch_input_sha256  # noqa: E402
from agents.generation.providers import VideoPlan, WanConfig, WanProvider  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Wan 3.0 单段 POC")
    parser.add_argument("--image-url", required=True, help="公网可访问的书页图 URL")
    parser.add_argument("--prompt", default="书页中的角色开始自然活动，画面保持同一绘本场景")
    parser.add_argument("--duration", type=float, default=5.0)
    parser.add_argument("--out", default="poc_output")
    parser.add_argument("--dry-run", action="store_true", help="只校验配置，不提交")
    args = parser.parse_args()

    load_dotenv()
    try:
        config = WanConfig.from_env()
    except Exception as exc:  # noqa: BLE001
        print("配置不可用：", exc)
        print("需要 .env: WAN_API_KEY / WAN_WORKSPACE_ID / WAN_REGION")
        return 2

    print(f"provider=wan model={config.model} region={config.region} resolution={config.resolution}")
    print(f"workspace={config.workspace_id} key=***")
    plan = VideoPlan(
        segment_id="poc_s01",
        prompt=args.prompt,
        target_duration_sec=args.duration,
    )
    print(f"plan: duration={plan.target_duration_sec}s chars={len(plan.prompt)}")
    if args.dry_run:
        print("dry-run：未提交")
        return 0

    # F08：M3 不持有 secret；Token 由 M1 验证，预算由 M1 预留/结算。
    reservation = None
    budget = None
    try:
        m1_base = (os.environ.get("M1_BASE_URL") or "").strip()
        token = (os.environ.get("POC_APPROVAL_TOKEN") or "").strip()
        if not m1_base or not token:
            raise PocGateError("缺少 M1_BASE_URL / POC_APPROVAL_TOKEN，拒绝真实 submit")
        actual_sha = fetch_input_sha256(args.image_url)
        verified = M1ApprovalClient(m1_base).verify(token, asset_sha256=actual_sha, purpose="M3 POC")
        rate_cny = float(os.environ.get("WAN_PRICE_PER_SEC_CNY") or "0.92")
        cost_cny = args.duration * rate_cny
        budget = M1BudgetClient(m1_base)
        reservation = budget.reserve(
            budget_id=verified.claims.budget_id,
            approval_jti=verified.claims.jti,
            amount_cny=cost_cny,
            purpose="M3 POC",
        )
        print(f"approved_by={verified.claims.approved_by} input_sha256={actual_sha[:12]}…")
    except (ApprovalError, BudgetError, PocGateError) as exc:
        print("POC 授权/预算拒绝：", exc)
        return 3

    provider = WanProvider(config)
    task = provider.submit(plan, args.image_url)
    print("task_id=", task.task_id)
    result = provider.wait(task.task_id)
    print("status=", result.status.value)
    if result.status.value != "succeeded" or not result.video_url:
        if budget and reservation:
            budget.commit(reservation, actual_cny=cost_cny)
        print("error=", result.error_code, result.error_message)
        return 1

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    dest = out / "poc_s01.mp4"
    path, digest = provider.download(result.video_url, dest)
    if budget and reservation:
        budget.commit(reservation, actual_cny=cost_cny)
    print("saved=", path, "bytes=", path.stat().st_size, "sha256=", digest)

    size = path.stat().st_size
    if size <= 0:
        return 1
    print("ok")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
