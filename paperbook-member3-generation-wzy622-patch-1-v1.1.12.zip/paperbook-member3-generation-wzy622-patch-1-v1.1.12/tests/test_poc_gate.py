"""F08：POC 授权/预算门禁测试。"""

from __future__ import annotations

import time

import pytest

from agents.generation.poc_gate import (
    PocApproval,
    PocGateError,
    assert_allowed,
    fetch_input_sha256,
    issue_approval,
    parse_approval,
    require_approval_from_env,
)

SECRET = "poc-secret"


def approval(**overrides) -> PocApproval:
    base = dict(
        approved_by="lead",
        purpose="offline-test",
        region="cn-beijing",
        max_calls=2,
        max_seconds=10,
        max_cost_usd=2,
        expires_at=int(time.time()) + 3600,
    )
    base.update(overrides)
    return PocApproval(**base)


def test_issue_and_verify() -> None:
    token = issue_approval(approval(), SECRET)
    parsed = parse_approval(token, SECRET)
    assert parsed.approved_by == "lead"
    assert_allowed(parsed, region="cn-beijing", calls=2, seconds=10)


def test_wrong_signature_rejected() -> None:
    token = issue_approval(approval(), SECRET)
    with pytest.raises(PocGateError):
        parse_approval(token, "wrong")


def test_expired_rejected() -> None:
    with pytest.raises(PocGateError):
        assert_allowed(approval(expires_at=1), region="cn-beijing", calls=1, seconds=5, now=2)


def test_region_mismatch_rejected() -> None:
    with pytest.raises(PocGateError):
        assert_allowed(approval(), region="ap-southeast-1", calls=1, seconds=5)


def test_calls_and_seconds_limits() -> None:
    with pytest.raises(PocGateError):
        assert_allowed(approval(), region="cn-beijing", calls=3, seconds=5)
    with pytest.raises(PocGateError):
        assert_allowed(approval(), region="cn-beijing", calls=1, seconds=11)


def test_cost_limit_enforced() -> None:
    with pytest.raises(PocGateError):
        assert_allowed(approval(max_cost_usd=1), region="cn-beijing", calls=1, seconds=5, estimated_cost_usd=2)


def test_env_missing_token_rejected() -> None:
    with pytest.raises(PocGateError):
        require_approval_from_env(region="cn-beijing", calls=1, seconds=5, env={})


def test_env_valid_token_accepted() -> None:
    token = issue_approval(approval(), SECRET)
    env = {"POC_APPROVAL_TOKEN": token, "POC_APPROVAL_SECRET": SECRET}
    parsed = require_approval_from_env(region="cn-beijing", calls=1, seconds=5, env=env)
    assert parsed.approved_by == "lead"


def test_input_hash_must_match() -> None:
    token = issue_approval(approval(input_sha256="a" * 64), SECRET)
    env = {"POC_APPROVAL_TOKEN": token, "POC_APPROVAL_SECRET": SECRET}
    with pytest.raises(PocGateError):
        require_approval_from_env(
            region="cn-beijing", calls=1, seconds=5, actual_input_sha256="b" * 64, env=env
        )
    parsed = require_approval_from_env(
        region="cn-beijing", calls=1, seconds=5, actual_input_sha256="a" * 64, env=env
    )
    assert parsed.input_sha256 == "a" * 64


def test_input_hash_missing_rejected() -> None:
    token = issue_approval(approval(), SECRET)
    env = {"POC_APPROVAL_TOKEN": token, "POC_APPROVAL_SECRET": SECRET}
    with pytest.raises(PocGateError):
        require_approval_from_env(
            region="cn-beijing", calls=1, seconds=5, actual_input_sha256="a" * 64, env=env
        )


class _Resp:
    def __init__(self, data: bytes):
        self._data = data
        self._pos = 0

    def read(self, size: int = -1):
        if size < 0:
            size = len(self._data) - self._pos
        chunk = self._data[self._pos : self._pos + size]
        self._pos += len(chunk)
        return chunk

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False


def test_fetch_input_sha256() -> None:
    data = b"hello"
    digest = fetch_input_sha256("https://example.com/a.jpg", opener=lambda request, timeout=None: _Resp(data))
    import hashlib

    assert digest == hashlib.sha256(data).hexdigest()
