"""Token、预算、Fake Provider 与 Adapter 的技术准备测试（不联网、不收费）。"""

from __future__ import annotations

import threading
import time
from pathlib import Path

import pytest

from agents.generation.approval import (
    ApprovalClaims,
    ApprovalError,
    FakeApprovalVerifier,
    issue_token,
    parse_token_untrusted,
)
from agents.generation.budget import BudgetError, FakeBudgetService, M1BudgetClient
from agents.generation.provider_adapter import AdapterError, VideoProviderAdapter
from agents.generation.providers import VideoPlan
from agents.generation.providers.fake import FakeVideoProvider

SECRET = "test-only-secret"
ASSET = "a" * 64


def claims(**overrides) -> ApprovalClaims:
    now = int(time.time())
    base = dict(
        jti="jti-001",
        issued_at=now - 10,
        expires_at=now + 3600,
        purpose="M3 POC",
        asset_sha256=ASSET,
        budget_id="paperbook-v1-poc",
        approved_by="lead",
        max_calls=10,
        max_seconds=100,
        max_cost_cny=10,
    )
    base.update(overrides)
    return ApprovalClaims(**base)


def token(**overrides) -> str:
    return issue_token(claims(**overrides), SECRET)


def test_token_normal_verify() -> None:
    verifier = FakeApprovalVerifier(SECRET)
    verified = verifier.verify(token(), asset_sha256=ASSET, purpose="M3 POC")
    assert verified.claims.jti == "jti-001"
    assert parse_token_untrusted(token()).budget_id == "paperbook-v1-poc"


def test_token_tamper_rejected() -> None:
    raw = token()
    tampered = raw[:-1] + ("0" if raw[-1] != "0" else "1")
    with pytest.raises(ApprovalError):
        FakeApprovalVerifier(SECRET).verify(tampered, asset_sha256=ASSET, purpose="M3 POC")


def test_token_expired_rejected() -> None:
    with pytest.raises(ApprovalError):
        FakeApprovalVerifier(SECRET).verify(
            token(expires_at=int(time.time()) - 1), asset_sha256=ASSET, purpose="M3 POC"
        )


def test_token_replay_rejected() -> None:
    verifier = FakeApprovalVerifier(SECRET)
    verifier.verify(token(), asset_sha256=ASSET, purpose="M3 POC")
    with pytest.raises(ApprovalError):
        verifier.verify(token(), asset_sha256=ASSET, purpose="M3 POC")


def test_asset_hash_mismatch_rejected() -> None:
    with pytest.raises(ApprovalError):
        FakeApprovalVerifier(SECRET).verify(token(), asset_sha256="b" * 64, purpose="M3 POC")


def test_budget_exhausted(tmp_path: Path) -> None:
    service = FakeBudgetService(tmp_path / "budget.json", total_cny=10.0)
    service.reserve(budget_id="p", approval_jti="j", amount_cny=9.9, purpose="x")
    with pytest.raises(BudgetError):
        service.reserve(budget_id="p", approval_jti="j2", amount_cny=0.2, purpose="x")


def test_budget_survives_restart(tmp_path: Path) -> None:
    path = tmp_path / "budget.json"
    service = FakeBudgetService(path)
    reservation = service.reserve(budget_id="p", approval_jti="j", amount_cny=1.0, purpose="x")
    service.commit(reservation, actual_cny=0.5)
    reloaded = FakeBudgetService(path)
    assert reloaded.spent_cny == 0.5


def test_budget_concurrent_race(tmp_path: Path) -> None:
    service = FakeBudgetService(tmp_path / "budget.json", total_cny=10.0)
    errors: list[Exception] = []

    def worker() -> None:
        try:
            service.reserve(budget_id="p", approval_jti="j", amount_cny=1.0, purpose="x")
        except Exception as exc:  # noqa: BLE001
            errors.append(exc)

    threads = [threading.Thread(target=worker) for _ in range(20)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    # 10 元总预算，最多 10 个 1 元预留成功
    assert service.reserved_cny <= 10.0
    assert len(errors) == 10


def test_failure_retry_counts(tmp_path: Path) -> None:
    source = tmp_path / "clip.mp4"
    source.write_bytes(b"fake-mp4-bytes")
    provider = FakeVideoProvider([source], fail_submits=1)
    budget = FakeBudgetService(tmp_path / "budget.json")
    adapter = VideoProviderAdapter(
        provider=provider,
        verifier=FakeApprovalVerifier(SECRET),
        budget=budget,
        cost_per_attempt_cny=0.05,
        output_dir=tmp_path / "out",
    )
    handoff = adapter.execute_with_retry(
        token=token(jti="retry-job"),
        plan=VideoPlan(segment_id="book01_p03_s01", prompt="p", target_duration_sec=5),
        image_url="https://example.com/a.jpg",
        asset_sha256=ASSET,
        page_id="book01_p03",
        max_attempts=2,
    )
    assert handoff.status == "ok"
    assert handoff.attempt == 2
    assert budget.spent_cny == pytest.approx(0.10)


def test_fake_provider_full_flow(tmp_path: Path) -> None:
    source = tmp_path / "clip.mp4"
    source.write_bytes(b"fake-mp4-bytes")
    provider = FakeVideoProvider([source])
    budget = FakeBudgetService(tmp_path / "budget.json")
    adapter = VideoProviderAdapter(
        provider=provider,
        verifier=FakeApprovalVerifier(SECRET),
        budget=budget,
        cost_per_attempt_cny=0.05,
        output_dir=tmp_path / "out",
    )
    handoff = adapter.execute(
        token=token(jti="full-flow"),
        plan=VideoPlan(segment_id="book01_p03_s01", prompt="p", target_duration_sec=5),
        image_url="https://example.com/a.jpg",
        asset_sha256=ASSET,
        page_id="book01_p03",
    )
    assert handoff.provider == "fake"
    assert handoff.model == "fake-video-v1"
    assert handoff.generation == 1
    assert handoff.attempt == 1
    assert handoff.task_id
    assert handoff.segment_id == "book01_p03_s01"
    assert handoff.asset_path.endswith(".mp4")
    assert len(handoff.asset_sha256) == 64
    assert budget.spent_cny == pytest.approx(0.05)


def test_fake_status_and_cancel(tmp_path: Path) -> None:
    source = tmp_path / "clip.mp4"
    source.write_bytes(b"fake")
    provider = FakeVideoProvider([source, source])
    task = provider.submit(VideoPlan(segment_id="s1", prompt="p", target_duration_sec=5), "https://x/a.jpg")
    assert provider.poll(task.task_id).status.value == "running"
    assert provider.poll(task.task_id).status.value == "succeeded"

    task2 = provider.submit(VideoPlan(segment_id="s2", prompt="p", target_duration_sec=5), "https://x/a.jpg")
    receipt = provider.cancel(task2.task_id)
    assert receipt.status.value == "cancelled"
    assert receipt.confirmed


def test_fake_timeout_counts_budget(tmp_path: Path) -> None:
    source = tmp_path / "clip.mp4"
    source.write_bytes(b"fake")

    class StuckProvider(FakeVideoProvider):
        def wait(self, task_id):
            from agents.generation.providers.base import ProviderResult, ProviderStatus

            return ProviderResult(ProviderStatus.RUNNING)

    provider = StuckProvider([source])
    budget = FakeBudgetService(tmp_path / "budget.json")
    adapter = VideoProviderAdapter(
        provider=provider,
        verifier=FakeApprovalVerifier(SECRET),
        budget=budget,
        cost_per_attempt_cny=0.05,
        poll_limit=1,
        output_dir=tmp_path / "out",
    )
    with pytest.raises(AdapterError):
        adapter.execute(
            token=token(jti="timeout-job"),
            plan=VideoPlan(segment_id="s", prompt="p", target_duration_sec=5),
            image_url="https://example.com/a.jpg",
            asset_sha256=ASSET,
            page_id="book01_p03",
        )
    assert budget.spent_cny == pytest.approx(0.05)


def test_budget_exhaustion_blocks_adapter(tmp_path: Path) -> None:
    source = tmp_path / "clip.mp4"
    source.write_bytes(b"fake")
    provider = FakeVideoProvider([source])
    budget = FakeBudgetService(tmp_path / "budget.json", total_cny=0.01)
    adapter = VideoProviderAdapter(
        provider=provider,
        verifier=FakeApprovalVerifier(SECRET),
        budget=budget,
        cost_per_attempt_cny=0.05,
        output_dir=tmp_path / "out",
    )
    with pytest.raises(BudgetError):
        adapter.execute(
            token=token(jti="no-budget"),
            plan=VideoPlan(segment_id="s", prompt="p", target_duration_sec=5),
            image_url="https://example.com/a.jpg",
            asset_sha256=ASSET,
            page_id="book01_p03",
        )


def test_m1_budget_client_http() -> None:
    calls = []

    class Resp:
        def __init__(self, data: dict):
            self._data = data

        def read(self, size: int = -1):
            import json

            return json.dumps(self._data).encode()

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

    def opener(request, timeout=None):
        calls.append(request.full_url)
        return Resp({"ok": True, "reservation_id": "res_1", "amount_cny": 0.05})

    client = M1BudgetClient("http://m1.internal", opener=opener)
    reservation = client.reserve(budget_id="b", approval_jti="j", amount_cny=0.05, purpose="p")
    client.commit(reservation, actual_cny=0.05)
    assert reservation.reservation_id == "res_1"
    assert calls[0].endswith("/internal/budget/reserve")
    assert calls[1].endswith("/internal/budget/commit")
