"""Story Planner 与角色归一测试。"""

from __future__ import annotations

import pytest

from types import SimpleNamespace

from agents.generation.errors import AppError, ErrorCode
from agents.generation.story.planner import CharacterRegistry, build_prompt, character_key, plan_segments


def segment(seg_id: str, narration: str, scene: str, duration: float = 5.0):
    return SimpleNamespace(segment_id=seg_id, narration=narration, scene=scene, duration_sec=duration)


def test_plan_matches_segments_and_uses_duration() -> None:
    segments = [
        segment("sally_p19_s01", "Sally 说快来帮我。", "两个孩子在草地上拉纸袋。"),
        segment("sally_p19_s02", "纸袋破了。", "纸袋裂开，孩子们大笑。", 6.5),
    ]
    objects = [{"label": "孩子"}, {"label": "纸袋"}]
    plans = plan_segments(segments, objects, age_level="3-6")
    assert [p.segment_id for p in plans] == ["sally_p19_s01", "sally_p19_s02"]
    assert plans[1].target_duration_sec == 6.5
    assert "纸袋" in plans[1].prompt
    assert "儿童绘本动画" in plans[0].prompt


def test_prompt_does_not_use_camera_zoom_as_motion() -> None:
    prompt = build_prompt(segment("a_p01_s01", "小兔子跳。", "小兔子在草地上跳。"), ["小兔子"], "3-6")
    assert "zoom" not in prompt.lower()
    assert "镜头缩放" not in prompt
    assert "动作" in prompt


def test_character_key_is_stable_across_pages() -> None:
    assert character_key("小兔子") == character_key(" 小兔子 ")
    assert character_key("小兔子") != character_key("大灰狼")


def test_registry_persists_and_reuses_reference(tmp_path) -> None:
    path = tmp_path / "characters.json"
    registry = CharacterRegistry(path)
    key = registry.register("小兔子", "book01_p01", "https://example.com/rabbit.png")
    registry.register("小兔子", "book01_p02")

    reloaded = CharacterRegistry(path)
    assert reloaded.key_for("小兔子") == key
    assert reloaded.references([key]) == ["https://example.com/rabbit.png"]
    assert reloaded._pages[key] == ["book01_p01", "book01_p02"]


def test_registry_alias_merges_same_character_across_pages(tmp_path) -> None:
    registry = CharacterRegistry(tmp_path / "characters.json")
    key = registry.key_for("人物")
    assert registry.alias("男孩", "人物") == key
    assert registry.alias("孩子", "人物") == key
    assert registry.key_for("男孩") == key


def test_registry_scope_and_reference_hash(tmp_path) -> None:
    registry = CharacterRegistry(tmp_path / "characters.json", scope="book01")
    key = registry.register("小兔子", "book01_p01", "https://example.com/r.png", reference_sha256="abc123")
    assert registry.reference_hashes([key]) == ["abc123"]
    other = CharacterRegistry(tmp_path / "other.json", scope="book02")
    assert other.key_for("小兔子") != key


def test_plan_segments_adds_continuity_note() -> None:
    segments = [
        segment("sally_p19_s01", "Sally 喊 Jane 过来。", "两个孩子拉纸袋。"),
        segment("sally_p19_s02", "纸袋破了。", "纸袋裂开。"),
    ]
    plans = plan_segments(segments, [{"label": "人物"}], continuity=True)
    assert "承接上一段" not in plans[0].prompt
    assert "承接上一段" in plans[1].prompt
    assert "Sally 喊 Jane 过来" in plans[1].prompt


def test_unsafe_prompt_rejected_before_provider(settings) -> None:
    from dataclasses import replace

    settings = replace(settings, safety_enabled=True, safety_blocklist=("暴力",))
    segments = [segment("sally_p19_s01", "这里出现暴力内容。", "孩子在草地上。")]
    with pytest.raises(AppError) as exc:
        plan_segments(segments, [{"label": "人物"}], settings=settings)
    assert exc.value.code == ErrorCode.SAFETY_BLOCKED
