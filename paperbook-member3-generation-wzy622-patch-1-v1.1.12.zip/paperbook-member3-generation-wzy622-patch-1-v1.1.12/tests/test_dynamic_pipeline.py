"""F03：动态执行适配器离线测试（fake Provider，不访问网络）。"""

from __future__ import annotations

import hashlib
import subprocess
from pathlib import Path

from agents.generation.config import Settings
from agents.generation.dynamic_pipeline import (
    compose_generated,
    generate_dynamic_clips,
    prepare_dynamic_page,
    run_dynamic_page,
)
from agents.generation.providers import ProviderResult, ProviderStatus, ProviderTask
from agents.generation.trust import MediaReview, SafetyDecision, SafetyReview, clips_digest


class FakeProvider:
    name = "fake"

    def __init__(self, sources: list[Path]):
        self._sources = list(sources)
        self.calls = 0

    def submit(self, plan, image_url, *, safety_check=None, execution=None, idempotency_key=None):
        self.calls += 1
        return ProviderTask(task_id=f"task-{self.calls}", provider="fake", model="fake-video")

    def wait(self, task_id):
        return ProviderResult(ProviderStatus.SUCCEEDED, video_url="https://dashscope-a717.oss-accelerate.aliyuncs.com/x.mp4")

    def download(self, url, dest: Path):
        source = self._sources.pop(0)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(source.read_bytes())
        return dest, hashlib.sha256(dest.read_bytes()).hexdigest()


def make_clip(ffmpeg: str, path: Path, color: str = "blue") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [
            ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
            "-f", "lavfi", "-i", f"color=c={color}:s=640x360:r=10",
            "-t", "5", "-pix_fmt", "yuv420p", str(path),
        ],
        check=True,
    )
    return path


def test_prepare_generate_compose(media_settings: Settings, page_image, sample_ocr: dict, sample_vlm: dict) -> None:
    prepared = prepare_dynamic_page("book01_p03", "3-6", media_settings, ocr=sample_ocr, vlm=sample_vlm)
    assert len(prepared.plans) == 2
    assert prepared.safety_digest

    sources = [
        make_clip(media_settings.ffmpeg, media_settings.data_dir / "src1.mp4", "blue"),
        make_clip(media_settings.ffmpeg, media_settings.data_dir / "src2.mp4", "green"),
    ]
    safety = SafetyReview(
        SafetyDecision.PASSED, "tester", "2026-11-12T00:00:00+00:00", (), prepared.safety_digest
    )
    generated = generate_dynamic_clips(prepared, FakeProvider(sources), "https://x/page.jpg", media_settings, safety_review=safety)
    assert len(generated.clips) == 2
    assert all(path.is_file() for path in generated.clips.values())

    hashes = {
        seg: hashlib.sha256(path.read_bytes()).hexdigest()
        for seg, path in generated.clips.items()
    }
    media = MediaReview(True, "tester", "2026-11-12T00:00:00+00:00", clips_digest(hashes))
    result = compose_generated(generated, media_settings, safety_review=safety, media_review=media)
    assert result.path.is_file()


def test_run_dynamic_page_adapter(media_settings: Settings, page_image, sample_ocr: dict, sample_vlm: dict) -> None:
    prepared = prepare_dynamic_page("book01_p03", "3-6", media_settings, ocr=sample_ocr, vlm=sample_vlm)
    safety = SafetyReview(
        SafetyDecision.PASSED, "tester", "2026-11-12T00:00:00+00:00", (), prepared.safety_digest
    )
    sources = [
        make_clip(media_settings.ffmpeg, media_settings.data_dir / "a1.mp4", "blue"),
        make_clip(media_settings.ffmpeg, media_settings.data_dir / "a2.mp4", "green"),
    ]

    def review_factory(clips):
        hashes = {
            seg: hashlib.sha256(path.read_bytes()).hexdigest()
            for seg, path in clips.items()
        }
        return MediaReview(True, "tester", "2026-11-12T00:00:00+00:00", clips_digest(hashes))

    result = run_dynamic_page(
        "book01_p03",
        "3-6",
        media_settings,
        "https://x/page.jpg",
        FakeProvider(sources),
        safety_review=safety,
        media_review_factory=review_factory,
        ocr=sample_ocr,
        vlm=sample_vlm,
    )
    assert result.path.is_file()
