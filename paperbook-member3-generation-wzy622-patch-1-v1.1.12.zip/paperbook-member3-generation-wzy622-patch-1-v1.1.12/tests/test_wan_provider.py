"""Wan Provider 协议测试：不访问真实网络。"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from agents.generation.errors import AppError, ErrorCode
from agents.generation.providers import (
    ProviderError,
    ProviderStatus,
    VideoPlan,
    WanConfig,
    WanProvider,
)


class FakeResponse:
    def __init__(self, payload: bytes):
        self._payload = payload
        self._pos = 0
        self.status = 200
        self.headers = {"Content-Type": "video/mp4"}

    def read(self, size: int = -1) -> bytes:
        if size < 0:
            size = len(self._payload) - self._pos
        chunk = self._payload[self._pos : self._pos + size]
        self._pos += len(chunk)
        return chunk

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False


class Recorder:
    def __init__(self, responses: list[dict] | None = None):
        self.requests = []
        self.responses = list(responses or [])

    def __call__(self, request, timeout=None):
        self.requests.append(request)
        payload = self.responses.pop(0) if self.responses else {}
        return FakeResponse(json.dumps(payload, ensure_ascii=False).encode("utf-8"))


def make_config(**overrides) -> WanConfig:
    base = dict(
        api_key="test-key",
        workspace_id="ws-test",
        region="cn-beijing",
        model="wan3.0-video",
        poll_interval_sec=0.01,
        timeout_sec=10,
    )
    base.update(overrides)
    return WanConfig(**base)


def test_submit_builds_dashscope_request() -> None:
    recorder = Recorder([{"output": {"task_id": "task-1", "task_status": "PENDING"}}])
    provider = WanProvider(make_config(), opener=recorder)

    plan = VideoPlan(
        segment_id="sally_p19_s01",
        prompt="两个孩子在草地上拉纸袋，纸袋被拉破",
        target_duration_sec=6,
    )
    task = provider.submit(plan, "https://example.com/page.jpg")

    assert task.task_id == "task-1"
    request = recorder.requests[0]
    assert request.full_url == "https://ws-test.cn-beijing.maas.aliyuncs.com/api/v1/services/aigc/video-generation/video-synthesis"
    assert request.get_header("X-dashscope-async") == "enable"
    assert request.get_header("Authorization") == "Bearer test-key"

    body = json.loads(request.data.decode("utf-8"))
    assert body["model"] == "wan3.0-video"
    assert body["input"]["media"] == [{"type": "first_frame", "url": "https://example.com/page.jpg"}]
    assert body["parameters"]["duration"] == 6
    assert body["parameters"]["resolution"] == "720P"
    assert body["parameters"]["ratio"] == "adaptive"
    assert body["parameters"]["audio"] is False


def test_submit_uses_reference_mode_and_never_mixes_first_frame() -> None:
    recorder = Recorder([{"output": {"task_id": "task-2"}}])
    provider = WanProvider(make_config(), opener=recorder)
    plan = VideoPlan(
        segment_id="sally_p19_s02",
        prompt="两个孩子继续拉纸袋",
        target_duration_sec=5,
        reference_image_urls=["https://example.com/rabbit.png"],
    )
    provider.submit(plan, "https://example.com/page.jpg")

    body = json.loads(recorder.requests[0].data.decode("utf-8"))
    media = body["input"]["media"]
    assert all(item["type"] == "reference_image" for item in media)
    assert [item["url"] for item in media] == [
        "https://example.com/page.jpg",
        "https://example.com/rabbit.png",
    ]
    assert "图1" in body["input"]["prompt"]


def test_poll_maps_running_and_succeeded() -> None:
    recorder = Recorder(
        [
            {"output": {"task_status": "RUNNING"}},
            {"output": {"task_status": "SUCCEEDED", "video_url": "https://dashscope-a717.oss-accelerate.aliyuncs.com/out.mp4"}},
        ]
    )
    provider = WanProvider(make_config(), opener=recorder)
    assert provider.poll("task-1").status is ProviderStatus.RUNNING
    result = provider.poll("task-1")
    assert result.status is ProviderStatus.SUCCEEDED
    assert result.video_url == "https://dashscope-a717.oss-accelerate.aliyuncs.com/out.mp4"


def test_poll_failed_carries_provider_error() -> None:
    recorder = Recorder([{"output": {"task_status": "FAILED", "code": "DataInspectionFailed", "message": "敏感内容"}}])
    result = WanProvider(make_config(), opener=recorder).poll("task-1")
    assert result.status is ProviderStatus.FAILED
    assert result.error_code == "DataInspectionFailed"
    assert result.error_message == "敏感内容"


def test_wait_times_out(monkeypatch) -> None:
    provider = WanProvider(make_config(timeout_sec=0.05), opener=Recorder([{"output": {"task_status": "RUNNING"}}] * 100))
    with pytest.raises(ProviderError) as exc:
        provider.wait("task-1")
    assert exc.value.code == ErrorCode.TIMEOUT


def test_download_writes_verified_bytes(tmp_path: Path) -> None:
    payload = b"\x00\x00\x00\x18ftypisom" + b"x" * 1024
    recorder = Recorder([payload])

    class RawResponse(FakeResponse):
        pass

    provider = WanProvider(make_config(), opener=lambda request, timeout=None: RawResponse(payload))
    dest = tmp_path / "clip.mp4"
    path, digest = provider.download("https://dashscope-a717.oss-accelerate.aliyuncs.com/out.mp4", dest)
    assert path.read_bytes() == payload
    assert len(digest) == 64
    assert not (tmp_path / "clip.mp4.part").exists()


def test_download_rejects_oversize() -> None:
    payload = b"x" * 64
    provider = WanProvider(
        make_config(max_clip_bytes=32),
        opener=lambda request, timeout=None: FakeResponse(payload),
    )
    with pytest.raises(ProviderError) as exc:
        provider.download("https://dashscope-a717.oss-accelerate.aliyuncs.com/out.mp4", Path("_test_tmp/oversize.mp4"))
    assert exc.value.code == ErrorCode.INVALID_PARAM


def test_submit_calls_safety_check_before_http() -> None:
    recorder = Recorder([{"output": {"task_id": "never"}}])
    provider = WanProvider(make_config(), opener=recorder)
    plan = VideoPlan(segment_id="sally_p19_s01", prompt="含暴力内容", target_duration_sec=5)

    def reject(prompt: str) -> None:
        raise AppError(ErrorCode.SAFETY_BLOCKED, "prompt 未通过安全审核")

    with pytest.raises(AppError) as exc:
        provider.submit(plan, "https://example.com/page.jpg", safety_check=reject)
    assert exc.value.code == ErrorCode.SAFETY_BLOCKED
    assert recorder.requests == []


def test_missing_config_is_unavailable() -> None:
    with pytest.raises(ProviderError) as exc:
        WanConfig.from_env({})
    assert exc.value.code == ErrorCode.UNAVAILABLE
