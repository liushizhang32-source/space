"""动态视频合成、来源/安全门禁与资产清单测试（不调用 Wan）。"""

from __future__ import annotations

import hashlib
import json
import subprocess
from pathlib import Path

import pytest

from agents.generation.config import Settings
from agents.generation.errors import AppError, ErrorCode, VideoError
from agents.generation.schemas import StoryDoc
from agents.generation.trust import (
    MediaReview,
    SafetyDecision,
    SafetyReview,
    clips_digest,
    sign_provenance,
    story_digest,
)
from agents.generation.video_dynamic import compose_dynamic_video

SECRET = "test-provenance-secret"


def make_clip(ffmpeg: str, path: Path, seconds: float, color: str = "blue") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [
            ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
            "-f", "lavfi", "-i", f"color=c={color}:s=640x360:r=10",
            "-t", f"{seconds:.2f}", "-pix_fmt", "yuv420p", str(path),
        ],
        check=True,
    )
    return path


def clips_for(settings: Settings, tmp_path: Path, seconds: float = 2.0) -> dict[str, Path]:
    base = settings.data_dir / "clips"
    return {
        "book01_p03_s01": make_clip(settings.ffmpeg, base / "c1.mp4", seconds, "blue"),
        "book01_p03_s02": make_clip(settings.ffmpeg, base / "c2.mp4", seconds, "green"),
    }


def hashes_of(clips: dict[str, Path]) -> dict[str, str]:
    return {seg: hashlib.sha256(path.read_bytes()).hexdigest() for seg, path in clips.items()}


def safety_review(story_dict: dict) -> SafetyReview:
    doc = StoryDoc.model_validate(story_dict)
    return SafetyReview(
        SafetyDecision.PASSED,
        "tester",
        "2026-11-12T00:00:00+00:00",
        (),
        story_digest(doc.model_dump(mode="json")),
    )


def media_review(clips: dict[str, Path]) -> MediaReview:
    return MediaReview(True, "tester", "2026-11-12T00:00:00+00:00", clips_digest(hashes_of(clips)))


def story(seconds: float = 1.0, page_id: str = "book01_p03", safety_pass: bool = True) -> dict:
    return {
        "schema_version": "1.0",
        "book_id": "book01",
        "page_id": page_id,
        "page_no": int(page_id[-2:]),
        "title": "测试页",
        "age_level": "3-6",
        "status": "ok",
        "segments": [
            {
                "segment_id": f"{page_id}_s01", "order": 1,
                "narration": "第一段旁白。", "scene": "第一段画面。",
                "duration_sec": seconds, "duration_source": "estimate", "highlight_object_ids": [],
            },
            {
                "segment_id": f"{page_id}_s02", "order": 2,
                "narration": "第二段旁白。", "scene": "第二段画面。",
                "duration_sec": seconds, "duration_source": "estimate", "highlight_object_ids": [],
            },
        ],
        "total_duration_sec": seconds * 2,
        "safety_pass": safety_pass,
        "safety_flags": [],
        "model": {"name": "mock", "version": "1"},
        "elapsed_ms": 1,
    }


def test_compose_local_clip_and_manifest(media_settings: Settings, tmp_path: Path) -> None:
    story_doc = story(1.0)
    clips = clips_for(media_settings, tmp_path)
    result = compose_dynamic_video(
        "book01_p03", story_doc, clips, media_settings,
        generation_mode="local_test",
        safety_review=safety_review(story_doc),
        media_review=media_review(clips),
        style_profile={"reference": "page.jpg"},
        characters=[{"key": "char_x", "label": "人物"}],
        provider="local", model="ltx-test",
    )
    assert result.path.is_file() and result.path.stat().st_size > 0
    assert result.doc["segments"][1]["end_sec"] == pytest.approx(2.0, abs=0.2)

    manifest = json.loads((media_settings.json_dir / "book01_p03_assets.json").read_text(encoding="utf-8"))
    assert manifest["generation_mode"] == "local_test"
    assert manifest["segments"][0]["clip"]["source_kind"] == "local_model"
    assert manifest["segments"][0]["clip"]["size_bytes"] > 0
    assert manifest["segments"][0]["clip"]["status"] == "ok"
    assert manifest["segments"][0]["clip"]["revision"]
    assert manifest["revision"]
    assert manifest["total_size_bytes"] > 0
    assert isinstance(manifest["subtitles_burned"], bool)
    assert manifest["segments"][1]["clip"]["provider"] == "local"


def test_real_video_accepts_valid_provenance(media_settings: Settings, tmp_path: Path) -> None:
    story_doc = story(1.0)
    clips = clips_for(media_settings, tmp_path)
    provenance = sign_provenance(
        provider="wan", model="wan3.0-video-prime",
        task_ids={"book01_p03_s01": "task-1", "book01_p03_s02": "task-2"},
        clip_hashes=hashes_of(clips), secret=SECRET,
    )
    result = compose_dynamic_video(
        "book01_p03", story_doc, clips, media_settings,
        generation_mode="real_video",
        safety_review=safety_review(story_doc),
        media_review=media_review(clips),
        provenance=provenance,
        provenance_secret_value=SECRET,
    )
    manifest = json.loads((media_settings.json_dir / "book01_p03_assets.json").read_text(encoding="utf-8"))
    assert manifest["generation_mode"] == "real_video"
    assert manifest["segments"][0]["clip"]["source_kind"] == "ai_video"
    assert manifest["segments"][0]["clip"]["task_ref"] == "task-1"
    assert result.path.is_file()


def test_real_video_requires_provenance(media_settings: Settings, tmp_path: Path) -> None:
    story_doc = story(1.0)
    clips = clips_for(media_settings, tmp_path)
    with pytest.raises(AppError) as exc:
        compose_dynamic_video(
            "book01_p03", story_doc, clips, media_settings,
            generation_mode="real_video",
            safety_review=safety_review(story_doc),
            media_review=media_review(clips),
        )
    assert exc.value.code == ErrorCode.SAFETY_BLOCKED


def test_real_video_rejects_forged_provenance(media_settings: Settings, tmp_path: Path) -> None:
    story_doc = story(1.0)
    clips = clips_for(media_settings, tmp_path)
    forged = sign_provenance(
        provider="wan", model="wan3.0-video-prime",
        task_ids={"book01_p03_s01": "t1", "book01_p03_s02": "t2"},
        clip_hashes=hashes_of(clips), secret="wrong-secret",
    )
    with pytest.raises(AppError):
        compose_dynamic_video(
            "book01_p03", story_doc, clips, media_settings,
            generation_mode="real_video",
            safety_review=safety_review(story_doc),
            media_review=media_review(clips),
            provenance=forged,
            provenance_secret_value=SECRET,
        )


def test_cross_page_story_rejected(media_settings: Settings, tmp_path: Path) -> None:
    story_doc = story(1.0, page_id="book01_p03")
    clips = clips_for(media_settings, tmp_path)
    with pytest.raises(AppError) as exc:
        compose_dynamic_video(
            "book01_p04", story_doc, clips, media_settings,
            generation_mode="local_test",
            safety_review=safety_review(story_doc),
            media_review=media_review(clips),
        )
    assert exc.value.code == ErrorCode.INVALID_PARAM


def test_safety_false_rejected(media_settings: Settings, tmp_path: Path) -> None:
    story_doc = story(1.0, safety_pass=False)
    clips = clips_for(media_settings, tmp_path)
    with pytest.raises(AppError) as exc:
        compose_dynamic_video(
            "book01_p03", story_doc, clips, media_settings,
            generation_mode="local_test",
            safety_review=safety_review(story_doc),
            media_review=media_review(clips),
        )
    assert exc.value.code == ErrorCode.SAFETY_BLOCKED


def test_tampered_story_after_review_rejected(media_settings: Settings, tmp_path: Path) -> None:
    original = story(1.0)
    review = safety_review(original)
    tampered = json.loads(json.dumps(original))
    tampered["segments"][0]["narration"] = "被篡改的旁白。"
    clips = clips_for(media_settings, tmp_path)
    with pytest.raises(AppError) as exc:
        compose_dynamic_video(
            "book01_p03", tampered, clips, media_settings,
            generation_mode="local_test",
            safety_review=review,
            media_review=media_review(clips),
        )
    assert exc.value.code == ErrorCode.SAFETY_BLOCKED


def test_missing_safety_review_rejected(media_settings: Settings, tmp_path: Path) -> None:
    clips = clips_for(media_settings, tmp_path)
    with pytest.raises(AppError) as exc:
        compose_dynamic_video(
            "book01_p03", story(1.0), clips, media_settings,
            generation_mode="local_test",
            media_review=media_review(clips),
        )
    assert exc.value.code == ErrorCode.SAFETY_BLOCKED


def test_stale_media_review_rejected(media_settings: Settings, tmp_path: Path) -> None:
    story_doc = story(1.0)
    clips = clips_for(media_settings, tmp_path)
    stale = media_review({"x": make_clip(media_settings.ffmpeg, media_settings.data_dir / "clips" / "other.mp4", 2.0)})
    with pytest.raises(AppError):
        compose_dynamic_video(
            "book01_p03", story_doc, clips, media_settings,
            generation_mode="local_test",
            safety_review=safety_review(story_doc),
            media_review=stale,
        )


def test_invalid_generation_mode_rejected(media_settings: Settings, tmp_path: Path) -> None:
    story_doc = story(1.0)
    clips = clips_for(media_settings, tmp_path)
    with pytest.raises(AppError) as exc:
        compose_dynamic_video(
            "book01_p03", story_doc, clips, media_settings,
            generation_mode="not_a_mode",
            safety_review=safety_review(story_doc),
            media_review=media_review(clips),
        )
    assert exc.value.code == ErrorCode.INVALID_PARAM


def test_missing_clip_fails_without_static_fallback(media_settings: Settings, tmp_path: Path) -> None:
    story_doc = story(1.0)
    clips = clips_for(media_settings, tmp_path)
    one = {"book01_p03_s01": clips["book01_p03_s01"]}
    with pytest.raises(VideoError, match="缺少 AI clip"):
        compose_dynamic_video(
            "book01_p03", story_doc, one, media_settings,
            generation_mode="local_test",
            safety_review=safety_review(story_doc),
            media_review=media_review(clips),
        )


def test_clip_shorter_than_narration_fails(media_settings: Settings, tmp_path: Path) -> None:
    story_doc = story(1.0)
    clips = clips_for(media_settings, tmp_path, seconds=0.5)
    with pytest.raises(VideoError, match="短于旁白"):
        compose_dynamic_video(
            "book01_p03", story_doc, clips, media_settings,
            generation_mode="local_test",
            safety_review=safety_review(story_doc),
            media_review=media_review(clips),
        )


def test_duplicate_clip_rejected(media_settings: Settings, tmp_path: Path) -> None:
    story_doc = story(1.0)
    same = make_clip(media_settings.ffmpeg, media_settings.data_dir / "clips" / "same.mp4", 2.0)
    clips = {"book01_p03_s01": same, "book01_p03_s02": same}
    with pytest.raises(VideoError, match="复用了同一 clip"):
        compose_dynamic_video(
            "book01_p03", story_doc, clips, media_settings,
            generation_mode="local_test",
            safety_review=safety_review(story_doc),
            media_review=media_review(clips),
        )


def test_external_clip_rejected(media_settings: Settings, tmp_path: Path) -> None:
    story_doc = story(1.0)
    outside = make_clip(media_settings.ffmpeg, tmp_path / "outside.mp4", 2.0)
    inside = make_clip(media_settings.ffmpeg, media_settings.data_dir / "clips" / "inside.mp4", 2.0)
    clips = {"book01_p03_s01": outside, "book01_p03_s02": inside}
    with pytest.raises(AppError) as exc:
        compose_dynamic_video(
            "book01_p03", story_doc, clips, media_settings,
            generation_mode="local_test",
            safety_review=safety_review(story_doc),
            media_review=media_review(clips),
        )
    assert exc.value.code == ErrorCode.INVALID_PARAM
