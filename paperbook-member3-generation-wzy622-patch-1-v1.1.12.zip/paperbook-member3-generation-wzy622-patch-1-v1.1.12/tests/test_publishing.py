"""F06：三件套原子发布与回滚。"""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from agents.generation.errors import VideoPublishError
from agents.generation import publishing


def test_publish_bundle_replaces_all(tmp_path: Path) -> None:
    targets = {}
    for name in ("video.mp4", "video.json", "assets.json"):
        target = tmp_path / name
        target.write_text("old", encoding="utf-8")
        staged = tmp_path / f"staged_{name}"
        staged.write_text("new", encoding="utf-8")
        targets[target] = staged

    publishing.publish_bundle("book01_p03", targets)
    for target in targets:
        assert target.read_text(encoding="utf-8") == "new"
        assert not list(tmp_path.glob(f"{target.name}.bak.*"))


def test_publish_bundle_rolls_back_on_failure(tmp_path: Path, monkeypatch) -> None:
    targets = {}
    for name in ("video.mp4", "video.json", "assets.json"):
        target = tmp_path / name
        target.write_text("old", encoding="utf-8")
        staged = tmp_path / f"staged_{name}"
        staged.write_text("new", encoding="utf-8")
        targets[target] = staged

    real_replace = os.replace

    def flaky_replace(src, dst):
        if str(dst).endswith("assets.json") and "staged" in str(src):
            raise OSError("simulated manifest publish failure")
        return real_replace(src, dst)

    monkeypatch.setattr(publishing.os, "replace", flaky_replace)
    with pytest.raises(VideoPublishError):
        publishing.publish_bundle("book01_p03", targets)

    for target in targets:
        assert target.read_text(encoding="utf-8") == "old"
        assert not list(tmp_path.glob(f"{target.name}.bak.*"))
