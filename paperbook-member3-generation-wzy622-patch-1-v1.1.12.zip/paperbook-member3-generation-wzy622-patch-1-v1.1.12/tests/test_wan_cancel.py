"""F04/F15：取消回执、unknown、错误分类与脱敏（不访问真实网络）。"""

from __future__ import annotations

import io
import json
import urllib.error

import pytest

from agents.generation.errors import ErrorCode
from agents.generation.execution import ExecutionContext
from agents.generation.providers import ProviderStatus, VideoPlan, WanConfig, WanProvider
from agents.generation.providers.wan import ProviderError


class Response:
    def __init__(self, payload: dict):
        self._body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.status = 200

    def read(self, size: int = -1) -> bytes:
        return self._body if size < 0 else self._body[:size]

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False


def config() -> WanConfig:
    return WanConfig(api_key="k", workspace_id="ws", poll_interval_sec=0.01, timeout_sec=2)


def plan() -> VideoPlan:
    return VideoPlan(segment_id="sally_p19_s01", prompt="p", target_duration_sec=5)


def test_cancel_confirmed() -> None:
    calls = []

    def opener(request, timeout=None):
        calls.append(request)
        return Response({"output": {"task_status": "CANCELED"}})

    receipt = WanProvider(config(), opener=opener).cancel("t-1")
    assert receipt.status is ProviderStatus.CANCELLED
    assert receipt.confirmed
    assert calls[0].get_method() == "POST"
    assert calls[0].full_url.endswith("/api/v1/tasks/t-1/cancel")


def test_cancel_unsupported_is_unknown() -> None:
    def opener(request, timeout=None):
        body = io.BytesIO(b'{"code":"UnsupportedOperation","message":"cannot cancel"}')
        raise urllib.error.HTTPError(request.full_url, 400, "Bad", {}, body)

    receipt = WanProvider(config(), opener=opener).cancel("t-1")
    assert receipt.status is ProviderStatus.UNKNOWN
    assert receipt.supported is False
    assert not receipt.confirmed


def test_poll_unknown_state_not_failed() -> None:
    provider = WanProvider(config(), opener=lambda request, timeout=None: Response({"output": {"task_status": "NEW_STATE"}}))
    result = provider.poll("t-1")
    assert result.status is ProviderStatus.UNKNOWN
    assert result.error_code == "unknown_state"


def test_submit_carries_execution_identity() -> None:
    captured = {}

    def opener(request, timeout=None):
        captured["body"] = json.loads(request.data.decode("utf-8"))
        return Response({"output": {"task_id": "t-1"}})

    ctx = ExecutionContext(job_id="job", generation=1, attempt=2, fence="fence")
    task = WanProvider(config(), opener=opener).submit(plan(), "https://example.com/page.jpg", execution=ctx)
    assert task.fence == "fence"
    assert task.idempotency_key == "job:1:2:fence:sally_p19_s01"
    assert len(task.request_hash) == 64
    assert captured["body"]["model"] == "wan3.0-video"


def test_error_detail_is_redacted() -> None:
    def opener(request, timeout=None):
        body = io.BytesIO(
            b'{"code":"Bad","message":"sk-abcdef1234567890 Signature=SECRETVALUE&OSSAccessKeyId=AK"}'
        )
        raise urllib.error.HTTPError(request.full_url, 400, "Bad", {}, body)

    provider = WanProvider(config(), opener=opener)
    with pytest.raises(ProviderError) as exc:
        provider.poll("t-1")
    assert exc.value.kind == "terminal"
    assert "sk-***" in (exc.value.detail or "")
    assert "SECRETVALUE" not in (exc.value.detail or "")
    assert "AK" not in (exc.value.detail or "").replace("OSS", "")
