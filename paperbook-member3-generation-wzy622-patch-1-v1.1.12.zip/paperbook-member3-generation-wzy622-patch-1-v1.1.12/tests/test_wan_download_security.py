"""F07：下载 URL/域名/内容/临时文件安全（不访问真实网络）。"""

from __future__ import annotations

import pytest

from agents.generation.errors import ErrorCode
from agents.generation.providers.wan import (
    DownloadUrlError,
    ProviderError,
    WanConfig,
    WanProvider,
    validate_download_url,
)

GOOD = "https://dashscope-a717.oss-accelerate.aliyuncs.com/out.mp4"


class Resp:
    def __init__(self, payload: bytes, content_type: str = "video/mp4"):
        self._payload = payload
        self._pos = 0
        self.headers = {"Content-Type": content_type}

    def read(self, size: int = -1) -> bytes:
        if size < 0:
            size = len(self._payload) - self._pos
        chunk = self._payload[self._pos : self._pos + size]
        self._pos += len(chunk)
        return chunk

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False


def config(**overrides) -> WanConfig:
    base = dict(api_key="k", workspace_id="ws", timeout_sec=5)
    base.update(overrides)
    return WanConfig(**base)


def provider(payload: bytes, content_type: str = "video/mp4", **overrides) -> WanProvider:
    return WanProvider(config(**overrides), opener=lambda request, timeout=None: Resp(payload, content_type))


def test_rejects_http_scheme() -> None:
    with pytest.raises(DownloadUrlError):
        validate_download_url("http://dashscope-a717.oss-accelerate.aliyuncs.com/x.mp4")


def test_rejects_private_or_hostile_host() -> None:
    for url in (
        "https://127.0.0.1/x.mp4",
        "https://localhost/x.mp4",
        "https://evil.example.com/x.mp4",
        "https://user:pass@dashscope-a717.oss-accelerate.aliyuncs.com/x.mp4",
    ):
        with pytest.raises(DownloadUrlError):
            validate_download_url(url)


def test_download_rejects_html(tmp_path) -> None:
    with pytest.raises(ProviderError) as exc:
        provider(b"<html>not a video</html>", "text/html").download(GOOD, tmp_path / "x.mp4")
    assert "不是视频类型" in exc.value.msg
    assert not list(tmp_path.glob("*.part"))


def test_download_rejects_invalid_mp4(tmp_path) -> None:
    with pytest.raises(ProviderError) as exc:
        provider(b"not an mp4 at all").download(GOOD, tmp_path / "x.mp4")
    assert exc.value.code == ErrorCode.INVALID_PARAM
    assert not list(tmp_path.glob("*.part"))


def test_download_oversize_cleans_part(tmp_path) -> None:
    payload = b"\x00\x00\x00\x18ftypisom" + b"x" * 64
    with pytest.raises(ProviderError):
        provider(payload, max_clip_bytes=16).download(GOOD, tmp_path / "x.mp4")
    assert not list(tmp_path.glob("*.part"))
