"""F05：执行身份、request hash、幂等键与 typed 事件。"""

from __future__ import annotations

import pytest

from agents.generation.execution import (
    EventKind,
    ExecutionContext,
    ProviderEvent,
    request_hash,
)


def test_execution_context_key_is_stable() -> None:
    ctx = ExecutionContext(job_id="job-1", generation=2, attempt=1, fence="fence-9")
    assert ctx.segment_key("book01_p03_s01") == "job-1:2:1:fence-9:book01_p03_s01"
    assert ctx.idempotency_key("book01_p03", "book01_p03_s01").startswith("job-1:2:1:fence-9")


def test_execution_context_rejects_bad_values() -> None:
    with pytest.raises(ValueError):
        ExecutionContext(job_id="", generation=0, attempt=0, fence="f")
    with pytest.raises(ValueError):
        ExecutionContext(job_id="j", generation=-1, attempt=0, fence="f")
    with pytest.raises(ValueError):
        ExecutionContext(job_id="j", generation=0, attempt=0, fence="")


def test_request_hash_is_order_insensitive() -> None:
    a = {"model": "wan", "input": {"prompt": "x", "media": [1, 2]}}
    b = {"input": {"media": [1, 2], "prompt": "x"}, "model": "wan"}
    assert request_hash(a) == request_hash(b)
    assert request_hash(a) != request_hash({**a, "model": "other"})


def test_provider_event_keeps_unknown_distinct() -> None:
    event = ProviderEvent.from_status(status="unknown", task_id="t", fence="f", raw_status="NEW_STATE")
    assert event.kind is EventKind.UNKNOWN
    assert event.raw_status == "NEW_STATE"
