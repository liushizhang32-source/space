"""跨运行 POC 台账与重试计数规则测试。"""

from __future__ import annotations

import time
from pathlib import Path

import pytest

from agents.generation.poc_gate import PocApproval, PocGateError
from agents.generation.poc_ledger import GlobalLimits, PocLedger, approval_id
from agents.generation.retry import is_billable_submit, should_retry


def approval(**overrides) -> PocApproval:
    base = dict(
        approved_by="lead",
        purpose="test",
        region="cn-beijing",
        max_calls=2,
        max_seconds=10,
        max_cost_usd=2.0,
        expires_at=int(time.time()) + 3600,
        input_sha256="",
    )
    base.update(overrides)
    return PocApproval(**base)


def test_cumulative_calls_rejected(tmp_path: Path) -> None:
    ledger = PocLedger(tmp_path / "ledger.json")
    a = approval()
    ledger.reserve(a, approval_id="a1", calls=2, seconds=10, cost_usd=1.0)
    with pytest.raises(PocGateError):
        ledger.reserve(a, approval_id="a1", calls=1, seconds=5, cost_usd=0.5)
    assert ledger.used_for("a1")["calls"] == 2


def test_cumulative_survives_reload(tmp_path: Path) -> None:
    path = tmp_path / "ledger.json"
    PocLedger(path).reserve(approval(), approval_id="a1", calls=1, seconds=5, cost_usd=0.5)
    reloaded = PocLedger(path)
    assert reloaded.used_for("a1")["calls"] == 1
    assert reloaded.totals["cost_usd"] == pytest.approx(0.5)


def test_global_limits(tmp_path: Path) -> None:
    ledger = PocLedger(tmp_path / "ledger.json")
    ledger.reserve(approval(), approval_id="a1", calls=1, seconds=5, cost_usd=0.5)
    with pytest.raises(PocGateError):
        ledger.reserve(
            approval(),
            approval_id="a2",
            calls=1,
            seconds=5,
            cost_usd=0.5,
            global_limits=GlobalLimits(max_calls=1),
        )


def test_approval_id_stable() -> None:
    assert approval_id("token") == approval_id("token")
    assert len(approval_id("token")) == 16


def test_retry_rules() -> None:
    assert should_retry("timeout", attempt=1, max_attempts=2)
    assert should_retry("rate_limited", attempt=1, max_attempts=2)
    assert not should_retry("auth", attempt=1, max_attempts=2)
    assert not should_retry("terminal", attempt=1, max_attempts=2)
    assert not should_retry("unknown", attempt=1, max_attempts=2)
    assert not should_retry("timeout", attempt=2, max_attempts=2)
    assert is_billable_submit(http_sent=True)
    assert not is_billable_submit(http_sent=False)
