# 成员 3 代码包 · Story / TTS / AI Video

| 项 | 内容 |
|---|---|
| 包名 | `paperbook-member3-generation-wzy622-patch-1-v1.1.12` |
| 版本 | v1.1.12（V1.1.8 技术准备，累积 v1.1.9） |
| 分支 | `wzy622-patch-1` |
| 打包日期 | 2026-11-12 |
| 对应契约 | `docs/API_v1.0.md` C3 / C4 / A6；v1.1 资产清单为独立文件 |
| 归属 | 成员 3（Story / TTS / AI Video / 资产关联） |
| 测试 | **213 passed**（`python -m pytest`） |
| 历史版本 | v1.1.0 ～ v1.1.9 包与报告原样保留 |

## 1. 本版新增

| 文件 | 作用 |
|---|---|
| `providers/` | Wan 3.0/2.7：submit/poll/wait/cancel/download、首帧/参考图、`audio=false` |
| `trust.py` | 模式/来源枚举、SafetyReview/MediaReview、HMAC provenance |
| `execution.py` | ExecutionContext、request hash、幂等键、typed event |
| `publishing.py` | mp4 + video.json + assets.json 三件套原子发布/回滚 |
| `poc_gate.py` | POC 授权/预算/次数/时长/费用/输入 SHA256 门禁 |
| `poc_ledger.py` | 跨运行调用/时长/费用累计台账 |
| `retry.py` | 统一重试/计数规则 |
| `approval.py` | M1 签发、M3 只验证的 Token claims/验证客户端 |
| `budget.py` | 统一预算接口 + Fake 预算服务 |
| `provider_adapter.py` | 验证→预留→Provider→资产 handoff |
| `providers/fake.py` | 确定性 Fake Provider |
| `dynamic_pipeline.py` | 动态执行适配器：prepare → generate → 媒体审核 → compose |
| `story/planner.py` | 保书页 prompt、连贯性、角色 scope/别名/参考 hash |
| `video_dynamic.py` | 真实 clip + TTS + 字幕；缺 clip/过短失败 |
| `assets.py` | 资产清单：时间轴/clip/audio/asset ID/hash/size/status/revision |
| `requirements.lock` | 精确依赖版本 |

POC-01 证据：`artifacts/wan_poc/poc_s01.mp4`（Wan 3.0，806×1140，30fps，5s，无音轨）。

## 2. 包内容

```
paperbook-member3-generation-wzy622-patch-1-v1.1.12/
├── README.md / PACKAGE.md / requirements.txt / requirements.lock / pytest.ini
├── .env.example / .gitignore
├── agents/generation/        story / tts / video / providers / trust / execution / publishing / poc_gate / dynamic_pipeline
├── tests/                    213 项用例
├── logs/                     分组/批量 pytest 原始日志
├── docs/                     实现说明、IO 示例、十一轮报告、Wan/整改/技术准备说明、Schema
├── examples/                 示例输入 + 安装脚本
├── artifacts/                静态链路产物 + Wan POC 证据
└── scripts/                  verify.ps1 / verify.sh / wan_poc*.py
```

**不含**：真实 API Key、`.env`、模型权重、ffmpeg 二进制、`_vendor`、POC 输入视频、缓存。

## 3. 环境要求

- Python 3.10+（实测 3.12.14）
- `ffmpeg` / `ffprobe`（缺失时明确 2004）
- 真实 Wan 模式：`WAN_API_KEY`、`WAN_WORKSPACE_ID`、`WAN_REGION`（同地域）
- POC：额外需要负责人签发的 `POC_APPROVAL_TOKEN` / `POC_APPROVAL_SECRET`

## 4. 验证

```bash
pip install -r requirements.lock
python -m pytest                 # 213 passed
python examples/install_example.py
python -m agents.generation run --page-id book01_p03      # 静帧 mock 链路
```

## 5. 交付物

| 产物 | 说明 |
|---|---|
| `json/{page_id}_story.json` | C3，未变 |
| `json/{page_id}_video.json` + `videos/*.mp4` | C4，未变 |
| `json/{page_id}_assets.json` | v1.1 资产清单 |
| `json/{page_id}_safety.json` | 内部安全状态 sidecar（unreviewed） |
| `POST /api/v1/tts` | A6，未变 |

## 6. 配置（关键项）

| 变量 | 默认 | 作用 |
|---|---|---|
| `WAN_API_KEY` / `WAN_WORKSPACE_ID` | 空 | 真实 Wan；缺则失败关闭 |
| `WAN_MODEL` | `wan3.0-video-prime` | 模型 |
| `WAN_RESOLUTION` | `720P` | 480P/720P/1080P |
| `WAN_DOWNLOAD_HOSTS` | OSS 域名白名单 | 下载域名 |
| `POC_APPROVAL_TOKEN` / `SECRET` | 空 | 无则不提交真实任务 |
| `TTS_ENGINE` | `auto` | silent/http |
| `SAFETY_ENABLED` | 0 | 统一安全开关 |

## 7. 已知限制

1. 真实 Wan POC 未执行：缺负责人授权 token；额度充值不等于授权；
2. 真实 TTS 未接，silent 标 `estimate`；
3. F04/F05/F06 的真实取消、M1 持久台账/fence/发布门禁未接；
4. F10 真实双页多段角色一致性未评测；
5. F11 生成媒体供应商侧审核未实现；
6. F03 动态适配器已离线完成，CLI/公共入口未接线；
7. F14/F15 完整 CI、CLI 日志脱敏未完成；
8. 无 git/PR（远程不可达）。

## 8. 分支与 PR

```bash
git checkout -b wzy622-patch-1 origin/dev
git add -A
git commit -m "fix(generation): v1.1.7 F01-F15 offline rectification"
git push -u origin wzy622-patch-1
# PR: wzy622-patch-1 -> dev
```
