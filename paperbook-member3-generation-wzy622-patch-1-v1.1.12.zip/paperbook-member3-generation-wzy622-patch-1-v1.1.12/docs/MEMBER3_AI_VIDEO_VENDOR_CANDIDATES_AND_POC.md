# 成员 3：AI 视频供应商候选与 POC 执行计划（G1 前置）

| 项 | 内容 |
|---|---|
| 依据 | ZSZB-V1-DYNAMIC-EXEC、ZSZB-V1.1 统一实施规范（U-B/G/H/I/L/M）、成员3影响评估 |
| 状态 | **调研与方案，未调用任何付费 API、未改业务代码** |
| 目的 | 为 G1 POC 提供候选、测试矩阵、成本/时延记录口径与决策请求 |
| 结论 | 首选可灵 Kling 4.0 做 POC；Vidu 作低价备选；Runway 作质量对照；自建开源作离线备选。最终由队长/业主拍板 |

> 说明：以下能力来自厂商官方文档检索（2026-11 可访问版本），POC 前必须用实际账号复核；本文不写未核实的价格数字。

---

## 1. 筛选标准（来自规范）

| 维度 | 要求 |
|---|---|
| 一段一 clip | 每个 Story Segment 独立生成、独立任务、独立证据 |
| 时长 | 能覆盖 TTS 实测时长；短了不能截旁白/循环/静帧补时 |
| 输入 | 支持图生视频（书页/角色参考图），最好支持多参考图/角色元素 |
| 角色一致性 | 跨段同一角色可辨认；有参考图/元素能力优先 |
| 异步 API | submit / poll / download / cancel / lookup，任务 ID 可持久化 |
| 幂等 | 支持幂等键或可按外部 ID 查询，避免重复扣费 |
| 输出 | MP4/H.264，720p 起，竖屏 9:16 或可裁切；可去掉自带音轨 |
| 数据 | 国内可访问、数据保留/删除条款可接受、支持儿童绘本授权场景 |
| 成本 | 按秒/按次可预估，失败/重试可对账 |
| 稳定性 | 有公开 SLA/配额/错误码；API 版本可追踪 |

---

## 2. 候选对比（官方文档已核部分）

| 供应商/模型 | 时长 | 分辨率 | 图生视频/参考 | 角色一致性 | 异步任务 API | 国内接入 | 备注 |
|---|---|---|---|---|---|---|---|
| **可灵 Kling 4.0** | 单次最长 30s（4.0）；3–20s（4.0 Flash） | 720p/1080p（4K 规划中） | 图生视频、Omni reference（最多 10 图 + 5 视频、15 输入） | 元素/多图参考，跨段一致性需实测 | 有任务查询/回调，支持 API Key | 是 | **首选**：时长覆盖最接近 TTS 实测；按总时长计费 |
| **可灵 Kling 4.0 Flash** | 3–20s | 720p | 文/图/Omni reference | 同上 | 同上 | 是 | 更便宜/更快，画质略低；适合先跑通 |
| **Vidu Q1 / Q2** | Q1 首尾帧默认 5s（可选 5）；其他模型档位需核 | 1080p（Q1） | 首尾帧、参考图（Q2/Q3 能力需核） | 参考图能力需实测 | 有 task_id + 状态查询 + 回调 | 是 | **低价备选**；时长档位可能固定，需验证 |
| **Runway Gen-4.5 / 聚合 API** | 5s/10s（Gen-4.5 示例 5s） | 720p/1080p | 图生视频、Characters 角色 | Characters 产品较成熟 | 有任务 API/SDK | 需评估 | 质量对照；国内网络/合规/成本待核 |
| **MiniMax 海螺** | 需核（i2v 文档存在） | 需核 | 图生视频 | 需核 | 有异步任务 | 是 | 备选，先核时长/参考图 |
| **Google Veo（Gemini/Vertex）** | 约 8s（需核） | 720p/1080p | 图生视频 | 参考图能力需核 | 有长任务 API | 需评估 | 质量强，但时长档位/区域/成本不利 |
| **OpenAI Sora API** | 需核 | 需核 | 需核 | 需核 | 需核 | 需评估 | 不作为首选，待可用性确认 |
| **开源：Wan2.x / HunyuanVideo / CogVideoX** | 自定 | 自定 | 图生视频 | 需自建参考链路 | 自建队列 | 本地 | 无按次费用但有 GPU/运维成本；适合离线兜底 |

官方来源：
- Kling API 更新（4.0 / 4.0 Flash 时长、分辨率、Omni reference）：https://kling.ai/document-api/updates/api.md
- Vidu 首尾帧任务 API（5s、1080p、task 状态、24h URL、off-peak）：https://platform.vidu.cn/docs/start-end-to-video.md
- Runway API（Kling 4.0 聚合、Gen-4.5 示例、Characters）：https://docs.dev.runwayml.com/
- MiniMax 图生视频 API 入口：https://platform.minimax.io/docs/api-reference/video-generation-i2v

> 重要：Kling 生成内容 **30 天后自动清理**；Vidu 结果 URL **24 小时有效**。POC 必须“生成后立即下载 + 校验 + 落私有存储”，不能把厂商 URL 当 `video_url`。

---

## 3. 推荐 shortlist

### 3.1 首选：可灵 Kling 4.0（POC 主供应商）

理由：
1. **时长覆盖最好**：3–20s（Flash）/最长 30s，能覆盖大多数 TTS 段（6–15s），减少“clip 短于旁白”的重规划；
2. **参考能力强**：图生视频 + Omni reference（多图/元素），是跨段角色一致性的现实路径；
3. **国内可访问**，任务查询/回调齐全，按总时长计费，便于成本对账；
4. 有 4.0 Flash 低价档，可先用 Flash 跑通协议，再用 4.0 做质量对照。

风险：
- 参考图/元素是否真能稳定保持“同一只兔子”的外观，必须 POC 人工评审；
- 30 天清理，必须即时下载；
- 生成内容自带音轨需移除；
- 时长参数与实际输出可能不完全一致，需实测容差。

### 3.2 备选：Vidu Q1/Q2

理由：国内、1080p、首尾帧/参考图、off-peak 更便宜；适合成本敏感或 Kling 额度不足时。
风险：时长档位可能只有 5s（Q1 首尾帧），与 TTS 对齐需重规划；角色一致性能力需实测。

### 3.3 质量对照：Runway（Gen-4.5 / Characters）

理由：角色一致性产品化程度高、模型质量稳定；适合做“质量上限”对照。
风险：国内访问/合规/成本不确定，不作为主链路。

### 3.4 离线兜底：开源 Wan/HunyuanVideo

理由：不按次付费、可内网部署；适合演示断网兜底。
风险：GPU 成本、部署/调优工作量大、生成质量/时长不稳定。

---

## 4. POC 设计（G1）

### 4.1 目标

用**一页真实绘本、2 个 Segment**，验证：

1. 能否按 `target_duration_sec` 生成覆盖旁白的动态 clip；
2. 两次生成能否保持同一角色可辨认；
3. 单 clip 的真实成本、排队/生成/下载时延；
4. submit/poll/download/cancel/lookup 协议是否满足成员1的 ledger 设计；
5. 输出是否可校验（容器/编码/分辨率/fps/时长/hash/全解码）；
6. 反例（静图、zoompan、固定片）能否被门禁拒绝。

### 4.2 输入

- 页面：`sally_p19`（有文字、2 个孩子）或 `boom_p01`（夜景、多物体）；
- Story：2 段，narration 由真实 OCR/VLM 生成；
- TTS：先跑真实 TTS，得到 2 个实测时长（例如 6.2s / 8.7s）；
- 提示词：`video_plan.prompt` 由 Planner 生成，包含主体动作 + 场景变化；
- 参考图：整页图 + 角色裁切图（若供应商支持）。

### 4.3 测试矩阵

| # | 场景 | 断言 |
|---|---|---|
| P1 | 正常 submit → poll → download | 拿到 task_id、最终 MP4、时长 ≥ TTS、可解码 |
| P2 | 同一 idempotency_key 重复 submit | 不产生第二次扣费/第二个任务，或可 lookup 原任务 |
| P3 | submit 响应丢失（模拟） | 能用 key/task 查回，不盲目重投 |
| P4 | cancel | 任务取消/停止计费，或明确 unsupported |
| P5 | 429/5xx | 按 Retry-After/退避，不无限重试 |
| P6 | 时长对齐 | clip 覆盖旁白；超长裁尾不截旁白；过短走重规划 |
| P7 | 角色一致性 | 2 段同一角色人工可辨认（同参考图/元素） |
| P8 | 输出音轨 | 默认移除供应商音轨，用独立 TTS |
| P9 | 伪媒体/HTML/截断 | 下载校验拒绝 |
| P10 | 静图/zoompan/固定片负例 | 不得判 REAL_VIDEO 成功 |
| P11 | 成本/时延 | 记录单 clip 费用、排队/生成/下载 P50/P95 |
| P12 | 数据保留 | 生成后立即下载；30 天/24h 过期前完成归档 |

### 4.4 记录口径

每个 clip 记录：

```
job_id / generation_id / segment_id / clip_id
provider / model / provider_task_ref（脱敏）
request_hash / prompt_hash / reference_hash
submit_at / first_poll_at / succeeded_at / downloaded_at
duration_requested / duration_actual / resolution / fps / has_audio
sha256 / bytes / ffprobe_json / decode_exit_code
cost_quote / cost_actual / currency
human_review: 角色一致性 / 动作是否发生 / 是否静图 / 结论
```

### 4.5 通过标准（建议，待业主批准）

- 每段 1 个独立 clip，来源/任务/哈希可追溯；
- clip 时长 ≥ TTS 实测 − 0.2s；不足则重规划，不截旁白；
- 720p 起，竖屏可裁切；全解码退出 0；
- 2 段角色人工可辨认；
- 单 clip 成本、单页成本可核算，失败/重试计入；
- 静图/zoompan/固定片负例 100% 拒绝；
- 以上未批准前只出测量报告，不宣称验收通过。

---

## 5. 需要队长/业主先给的东西

| 项 | 用途 | 不给的后果 |
|---|---|---|
| 供应商与账号（API Key） | 真实 submit/poll/download | 只能做文档与 Mock，无法完成 G1 |
| 预算上限（单次 POC，如 ¥XXX） | 控制试验费用 | 不敢提交真实任务 |
| 授权页面（1–2 页） | 发送书页/角色图给供应商 | 不能传真实儿童绘本数据 |
| 时长/分辨率/fps 的允许范围 | 设 target_duration、验收 | 无法判断 clip 是否合格 |
| 数据保留/删除条款确认 | 合规 | 不能把真实页面发给云端 |
| 角色一致性验收人 | 人工评审 | 无法判定 P7 |

---

## 6. 建议执行顺序

1. **G0 通过后**：确定 primary provider（建议 Kling 4.0 Flash 先跑协议，4.0 做质量）；
2. 申请账号 + POC 预算 + 授权页面；
3. 用**独立 POC 脚本**（不进业务代码）跑 P1–P12；
4. 产出 `POC_REPORT.md`：能力表、时长/成本/时延、角色一致性截图、失败样本；
5. 队长/业主据此定 D02/D04/D07/D10 参数；
6. 再进入 G1 正式实现（provider 适配、clip 证据、C3/C4 v1.1）。

---

## 7. 结论

- 供应商方向明确：**Kling 4.0 首选，Vidu 备选，Runway 对照，开源兜底**；
- 但“真实动态视频 POC”**尚未执行**，因为缺账号、预算与数据授权；本轮不伪造结果；
- 下一步只差队长给：**供应商选择 + POC 预算 + 一页授权素材 + 允许的时长/分辨率**，我即可在 1–2 天内出 POC 报告。
