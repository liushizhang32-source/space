# 成员 3 技术升级影响评估：V1 AI 动态视频（方案 B）

| 项 | 内容 |
|---|---|
| 评估对象 | 《纸书智伴 V1 AI 动态视频最终成员开发执行规范》（ZSZB-V1-DYNAMIC-EXEC，2026-11-11） |
| 评估人 | 成员 3（Story / TTS / AI Video / FFmpeg） |
| 当前基线 | 成员 3 v1.1.6：Story 模板/LLM、静音或 HTTP TTS、静帧 FFmpeg 合成；134 项测试通过 |
| 本轮交付 | **仅本评估文档**；未改代码、测试、Schema、路由、工作流、分支 |
| 结论 | 现有 Story/TTS/媒体校验/发布事务可保留；Video 需要从“静帧合成器”升级为“逐 Segment 真实动态片的编排与合成”；阻塞项集中在供应商参数、时长策略、成本与验收标准，需 G0/G1 决策 |

---

## 1. 结论摘要

1. **不是推倒重做**：Story 生成、TTS、安全、媒体校验、原子发布、错误码体系都能保留；真正要换的是 `video.py` 的“每段静帧”生成方式，以及围绕它的 provider 适配、clip 证据和时长对齐。
2. **最大结构变化**：一个 Story Segment 必须对应一个可独立验证的 AI 动态 clip，且 clip 必须是真实模型产出，不能用静图/运镜/固定片替代。
3. **最大工程风险**：供应商多为“离散时长 + 异步排队 + 按次计费”，与当前“TTS 实测时长 + 180s 渲染 + 300s 任务”的预算模型不兼容；必须 POC 后重定预算，不能沿用旧值。
4. **接口不能现在改**：C3/C4 的 `video_plan`、`generation_mode`、`clips`，Jobs 的 4 个 video 子阶段，都只能在 G0 形成独立 v1.1 契约后实施；本文只给差异清单，不落地。
5. **验收不能只看“能解码”**：MP4 可播放不等于 AI 动态；需要“来源证据 + 每段独立 clip + 抽帧/动作人工评审 + 负例拒绝”，否则静态片也能混过。

---

## 2. 现状盘点：哪些可以保留

### 2.1 直接保留（只做小幅扩展）

| 模块/文件 | 现有能力 | 保留理由 |
|---|---|---|
| `agents/generation/story/builder.py` | 读 C1/C2、页身份校验、sanitize、≤120 字切分、安全三闸、TTS 逐段调用、C3 校验 | 输入契约和降级逻辑不变；只需在草稿阶段增加 `video_plan` 生成 |
| `agents/generation/story/template.py` / `text.py` | 模板故事、标点切分 | 继续服务 MOCK；REAL_VIDEO 下由 Planner 产出动作提示 |
| `agents/generation/story/llm.py` | OpenAI 兼容调用、重试、JSON 解析 | 可复用为“Planner LLM”，扩展输出 `video_plan` |
| `agents/generation/tts/*` | A6 服务、silent/http 引擎、内容哈希缓存、时长实测、有效性校验 | TTS 仍是时长基准；动态视频要求“先 TTS 后定 clip 目标时长”，正好复用 |
| `agents/generation/media.py` | 音频/视频三态校验、深解码、`-xerror` | 扩展 clip 的 hash/分辨率/fps/时长校验即可 |
| `agents/generation/safety.py` | 输入/草稿/落盘前三道闸 | 增加“提交供应商前的 prompt 安全审查” |
| `agents/generation/storage.py` | 原子写、相对路径→URL | 新增私有 `work/`、`clips/` 路径，公开文件名不变 |
| `agents/generation/video.py` 的 `_publish_pair` | MP4+JSON 成对发布、备份/回滚、页锁 | 继续作为最终发布事务；只替换“片段来源” |
| `agents/generation/pipeline.py` | 单页 story→tts→video、`pages[]` 结果、降级聚合 | 保留为集成面；增加 mode/clip 证据字段 |
| `agents/generation/errors.py` | 契约错误码与可重试白名单 | 不新增公共码；provider 细分只进内部台账 |
| `tests/`（134 项） | 契约、安全、降级、媒体、并发、恢复 | 全部保留；新增 provider 协议与动态负例测试 |

### 2.2 必须修改

| 模块 | 现状 | 目标 |
|---|---|---|
| `video.py::_render_clip` / `_render_once` | `-loop 1` 静帧 + 音频 + 字幕，按段渲染 | 改为“消费已验证 clip”：缩放/裁切/补边、按 TTS 时长裁切、烧字幕、按 order 拼接 |
| `video.py::compose_video` | 直接由 story.json 渲染 | 先检查每段 clip 证据（clip_id/hash/validation），缺一段即 `no_video`，不得静图补位 |
| `schemas.py` | C3/C4 仅 v1.0 | v1.1 可选字段：`video_plan`、`generation_mode`、`clips`；双版本读取 |
| `config.py` | `TTS_*`、`VIDEO_*`、`MAX_RETRY` 等 | 新增 `AI_VIDEO_*`（provider/model/base/key/timeouts/poll/retries/concurrency/cost），**无默认值**，缺配置即真实模式失败关闭 |
| `pipeline.py` | 页面结果 `{status,degraded,story_url,video_url,error}` | 增加 `generation_mode`、`clip_progress` 等适配字段（由 member1 的 Jobs 消费，不改公共 HTTP 契约） |
| `cli.py` | `video` 只跑静帧 | 增加 `video --mode mock|real`、`provider-check`，用于 POC，不作为公共 API |
| `media.py` | 视频校验停在“可解码” | 增加 clip 级校验：容器/编码/分辨率/fps/时长/hash/音轨；动态真实性只做机器辅助，最终由成员5人工评审 |

### 2.3 必须新增

| 新增模块 | 职责 |
|---|---|
| `agents/generation/video/provider.py` | 供应商中立协议：`submit(plan, idempotency_key)` / `poll(task_ref)` / `download(task_ref, dest)` / `cancel(task_ref)`；归一状态 `queued/running/succeeded/failed/cancelled` |
| `agents/generation/video/providers/<vendor>.py` | POC 选定供应商的实现；映射参数、错误、轮询；不把供应商状态写进公共枚举 |
| `agents/generation/video/plan.py` | `StorySegment -> VideoPlan`：prompt、reference_object_ids、character_keys、target_duration_sec；只引用本页 VLM 对象 |
| `agents/generation/video/clip_store.py` | 私有 clip 下载：`.part` 临时文件、域名/重定向/大小/MIME/SSRF 校验、sha256、全解码、原子 rename |
| `agents/generation/video/ledger.py`（只读/写接口） | **仅提供记录结构**；持久化与恢复由成员1负责，避免第二套 Job 状态机 |
| `docs/DYNAMIC_VIDEO_POC.md` | POC 方案、供应商对比、成本/时延记录（G1 产出） |

### 2.4 真实材料试跑观察（评估依据）

用成员二 2026-11-10 交付的 4 页 C1/C2 + 原图，在 v1.1.6 上实测：

| 页面 | 结果 | 对评估的意义 |
|---|---|---|
| `sally_p19` | done，4 段，18.8s | 正常页可跑通；但画面仍是静帧，证明现状只能算 MOCK |
| `fern_p01` | done，1 段，10.9s（无字页） | `empty` 语义正确，动态化后仍应保留无字模式 |
| `latin_p01` | done，但 20 段 / 597s / 渲染 168s | OCR 乱码会被模板放大成十分钟视频，证明需要语言/置信度过滤与总时长策略（R1/R9） |
| `boom_p01` | blocked 3004 | 成员二把 `safety_missing` 记为 `pass=false`，证明安全字段语义必须先对齐（R7） |

这组结果同时说明：**当前“能解码”的 MP4 完全可能只是静帧**，因此 REAL_VIDEO 必须有独立来源与动态证据（R5/R10）。

---

## 3. 与规范的接口差异

> 以下均为“目标 v1.1”提案，不是当前实现；v1.0 文件与消费者保持原样。

### 3.1 C3 `story.json`

| 字段 | v1.0 现状 | v1.1 目标 | 成员3动作 |
|---|---|---|---|
| `segments[].video_plan` | 无 | 新增可选；存在时四子字段齐备 | Planner 生成；MOCK 可给通用动作提示 |
| `video_plan.prompt` | 无 | 非空，主体动作+场景变化，过安全审查后提交 | 新增 |
| `video_plan.reference_object_ids` | 无 | 可空，只引用本页 VLM 对象 | 从 C2 `object_id` 取交集 |
| `video_plan.character_keys` | 无 | 可空，跨段角色键 | 由 Planner 维护；不要求成员2新增字段 |
| `video_plan.target_duration_sec` | 无 | >0，来自 TTS 实测/批准策略 | TTS 后回填 |
| `segments[].image_prompt` | 可选，v1 不消费 | 保留旧义，不改名 | 不再把它当动态指令 |
| `schema_version` | 常量 `1.0` | 常量 `1.1`，双读 | G0 后加 1.1 模型；不现在改 |

### 3.2 C4 `video.json`

| 字段 | v1.0 现状 | v1.1 目标 | 成员3动作 |
|---|---|---|---|
| `generation_mode` | 无 | 可选 enum `mock/real_video/hybrid_test`；REAL_VIDEO 条件必备 | 输出真实模式标签 |
| `clips[]` | 无 | 可选；REAL_VIDEO 条件必备，一段一 clip | 逐段产出证据 |
| `clips[].clip_id` | 无 | `{segment_id}_c01`，唯一 | 生成并校验 |
| `clips[].asset_path` | 无 | DATA_DIR 相对路径，禁止绝对/穿越 | clip_store 保证 |
| `clips[].sha256` | 无 | 64 位小写十六进制 | 下载后重算 |
| `clips[].provider/model` | 无 | 实际供应商/模型，mock 不得冒充 | 从 provider 结果写 |
| `clips[].provider_task_ref` | 无 | 脱敏引用，不暴露原始 ID | 由 ledger 映射 |
| `clips[].duration_sec` | 无 | >0，原始 clip 实测 | ffprobe |
| `clips[].validation` | 无 | `passed` 才允许进成功 C4 | 机器校验 + 人工评审标记 |
| `video_url` | 可选/null | 成功发布条件必填非空 | 发布门禁校验 |

### 3.3 Jobs（成员1 owner，成员3只提供数据）

| 项 | 变化 |
|---|---|
| `current_stage` / `stages[].name` | 增加 `video_submit/video_poll/video_download/video_validate`；成员3不直接改枚举 |
| `progress` | 5 阶段 → 9 阶段；成员1实现 |
| `pages[].clip_progress` | 新增可选 `{completed,total}`；成员3提供每页已完成且验证通过的 clip 数 |
| `degraded` | 保留 `no_video`；AI 生成/下载/验证/FFmpeg 失败都归 `no_video`，不新增公共码 |
| 错误码 | provider 私有错误只进内部 ledger；公共仍用 2001/2002/2003/2004/3004/3007/3008 |

### 3.4 配置

新增（无默认值，缺则真实模式启动失败）：

```
AI_VIDEO_PROVIDER / AI_VIDEO_MODEL / AI_VIDEO_API_BASE / AI_VIDEO_API_KEY
AI_VIDEO_REQUEST_TIMEOUT_SEC / AI_VIDEO_PROVIDER_TIMEOUT_SEC / AI_VIDEO_DOWNLOAD_TIMEOUT_SEC
AI_VIDEO_POLL_INTERVAL_SEC / AI_VIDEO_MAX_RETRIES / AI_VIDEO_MAX_CONCURRENCY
AI_VIDEO_MAX_JOB_COST / AI_VIDEO_DAILY_BUDGET / AI_VIDEO_MAX_CLIP_COST
```

约束：密钥只从服务环境读取；不进入前端、URL、C3/C4、日志、CI 产物；`GENERATION_MODE` 由成员1控制，普通用户不可切换。

### 3.5 存储

```
work/{job_id}/{segment_id}/      私有工作区（新增，G0 确认）
clips/                           私有 clip 存储（新增）
videos/{page_id}_video.mp4       公共稳定名（不变）
```

公开 JSON 只写相对路径；供应商签名 URL 不得作为 `video_url`。

---

## 4. 需要其他成员提供什么

### 成员1（Orchestrator）

- G0：独立 v1.1 契约（C3/C4 扩展、9 阶段、错误映射、版本协商、partial 聚合）。
- 持久化 ledger：`provider_task_id`、`request_hash`、attempt、deadline、cost、原始响应摘要；重启恢复不重复 submit。
- Job 状态机与预算：9 阶段 progress、provider 并发/日预算、job deadline、取消/force 隔离。
- 发布门禁：只有 `clips` 全部验证通过、C3/C4 关系校验通过，才发布 `video_url`。

### 成员2（视觉）

- 保持 C1/C2 稳定（已具备）；`object_id` 稳定、bbox 回原图。
- 如做角色参考：只新增可选扩展，不把 `character_keys` 变成 C2 必填。
- 安全 `safety.pass=false` 的语义要一致（当前 `safety_missing` 被记为 false，会阻断，需要他们确认是否预期）。

### 成员4（前端）

- 展示 9 阶段/片段计数/下载与验证状态，不虚构供应商百分比。
- 真实失败不得显示“已生成动态视频”；`partial` 时展示图文降级。
- force 后丢弃旧轮询；播放器只接已发布 URL。

### 成员5（评测）

- 动态真实性验收：每段独立来源、抽帧/运动/内容动作人工评审、角色一致性、音画同步、P95、成本。
- 负例库：固定片、静图运镜、跨段复用同一 clip 必须判不通过。

### 业主/队长

- 供应商与模型、地区与数据条款；
- 每段时长/段数/单 clip 限制；
- 分辨率/fps/编码；
- 单段/单 job/日成本与币种；
- P95、并发、角色一致性标准、音画容差。

---

## 5. 技术风险与缓解

| # | 风险 | 影响 | 缓解 |
|---|---|---|---|
| R1 | 供应商只支持离散时长（如 5s/10s），与 TTS 实测时长不匹配 | 无法一段一 clip；或被迫截断旁白 | POC 先验证“目标时长”能力；不够则重规划旁白/重 TTS；仍不满足则停在 G2 等业主裁定，禁止循环/静帧补时 |
| R2 | 跨段角色一致性无原生支持 | 同一角色每段长得不一样 | 角色参考图 + `character_keys` + 人工评审；必要时减少段数/换供应商 |
| R3 | 真实排队+生成远超 180s/300s 旧预算 | 任务必然超时 | 新预算分离 submit/poll/download/render/job；POC 给 P95 后再定 |
| R4 | 逐段生成+重试导致成本失控 | 费用不可控 | 幂等键、按 attempt 计费台账、单段/单 job/日预算、达到上限直接 2003 |
| R5 | 动态真实性难证 | 静态片可能混过验收 | 每段 clip 独立 hash/来源、跨段去重、抽帧+人工评审；机器校验只做辅助 |
| R6 | submit 响应丢失/重启 | 重复提交、双扣费 | 稳定幂等键 + 先落 intent 再 submit；恢复按原 task 查询；不确定则人工对账 |
| R7 | 下载安全（SSRF、超大、伪 MP4） | 安全/稳定性事故 | 域名/重定向白名单、大小/MIME 限制、`.part` + 全解码 + hash + 原子 rename |
| R8 | 音画不同步 | 观感差、返工 | TTS 先测时长；clip 覆盖后裁尾；短于旁白则重规划，不截断旁白 |
| R9 | v1.0/v1.1 双版本混用 | 旧前端/旧消费者崩 | 双读、能力协商、未知字段忽略；旧枚举不塞新 stage |
| R10 | 静态管线被误报为 REAL_VIDEO | 验收造假 | `generation_mode` 显式标签 + 负例测试 + 发布门禁拒绝 |
| R11 | 与成员1职责重叠（Job 状态机） | 两套状态不一致 | 成员3只提供 provider 适配与 clip 证据，不实现第二套 Job 状态机 |

---

## 6. 验证方案

### 6.1 分层测试

| 层级 | 内容 | 负责 |
|---|---|---|
| 契约回归 | v1.0 现有 134 项全保留；v1.1 Schema 与双读；未知字段/未知 enum | 3 + 1 |
| Provider 协议 | 用 fake provider 覆盖 submit/poll/download/cancel、429/5xx、响应丢失、幂等键、重复 poll | 3 |
| 媒体 | 伪 MP4/HTML、空/截断、错误编码、尺寸/fps/时长不符、hash 不符、无音轨 | 3 |
| 动态负例 | 静图、静图+zoompan、固定片、跨段复用同一 clip → 全部判不通过 | 3 + 5 |
| 音画 | TTS 长于/短于 clip、多段顺序、字幕对齐 | 3 |
| 端到端 | G2 单段真实闭环；G3 多段；G4 Orchestrator | 3 + 1 |
| 真实性能/成本 | 冷/热、失败、限流、单/多段 P50/P95、费用 | 5 |

### 6.2 REAL_VIDEO 验收证据（每段）

- `clip_id`、`segment_id`、provider/model、脱敏 task ref；
- 原始 clip 文件、sha256、`ffprobe` 元数据、FFmpeg 全解码退出码；
- 至少 2 帧抽帧 + 人工确认“主体/场景随时间发生内容动作”；
- 最终 mp4 与 Story 段一一对应、顺序正确、旁白未截断；
- 失败样本（固定片/静图/复用）必须被门禁拒绝。

### 6.3 分阶段门槛

| 门槛 | 成员3交付 |
|---|---|
| G0 | 本文 + v1.1 字段/协议提案 + 测试计划 |
| G1 | 单供应商 POC：submit/poll/download、单 clip 全解码、动态人工核验、成本/时延报告 |
| G2 | 单段真实闭环：TTS → clip → FFmpeg → 合法 C3/C4 + 证据 |
| G3 | 多段：顺序、角色一致性、失败重试、音画对齐 |
| G4 | 提供 adapter 接口与 clip 证据，配合成员1持久化/9 阶段/预算/恢复 |

---

## 7. 实施计划与相对工作量

> 依赖 G0/G1 结论；以下为相对量级，不是承诺工期。

| 阶段 | 工作 | 量级 |
|---|---|---|
| P0 | 本评估、接口差异、测试计划 | S（已完成） |
| G0 | v1.1 模型/协议提案、双读设计、测试骨架 | M |
| G1 | 供应商 POC、成本/时延、时长能力验证 | M–L（取决于账号/额度） |
| G2 | provider 适配、clip 下载校验、动态合成、单段闭环 | L |
| G3 | 多段编排、角色参考、顺序/重试、音画对齐 | L |
| G4 | 配合成员1 持久化/9 阶段/预算/恢复 | M |
| G5/G6 | 前端与评测支持、证据整理 | M |

---

## 8. 待决策事项（不擅自定）

1. 供应商/模型/地区与数据条款；
2. 每段时长、段数、单 clip 时长限制；
3. 分辨率、fps、宽高比、编码；
4. 单段/单 job/日成本与币种；
5. 总时延 P95、provider 并发/速率；
6. 跨段角色一致性标准；
7. 音画容差、裁切/变速允许范围；
8. 本地 ledger 与第三方保留/删除策略；
9. v1.1 版本协商、partial 聚合、cancel 路由、持久化方案。

---

## 9. 明确不做（本阶段）

- 不修改 `docs/API_v1.0.md`、公共 Schema、现有路由与枚举；
- 不把 `video_submit/poll/...` 塞进当前 5 阶段枚举；
- 不选供应商、不定时长/分辨率/成本/P95；
- 不实现第二套 Job 状态机或持久化（成员1负责）；
- 不把静图/运镜/固定 MP4 标成 `real_video`；
- 不在 v1.0 输出里新增字段；v1.1 只在 G0 后落地；
- 本阶段不提交代码、不建分支、不推送。

---

## 10. 对规范条款的逐项响应（摘要）

| 规范要求 | 成员3响应 |
|---|---|
| 每 Segment 一个 AI 动态 clip | 接受；`clip_id={segment_id}_c01`，一段一证据 |
| 动态片段 + TTS + FFmpeg 合成 | 接受；保留现有 FFmpeg 合成/字幕/发布事务 |
| 固定 MOCK 仅测试 | 接受；`generation_mode=mock` 显式标注，不参与真实成功率 |
| 静图/运镜不能替代 | 接受；现有静帧实现仅保留为 MOCK，REAL_VIDEO 门禁拒绝 |
| V1 就要真实动态 | 接受；但需 G0 契约 + G1 POC，不能跳过供应商/时长/成本决策 |
| 不改公共 API/Schema/业务代码 | 遵守；本文只评估，v1.1 待 G0 |
