# 第十轮（v1.1.9）复审交付报告：POC 治理五项

| 项 | 内容 |
|---|---|
| 分支 | `wzy622-patch-1` |
| 版本 | v1.1.9（累积 v1.1.8） |
| 测试 | **199 passed**（`logs/v119_batch_pytest.log`） |
| 范围 | 负责人要求的五项 POC 治理整改 |
| 真实 POC | 未执行：缺负责人 token，且 token 必须绑定输入 SHA256 |
| 未改 | 冻结 API v1.0、公共 Schema、路由、Jobs 状态机 |

## 1. 五项状态

| # | 要求 | 实现 |
|---|---|---|
| 1 | 实际输入 SHA256 核验 | `fetch_input_sha256()`；approval `input_sha256` 必须存在且匹配 |
| 2 | 跨运行累计调用/费用 | `PocLedger` 原子台账；per-approval + 全局 caps |
| 3 | 重试/正式调用计数 | `retry.py`；每次 submit 计数，poll/download 不计 |
| 4 | 视频生成接口适配 | `run_dynamic_page`：prepare→generate→媒体审核→compose |
| 5 | Fake 测试/完整日志 | 199 passed；`logs/v119_batch_pytest.log` |

## 2. 新增/修改

新增：

- `agents/generation/poc_ledger.py`
- `agents/generation/retry.py`
- `docs/M3_V1.1.9_POC_GOVERNANCE.md`
- `tests/test_poc_ledger.py`
- `tests/test_dynamic_pipeline.py` 的 `run_dynamic_page` 端到端

修改：

- `poc_gate.py`：输入 hash、`fetch_input_sha256`、`assert_allowed`。
- `scripts/wan_poc*.py`：先算实际图片 hash，再校验 token；提交前写累计台账。
- `dynamic_pipeline.py`：新增 `run_dynamic_page` 适配器；`story_digest` 排除 `elapsed_ms`。
- `trust.py`：`story_digest` 只绑定内容。

## 3. 测试

```
python -m pytest
199 passed in 53.28s
```

## 4. 仍需外部条件

1. 负责人签发 `POC_APPROVAL_TOKEN` + `SECRET`，且 `input_sha256` 填实际图片 hash；
2. M1 持久台账/fence/发布门禁；
3. 真实 TTS；
4. M5 人工评测；
5. Git PR。

## 5. 复审入口

```bash
pip install -r requirements.lock
python -m pytest            # 199 passed
```
