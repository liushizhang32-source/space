# M3 Wan 3.0 接入说明（Provider / Planner / 角色归一）

| 项 | 内容 |
|---|---|
| 决策 | 视频模型采用 **Wan 3.0**：`wan3.0-video`（标准）/ `wan3.0-video-prime`（优速）；Wan 2.7 作对照 |
| 依据 | V1.1 统一实施规范、M3 任务书、阿里云百炼官方文档（2026-11） |
| 本轮状态 | 已实现 Provider + Planner + 角色归一 + 12 项单测；**未调用真实 API**（缺 WorkspaceId/Key/预算/图片托管） |
| 未改 | 冻结 API v1.0、公共 Schema、路由、Jobs 状态机 |

## 1. 官方接口事实（已核对）

- 异步两段式：
  - `POST https://{WorkspaceId}.{region}.maas.aliyuncs.com/api/v1/services/aigc/video-generation/video-synthesis`
  - `GET  https://{WorkspaceId}.{region}.maas.aliyuncs.com/api/v1/tasks/{task_id}`
- Header：`Authorization: Bearer <API_KEY>`、`X-DashScope-Async: enable`、`Content-Type: application/json`
- 模型：`wan3.0-video`、`wan3.0-video-prime`；Wan 2.7 为 `wan2.7-i2v`
- 输出：MP4、30fps、480P/720P/1080P；时长 2–30s（`-1` 智能）；视频 URL **24 小时**
- 约束：
  - 模型、Endpoint、API Key **必须同地域**；
  - `first_frame` / `last_frame` 与 `reference_image` **互斥**，不能混用；
  - 默认生成供应商音轨，需 `audio=false` 关闭；
  - `input.media[].url` 必须是可公网访问的图片 URL，不能传本地路径。
- 价格（北京，标准价，美元/秒）：
  - `wan3.0-video-prime`：480P 0.0636、720P 0.1272、1080P 0.2544
  - `wan2.7-i2v`：720P 0.0860、1080P 0.1434
  - `wan3.0-video` 以控制台为准（文档未单列）
- 来源：
  - https://www.alibabacloud.com/help/zh/model-studio/wan3-video-generation-guide
  - https://www.alibabacloud.com/help/zh/model-studio/wan3-video-generation-api-reference
  - https://www.alibabacloud.com/help/zh/model-studio/wan3-0-video-prime
  - https://www.alibabacloud.com/help/zh/model-studio/wan-2-7-i2v

## 2. 本轮代码

| 文件 | 作用 |
|---|---|
| `agents/generation/providers/base.py` | `VideoPlan` / `ProviderTask` / `ProviderResult` / 归一状态 |
| `agents/generation/providers/wan.py` | Wan 3.0/2.7 Provider：submit / poll / wait / download / 错误映射 |
| `agents/generation/providers/__init__.py` | 导出 |
| `agents/generation/story/planner.py` | Segment → `VideoPlan`；角色 key；书级 `CharacterRegistry` |
| `tests/test_wan_provider.py` | 7 项：请求构造、两种 media 模式、轮询、超时、下载、超限、缺配置 |
| `tests/test_story_planner.py` | 5 项：段数/时长、prompt 不含运镜替代、角色 key 稳定、注册表持久化 |

关键实现：

- **两种模式自动切换**：
  - 无角色参考图 → `first_frame` 模式，保持书页原貌；
  - 有角色参考图 → 全模态 `reference_image` 模式（页面图 + 角色图），不混入 `first_frame`；
- `audio=false`，避免和自有 TTS 双音轨；
- `ratio=adaptive`，竖屏页面自适应；
- 时长 `max(2, min(30, round(target)))`；
- 下载后返回 sha256，交给媒体校验与发布层；
- Provider 不维护 Job 状态，只返回 typed 结果，符合“禁止第二套状态机”。

## 3. 还需要接的部分

1. **动态合成路径**：把 `video.py` 的“静帧渲染”替换为“消费 per-segment clip + TTS + 字幕”；静态路径只保留为 MOCK。
2. **C3/C4 v1.1 字段**：`video_plan`、`generation_mode`、`clips[]` 等，等 M1 的 G0 契约；本包未自行加。
3. **图片托管**：Wan 要求公网 URL；需要 M1 资产网关/OSS 上传，返回可访问 URL（真实儿童绘本上传前需授权）。
4. **ledger/持久化**：`task_id`、attempt、request_hash、cost 由 M1 存 SQLite；M3 只返回。
5. **角色裁切**：`CharacterRegistry` 已有 key/参考图登记；还需从 C2 bbox 裁角色图并上传。
6. **POC**：拿到 WorkspaceId/API Key/预算后，跑 1 页 2 段。

## 4. POC 计划（待 Key）

```
输入：sally_p19 页面图 + C1/C2 + 2 段 Story
模式：首帧模式（保页面）先跑；再用 reference_image 模式对比角色一致性
参数：wan3.0-video-prime / 720P / 5s / audio=false
预算：2 段 × 5s × $0.1272 ≈ $1.27（不含重试）
产出：task 记录、clip 文件、sha256、ffprobe、抽帧、人工评审、费用
```

验收：一段一 clip、时长 ≥ TTS、无供应商音轨、可解码、角色可辨认、失败负例拒绝。

## 5. 未解决问题

- `wan3.0-video`（非 prime）价格与限流需控制台确认；
- `reference_image` 模式下“书页文字/版式”能否保持，需 POC 对比；
- 角色参考图需要“同一角色跨页”的人工确认，自动裁切可能不准；
- 24h URL/任务过期，M1 必须有下载与对账兜底；
- 内容审核失败/超时/限流的重试预算，需与 M1 的 attempt/预算策略对齐；
- 真实绘本上传云端需授权确认。

## 6. 规范条款对应

| 条款 | 实现 |
|---|---|
| U-B 一段一真实 clip | Provider 一 Plan 一 task；下载后独立 hash |
| U-C 只有 M1 写 Job 状态 | Provider 无状态机，只返回 typed 结果 |
| U-G Provider 异步/取消/轮询 | submit/poll/wait；取消待 M1 路由 |
| U-H 来源证据 | task_id/model/url/hash/时长/分辨率记录 |
| U-L 预算/期限 | 费用按秒；超时/限流映射 2002/2003 |
| 禁止静态替代 | 静态路径仅 MOCK，不进入 Wan 成功判定 |
