# M3 V1.1 职责扩展落地说明（故事 / Segment / 动态视频 / 资产关联）

| 项 | 内容 |
|---|---|
| 依据 | 负责人 V1.1 正式开发执行通知（M3 职责扩大）、统一实施规范 |
| 状态 | 代码已落地；本地合成与协议测试通过；真实 Wan 多段受额度阻塞 |
| 测试 | **151 passed** |
| 未改 | 冻结 API v1.0、公共 Schema、路由、Jobs 状态机 |

## 1. 八项要求逐条对应

| # | 要求 | 实现 | 状态 |
|---|---|---|---|
| 1 | 根据绘本内容生成故事脚本 | 现有 `story/builder.py`（C1/C2 → 故事草稿）+ `story/planner.py`（段级视频计划） | 已有；真实 LLM 可选 |
| 2 | 拆成多个场景 / Segment | Builder 的 sanitize/≤120 字/≤20 段；Planner 按 Segment 产出 `VideoPlan` | 完成 |
| 3 | 每个 Segment 真实动态视频 | `providers/wan.py` 一 Plan 一 task；`video_dynamic.py` 一 Segment 一 clip，缺段即失败 | 代码完成；POC-01 已出 1 段真实 clip |
| 4 | 与原绘本视觉风格一致 | 首帧模式锁定书页；`PAGE_PRESERVE` prompt（固定机位/保构图文字/不新增物体）；资产清单记录 `style_profile` | 代码完成；需 POC-02 目测调 prompt |
| 5 | 跨页角色一致 | `CharacterRegistry`：稳定 `character_key`、别名归一（男孩/孩子/人物）、参考图登记；Provider 的 `reference_image` 模式 | 代码完成；需角色裁图 URL + Wan 额度 |
| 6 | 情节/动作连续 | `plan_segments(continuity=True)` 把上一段旁白写入下一段 prompt（“承接上一段…”） | 代码完成（prompt 级） |
| 7 | 匹配旁白/语音 | 现有 TTS 引擎/缓存/实测时长；动态合成按 Segment 音频时长裁 clip、烧字幕 | 已有；真实 TTS 服务待接 |
| 8 | 时间戳 / Segment ID / 资产 ID | `assets.py` 产出 `{page_id}_assets.json`：segment、clip、audio、start/end、hash、provider/model/task_ref、video asset | 完成 |

## 2. 新增交付物：`{page_id}_assets.json`

由 `video_dynamic.compose_dynamic_video()` 写出，供 M1/M2/M4 消费：

```json
{
  "schema_version": "1.1",
  "page_id": "book01_p03",
  "generation_mode": "real_video",
  "style_profile": {"source": "page_first_frame"},
  "characters": [{"key": "char_xxx", "label": "小兔子", "reference_url": "..."}],
  "segments": [
    {
      "segment_id": "book01_p03_s01",
      "order": 1,
      "start_sec": 0.0,
      "end_sec": 5.0,
      "narration": "...",
      "scene": "...",
      "character_keys": ["char_xxx"],
      "clip": {
        "clip_id": "book01_p03_s01_c01",
        "asset_id": "clip_book01_p03_s01_xxxxxxxxxxxx",
        "path": "clips/book01_p03_s01_c01.mp4",
        "sha256": "...",
        "duration_sec": 5.0,
        "width": 806,
        "height": 1140,
        "fps": 30.0,
        "provider": "wan",
        "model": "wan3.0-video-prime",
        "task_ref": "...",
        "source_kind": "ai_video"
      },
      "audio": {
        "asset_id": "aud_book01_p03_s01_xxxxxxxxxxxx",
        "path": "audios/tts_xxx.mp3",
        "duration_sec": 5.0,
        "engine": "tts"
      }
    }
  ],
  "video_path": "videos/book01_p03_video.mp4",
  "video_asset_id": "video_book01_p03_full_xxxxxxxxxxxx",
  "video_sha256": "...",
  "video_duration_sec": 10.0,
  "resolution": "720x1280",
  "fps": 25,
  "provider": "wan",
  "model": "wan3.0-video-prime"
}
```

用途：

- **M1**：发布门禁读 `video_asset_id`/`clip.asset_id`/`sha256`/`task_ref`，写 ledger；
- **M2**：用 `segment_id`、`clip_id` 对齐 OCR/VLM 与高亮；
- **M4**：用 `segments[].start_sec/end_sec` 做进度、字幕、播放器时间轴；
- **M5**：用 `source_kind`、provider/model/task_ref、hash 做真实性证据。

## 3. 代码修改清单

| 文件 | 变更 |
|---|---|
| `agents/generation/assets.py` | 新增：ClipAsset/AudioAsset/SegmentAsset/PageAssetManifest、asset_id、sha256、写清单 |
| `agents/generation/video_dynamic.py` | 新增：真实 clip → 裁切/字幕/音频 → concat → C4 + 资产清单；缺 clip/过短直接失败 |
| `agents/generation/story/planner.py` | 增强：`PAGE_PRESERVE`、`preserve_page`、`continuity`、标签去重/标点清理、角色别名归一 |
| `tests/test_video_dynamic.py` | 新增 3 项：正常合成+清单、缺 clip 失败、clip 过短失败 |
| `tests/test_story_planner.py` | 增加角色别名、连贯性 prompt 测试 |
| `scripts/wan_poc02.py` | POC-02：用 M2 C1/C2 生成两段计划（真实提交待额度） |

## 4. 未完成 / 阻塞

1. **Wan 额度**：`AccessDenied.Unpurchased`，POC-02 两段未提交；需购买资源包/开后付费。
2. **角色参考图 URL**：`CharacterRegistry` 已有登记，但角色裁图还没有公网 URL（需 OSS/资产网关）。
3. **风格一致性验证**：PAGE_PRESERVE 是否真能保住文字/版式，需 POC-02 目测；若不行，需调 prompt 或换 `reference_image` 模式。
4. **真实 TTS**：当前可用 silent 验证结构；正式旁白需 TTS 服务地址/音色。
5. **C3/C4 v1.1 公共字段**：`clips[]`/`generation_mode` 等需 M1 G0 契约；当前资产清单是**独立文件**，未改 v1.0。
6. **M1 资产网关**：自动上传图/角色图并返回 URL；否则每页仍需手动 OSS。
7. **跨页连贯性**：目前是 prompt 级“承接上一段”，真正的跨页动作/角色连续性还需 POC 评估。
8. **PR**：本机无 git/远程不可达，暂无 PR。

## 5. 下一步

- 先解决 Wan 额度，跑 POC-02 两段（保书页 + 角色参考）；
- 用 POC-02 结果调 PAGE_PRESERVE / reference 模式；
- M1 给资产网关和 v1.1 字段后，把 `video_dynamic` 接进 `run_page`，并把 `assets.json` 纳入发布门禁。
