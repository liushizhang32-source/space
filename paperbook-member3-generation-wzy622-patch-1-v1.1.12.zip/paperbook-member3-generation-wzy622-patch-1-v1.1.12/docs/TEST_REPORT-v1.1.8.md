# 第九轮（v1.1.8）复审交付报告：F01–F15 离线整改

| 项 | 内容 |
|---|---|
| 分支 | `wzy622-patch-1` |
| 版本 | v1.1.8（累积 v1.1.7） |
| 测试 | **190 passed**（`logs/v117_batch_pytest.log`） |
| 范围 | 官方 F01–F15 中 M3 可离线整改项 |
| 真实 POC | **未执行**：缺 `POC_APPROVAL_TOKEN`/`SECRET`，脚本会拒绝 |
| 未改 | 冻结 API v1.0、公共 Schema、路由、Jobs 状态机 |

## 1. 状态总表

| ID | 状态 | 证据 |
|---|---|---|
| F01 | 离线关闭 | 页身份、`safety_pass`、`SafetyReview` 内容绑定、`ensure_story_safe` |
| F02 | 离线关闭 | 模式/来源枚举、HMAC provenance、媒体审核、重复 clip/外部路径拒绝 |
| F03 | 离线适配器完成 | `dynamic_pipeline.prepare/generate/compose`；默认 CLI 仍 `mock_static` |
| F04 | 部分 | `UNKNOWN`、`cancel()` 回执、unsupported/超时保留 unknown |
| F05 | 部分 | `ExecutionContext`、request hash、幂等键、typed event |
| F06 | 部分 | 三件套原子发布/回滚；私有目录/M1 fence 未做 |
| F07 | 离线关闭 | HTTPS/域名/私网/重定向/类型/MP4 头/超限清理 |
| F08 | 离线关闭 | HMAC 授权、次数/时长/费用/地域/过期；脚本强制 |
| F09 | 离线关闭 | 缓存按 engine/model/version/rate/fmt 隔离；silent 标 estimate |
| F10 | 部分 | scope/canonical key、参考 hash、别名、跨页注册；真实评测未做 |
| F11 | 部分 | `safety.json`（unreviewed）、动态审核、媒体审核、prompt guard；生成媒体审核未做 |
| F12 | 离线关闭 | 每段实际 probe 建 PTS，字幕降级记录 |
| F13 | 离线关闭 | size/status/revision/音频来源/相对路径/total size |
| F14 | 部分 | `requirements.lock`；完整 CI/环境矩阵未齐 |
| F15 | 部分 | ProviderError.kind、脱敏 detail、unknown；CLI 统一脱敏未做 |

## 2. 本轮代码

新增：

- `trust.py`、`execution.py`、`publishing.py`、`poc_gate.py`、`dynamic_pipeline.py`
- `requirements.lock`
- `tests/test_execution.py`、`test_wan_cancel.py`、`test_publishing.py`、`test_wan_download_security.py`、`test_poc_gate.py`、`test_dynamic_pipeline.py`

修改：

- `video_dynamic.py`：安全/来源/媒体门禁、clip 去重/路径、三件套发布、PTS 时间轴、清单字段。
- `pipeline.py`：`generation_mode=mock_static`。
- `story/planner.py`：prompt 安全、scope/参考 hash、连贯性。
- `story/builder.py`：`safety.json` sidecar；silent 不误报 TTS 失败。
- `providers/base.py`、`providers/wan.py`：UNKNOWN、capabilities、cancel、execution、下载安全、错误分类。
- `tts/client.py`、`ids.py`：缓存按来源隔离；silent 标 estimate。
- `assets.py`：clip/audio/manifest 补 size/status/revision/source。
- `scripts/wan_poc*.py`：POC 授权/预算门禁。

## 3. 测试

```
python -m pytest
190 passed in 46.78s
```

日志：`logs/v117_group1_pytest.log`、`v117_group2_pytest.log`、`v117_group3_pytest.log`、`v117_batch_pytest.log`。

## 4. 未执行 / 未关闭

1. 真实 Wan POC：缺负责人签发 token；额度充值不等于授权。
2. 真实 TTS：silent 仍为 mock；`duration_source=estimate`。
3. F04/F05/F06：真实取消、M1 持久台账/fence/发布门禁未接。
4. F10：真实双页多段角色一致性未评测。
5. F11：生成图像/视频的供应商侧审核未实现。
6. F14/F15：完整 CI、CLI 日志脱敏未完成。
7. PR：本机无 git/远程不可达。

## 5. 复审入口

```bash
pip install -r requirements.lock
python -m pytest                  # 190 passed
python examples/install_example.py
python -m agents.generation run --page-id book01_p03
```
