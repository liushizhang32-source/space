# 第八轮（v1.1.7）交付报告：Wan 动态视频 + 资产清单

| 项 | 内容 |
|---|---|
| 分支 | `wzy622-patch-1` |
| 版本 | v1.1.7（累积 v1.1.6） |
| 测试 | **151 passed** |
| 真实 POC | Wan 3.0 单段 5 秒，SUCCEEDED，见 `artifacts/wan_poc/` |
| 未改 | 冻结 API v1.0、公共 Schema、路由、Jobs 状态机 |

## 1. 本轮新增

- **Wan 3.0 Provider**：submit / poll / wait / download；`audio=false`；首帧/参考图两种模式；错误映射。
- **Story Planner**：Segment → `VideoPlan`；保书页 prompt；连贯性“承接上一段”；角色 key/别名/参考图登记。
- **动态合成**：真实 clip + TTS + 字幕 → FFmpeg；缺 clip/过短直接失败，禁止静图补位。
- **资产清单**：`{page_id}_assets.json`，含 Segment、时间轴、clip/audio/video asset ID、hash、provider/model/task_ref。
- **POC-01 证据**：`artifacts/wan_poc/poc_s01.mp4` + 起始/结束帧 + probe。

## 2. 测试

```
151 passed in 41.95s
```

新增：
- `tests/test_wan_provider.py` 7 项；
- `tests/test_story_planner.py` 6 项；
- `tests/test_video_dynamic.py` 3 项。

## 3. POC-01 实测

| 项 | 值 |
|---|---|
| 模型 | `wan3.0-video-prime` / 720P / 5s |
| Task ID | `45950499-de03-4eea-bfde-aad97e44b462` |
| 端到端 | 约 72 秒 |
| 输出 | H.264 806×1140 / 30fps / 5.000s / 无音轨 |
| 大小 | 5,195,581 字节 |
| SHA-256 | `d15f01ef58dd1b6ef1b4e1b7a4e57c731d8d3e5070d6b43583277f7d05fb2fd2` |
| 估算费用 | 约 $0.64 |

观察：起始帧=原书页；结束帧=生成的卧室场景，说明是真实动态，但书页文字/版式未保持。POC-02（保书页 + 角色参考）因账号 `AccessDenied.Unpurchased` 暂停。

## 4. 已知限制

1. Wan 额度不足，POC-02 未跑；
2. 真实 TTS 未接，动态合成目前用 silent 验结构；
3. C3/C4 的 `clips[]`/`generation_mode` 等 v1.1 字段待 M1 G0；
4. 资产清单是独立文件，未改 v1.0；
5. 角色裁图公网 URL / 资产网关未接；
6. 跨页连贯性目前为 prompt 级；
7. 无 git/PR（远程不可达）。

## 5. 复现

```bash
pip install -r requirements.txt
python -m pytest            # 151 passed
python scripts/wan_poc02.py --image-url "..." --duration 5
```
