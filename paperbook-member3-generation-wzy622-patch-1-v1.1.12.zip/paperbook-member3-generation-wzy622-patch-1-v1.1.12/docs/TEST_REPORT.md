# 第十一轮（v1.1.12）交付报告：V1.1.8 技术准备

| 项 | 内容 |
|---|---|
| 分支 | `wzy622-patch-1` |
| 版本 | v1.1.12（对应负责人 V1.1.8 技术准备） |
| 测试 | **213 passed**（`logs/v118_tech_prep_pytest.log`） |
| 真实调用 | **0 次**；未调用 Wan、未产生收费请求 |
| 未改 | 冻结 API v1.0、公共 Schema、路由、Jobs |

## 1. 交付物

| # | 文件 |
|---|---|
| 1 | `docs/M3_V1.1.8_TOKEN_SPEC.md` |
| 2 | `docs/M3_V1.1.8_BUDGET_CONTROL_SPEC.md` |
| 3 | `docs/M3_V1.1.8_PROVIDER_ADAPTER.md` |
| 4 | `agents/generation/providers/fake.py` |
| 5 | `examples/v1.1.8/*.json` |
| 6 | `logs/v118_tech_prep_pytest.log` |
| 7 | `docs/M3_V1.1.8_TECHNICAL_PREPARATION_REPORT.md` |

## 2. 代码

新增：

- `approval.py`：`ApprovalClaims`、M1 验证客户端、Fake 验证器（仅测试）；
- `budget.py`：统一预算接口、`FakeBudgetService`（10 元总额、并发/重启）；
- `provider_adapter.py`：验证→预留→submit/poll/download→handoff；
- `providers/fake.py`：确定性 Fake Provider；
- `tests/test_approval_budget.py`（11 项）。

## 3. 测试覆盖

- Token 正常、篡改、过期、重放、素材 hash 不匹配；
- 预算耗尽、并发竞争、重启保持；
- 失败/重试计费；
- Fake Provider 完整流程；
- Adapter 全链路。

## 4. 未做

真实 Token 签发、真实 Wan 调用、真实 TTS、M1 持久台账/发布、M5 评测、PR。

## 5. 复审

```bash
pip install -r requirements.lock
python -m pytest     # 213 passed
```
